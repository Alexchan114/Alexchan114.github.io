# CAE MCP article sources

Canonical text: main.tex + article.tex. Published on 2026-10-18; engineering measurements are from 2026-10-12.

Build PDF with XeLaTeX twice:

    xelatex -interaction=nonstopmode -halt-on-error main.tex
    xelatex -interaction=nonstopmode -halt-on-error main.tex

main.tex uses ctex with Windows fonts. On another platform choose a supported ctex fontset and installed Chinese fonts.

Editable figures: figures/blog_figures.py, figures/*.tavotto.json, figures/tavotto_registry.json.
Open the figures directory in Tavotto, execute the registered script, and export each layout. The script uses numpy and matplotlib; data paths are relative to this source bundle. Existing exported PDF/PNG figures are included, so compiling the article does not require installed CAE software.

Data: data/task_metrics.json, CSV histories and provenance.json. engineering-query.txt is a portable editorial adaptation, not a byte-identical original query. tool_catalog.md lists all 54 tools. Three measured sessions, one case, one session per group; token counters are provider-reported and not calibrated across providers.

CAD/HM/INP files, commercial runtime libraries, solver databases and raw client transcripts are not included. Input fingerprints identify the measured engineering case; the numeric reference is not experimental ground truth.

English text: article.en.tex and main.en.tex. Run XeLaTeX twice on main.en.tex for the English PDF. Both languages use identical measured data and Tavotto figures.
