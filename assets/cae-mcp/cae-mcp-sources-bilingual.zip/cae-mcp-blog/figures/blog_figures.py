"""Editable Tavotto figure source. Data is measured, except the labeled sizing rule."""
from pathlib import Path
import csv
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

HERE = Path(__file__).resolve().parent
DATA = HERE.parent / 'data'
rows = json.loads((DATA / 'task_metrics.json').read_text(encoding='utf-8'))['rows']
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'axes.linewidth': .8, 'pdf.fonttype': 42,
                     'svg.fonttype': 'none', 'savefig.facecolor': 'white'})

def save(fig, name):
    fig.savefig(HERE / (name + '.pdf'))
    fig.savefig(HERE / (name + '.png'), dpi=180)

def box(ax, x, y, w, h, title, body, fill='white'):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.012',
                 linewidth=.9,facecolor=fill,edgecolor='.15'))
    ax.text(x+w/2,y+h*.72,title,ha='center',va='center',fontsize=11,fontweight='bold')
    ax.text(x+w/2,y+h*.32,body,ha='center',va='center',fontsize=9,linespacing=1.5)

def arrow(ax, start, end):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=12,
                               linewidth=1,color='.2',shrinkA=4,shrinkB=4))

fig,ax=plt.subplots(figsize=(9,5.2));fig.subplots_adjust(left=.035,right=.965,top=.97,bottom=.04)
ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
box(ax,.17,.81,.66,.15,'Agent + engineering procedures',
    'Intent / confirmed regions / units / next tool', '.96')
for x,title,body in [(.02,'HyperMesh MCP (13)','STEP / HM / partition / mesh'),
                     (.355,'Abaqus MCP (29)','Materials / resources / solve / ODB'),
                     (.69,'ParaView MCP (12)','Inspect / render / slice / sample')]:
    box(ax,x,.49,.29,.20,title,body)
    arrow(ax,(.5,.81),(x+.145,.69))
box(ax,.09,.19,.82,.17,'Shared dispatcher + persistent job records',
    'Input snapshot + hash / job_id / native logs / actual artifacts', '.96')
for x in [.165,.5,.835]:arrow(ax,(x,.49),(x,.36))
ax.text(.5,.08,'Native execution: Tcl  |  Abaqus Python + C++ SDK  |  pvpython',
        ha='center',va='center',fontsize=10)
save(fig,'architecture')

fig,ax=plt.subplots(figsize=(9,3.45));fig.subplots_adjust(left=.025,right=.975,top=.98,bottom=.04)
ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
for x,title,body in [(.02,'1  Element-local values','Extrapolate tensor\nto element nodes'),
                     (.355,'2  Scalar first','Compute Mises / component\nbefore averaging'),
                     (.69,'3  Region + threshold','Section assignment boundary\nthen Avg 75 test')]:
    box(ax,x,.43,.29,.45,title,body)
arrow(ax,(.31,.66),(.355,.66));arrow(ax,(.645,.66),(.69,.66))
ax.text(.5,.22,'Rejected averages and region boundaries retain separate coincident points.',
        ha='center',fontsize=10)
ax.text(.5,.08,'NodeLabel preserves identity; missing values remain NaN.',ha='center',fontsize=10)
save(fig,'averaging')

fig,axes=plt.subplots(2,1,figsize=(9,11.6));fig.subplots_adjust(left=.01,right=.99,top=.96,bottom=.06,hspace=.12)
for ax,name,title in [(axes[0],'prepress.png','a  Prepress: plate +0.3348 mm in Y'),
                      (axes[1],'insertion.png','b  Insertion: female + plate -10 mm in Z')]:
    ax.imshow(plt.imread(HERE/name));ax.axis('off');ax.set_title(title,fontsize=12,pad=12,loc='left')
fig.text(.5,.025,'Native ParaView results; deformation scale = 1. Each panel has its own stress scale.',
         ha='center',fontsize=9)
save(fig,'terminal_states')

force=list(csv.DictReader((DATA/'force_displacement.csv').open(encoding='utf-8')))
energy=list(csv.DictReader((DATA/'energy_history.csv').open(encoding='utf-8')))
fig,(ax,ay)=plt.subplots(1,2,figsize=(9,3.8),layout='constrained')
selected=[r for r in force if r['step']=='Insertion']
x=np.array([float(r['travel_mm']) for r in selected]);y=np.array([float(r['insertion_force_N']) for r in selected])
ax.plot(x,y,color='.12',lw=1.5);peak=int(np.argmax(y));ax.plot(x[peak],y[peak],'o',color='.12',ms=4)
ax.annotate(f'{y[peak]:.6f} N\nat {x[peak]:.3f} mm',(x[peak],y[peak]),xytext=(2.0,.85),
            fontsize=9,arrowprops={'arrowstyle':'->','lw':.8})
ax.set(xlabel='Insertion travel (mm)',ylabel='Projected actuator force (N)',xlim=(0,10))
ax.set_title('a  Stored reaction history',loc='left',fontsize=12)
for key,ls in [('ALLWK','-'),('ALLSE','--'),('ALLPD',':'),('ALLFD','-.')]:
    selected=[r for r in energy if r['variable']==key]
    ay.plot([float(r['total_time']) for r in selected],[float(r['value_Nmm']) for r in selected],
            color='.15',ls=ls,lw=1.5,label=key)
ay.axvline(1,color='.65',lw=.7);ay.set(xlabel='Static load-path parameter',ylabel='Energy (N mm)')
ay.set_title('b  Stored energy histories',loc='left',fontsize=12);ay.legend(frameon=False,fontsize=9)
for a in [ax,ay]:a.spines[['top','right']].set_visible(False)
save(fig,'force_energy')

fig,(ax,ay)=plt.subplots(1,2,figsize=(9,3.4),layout='constrained')
d=np.array([0,50000,200000,750000,1000000]);v=np.array([1,2,4,8,8])
ax.step(d/1000,v,where='post',color='.15',ls='--',label='Rule tier')
ax.step(d/1000,np.minimum(v,4),where='post',color='.15',lw=1.6,label='Host budget cap: 4')
case_d=24175*3*1.5;ax.plot(case_d/1000,2,'o',color='.15',ms=5)
ax.annotate('Terminal case: 2 CPUs',(case_d/1000,2),xytext=(180,3.1),fontsize=9,
            arrowprops={'arrowstyle':'->','lw':.8})
ax.set(xlabel='Weighted DOF proxy (thousand)',ylabel='Requested CPUs',yticks=[1,2,4,8],ylim=(0,9))
ax.legend(frameon=False,fontsize=8,loc='upper left');ax.set_title('a  Transparent sizing rule',loc='left',fontsize=12)
ay.axis('off')
for y,text in [(.85,'Scan INP + INCLUDE + instances'),(.61,'Bind the plan to source hashes'),
               (.37,'Reserve shared CPU / memory budget'),(.13,'Datacheck, solve, then release')]:
    ay.text(.5,y,text,ha='center',va='center',fontsize=10,
            bbox={'boxstyle':'round,pad=.65','facecolor':'white','edgecolor':'.3','linewidth':.8})
for y in [.75,.51,.27]:ay.annotate('',xy=(.5,y-.04),xytext=(.5,y+.015),
                                 arrowprops={'arrowstyle':'->','lw':.8})
ay.set_title('b  Execution contract',loc='left',fontsize=12)
ax.spines[['top','right']].set_visible(False)
save(fig,'resources')

fig,axes=plt.subplots(2,2,figsize=(9,7.0),layout='constrained');x=np.arange(3);labels=['A: MCP + procedures','B: native tools','C: native tools']
def style(ax,title,ylabel):
    ax.set_title(title,loc='left',fontsize=12,pad=14);ax.set_ylabel(ylabel)
    ax.set_xticks(x,['A','B','C']);ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',color='.88',lw=.5);ax.set_axisbelow(True)
a,b,c,d=axes.flat
native=np.array([r['native_analysis_wall_seconds']/60 for r in rows]);other=np.array([r['other_workflow_seconds']/60 for r in rows]);total=native+other
a.bar(x,native,color='.25',label='Final native analysis')
a.bar(x,other,bottom=native,color='white',edgecolor='.2',hatch='///',lw=.8,label='Other task time')
for i,n in enumerate(total):a.text(i,n+.9,f'{n:.2f}',ha='center',fontsize=9)
a.set_ylim(0,68);style(a,'a  Task elapsed time','Minutes');a.legend(frameon=False,fontsize=8)
w=.33;ordinary=np.array([r['ordinary_input_tokens']/1000 for r in rows]);output=np.array([r['output_tokens']/1000 for r in rows])
b.bar(x-w/2,ordinary,w,color='white',edgecolor='.2',hatch='///',lw=.8,label='Ordinary input')
b.bar(x+w/2,output,w,color='.25',label='Reported output')
for i,(n,o) in enumerate(zip(ordinary,output)):
    b.text(i-w/2,n+5,f'{n:.1f}',ha='center',fontsize=8);b.text(i+w/2,o+5,f'{o:.1f}',ha='center',fontsize=8)
b.set_ylim(0,300);style(b,'b  Reported input / output','Thousand tokens');b.legend(frameon=False,fontsize=8)
cache=[r['cached_input_tokens']/1e6 for r in rows];c.bar(x,cache,color='white',edgecolor='.2',hatch='...',lw=.8)
for i,n in enumerate(cache):c.text(i,n+.8,f'{n:.3f}',ha='center',fontsize=9)
c.set_ylim(0,58);style(c,'c  Reused input context','Million cache-read tokens')
terminal=np.array([r['native_file_terminal_calls'] for r in rows]);actions=np.array([r['mcp_action_calls'] for r in rows]);poll=np.array([r['mcp_poll_calls'] for r in rows])
d.bar(x,terminal,color='.25',label='File / terminal / edits')
d.bar(x,actions,bottom=terminal,color='white',edgecolor='.2',hatch='///',lw=.8,label='MCP operations')
d.bar(x,poll,bottom=terminal+actions,color='white',edgecolor='.2',hatch='...',lw=.8,label='MCP status polls')
for i,r in enumerate(rows):d.text(i,r['all_tool_calls']+5,str(r['all_tool_calls']),ha='center',fontsize=9)
d.set_ylim(0,310);style(d,'d  Actual tool calls','Calls');d.legend(frameon=False,fontsize=8)
save(fig,'task_effort')

fig,(ax,ay)=plt.subplots(1,2,figsize=(9,3.7),layout='constrained')
for group,label,ls in [('trial_a','A: MCP + procedures','-'),('trial_b','B: native tools','--'),('trial_c','C: native tools',':')]:
    samples=[r for r in csv.DictReader((DATA/(group+'_force.csv')).open(encoding='utf-8')) if r['step']=='Insertion']
    ax.plot([float(r['travel_mm']) for r in samples],[float(r['insertion_force_N']) for r in samples],
            color='.15',ls=ls,lw=1.5,label=label)
ax.set(xlabel='Insertion travel (mm)',ylabel='Projected actuator force (N)',xlim=(0,10))
ax.set_title('a  Independently extracted curves',loc='left',fontsize=11);ax.legend(frameon=False,fontsize=8)
vals=[r['normalized_curve_RMSE_percent'] for r in rows]
ay.bar([0,1,2],vals,color='white',edgecolor='.2',hatch='///',lw=.8)
for i,n in enumerate(vals):ay.text(i,n+0.000025,f'{n:.2e}%',ha='center',fontsize=8)
ay.set(xticks=[0,1,2],xticklabels=['A','B','C'],ylabel='Normalized curve RMSE (%)',ylim=(0,.00085))
ay.ticklabel_format(axis='y',style='sci',scilimits=(0,0));ay.set_title('b  Difference from numerical reference',loc='left',fontsize=10.5)
for a in [ax,ay]:a.spines[['top','right']].set_visible(False)
save(fig,'consistency')
