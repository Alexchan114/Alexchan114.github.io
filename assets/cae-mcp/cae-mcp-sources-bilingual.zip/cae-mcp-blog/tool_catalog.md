# MCP tool catalog

All long operations return job_id. Poll the matching *_job_status and consume actual result paths only after succeeded.

## abaqus (29 tools)

| Tool | Purpose |
|---|---|
| `abaqus_capabilities` | Show detected runtime paths and application availability; license validity is checked by actual execution. |
| `abaqus_job_status` | Read persistent job state, result paths, errors and current stage. queued/running is not success. |
| `abaqus_list_jobs` | List recent jobs owned by this application, including failed tasks. |
| `abaqus_job_artifacts` | List actual input snapshots, scripts, logs and outputs for a job; no guessed paths. |
| `abaqus_job_logs` | Read bounded tails of process logs for failure diagnosis without rerunning a job. |
| `abaqus_cancel_job` | Explicitly request cancellation of this job and its owned process tree. Existing output evidence is retained. |
| `abaqus_diagnose_job` | Read actual solve .dat/.msg/.sta/log/error evidence, classify errors and return verbatim bounded context, file hashes and eligible numerical repairs. Unknown errors have no guessed auto-fix. |
| `abaqus_repair_job` | Repair a failed solve into a new INP snapshot using current diagnostic_hash: reduce initial Static increment or raise max increments only. Keep total load/time, materials and contact; emit diff/manifest. Boundary/physics edits use explicit advanced scripts after user confirmation. Replan resources and datacheck before resubmitting. |
| `abaqus_plan_resources` | Scan actual INP/INCLUDE/instances, recommend CPU/memory by transparent scale rules and persist a source-hash-bound plan. License capacity is not inferred; submit_job consumes the plan. No solve is launched. |
| `abaqus_resource_status` | Show physical CPU/memory, configured solver budgets and live CPU/memory reservations for jobs owned by this suite. External jobs and live license capacity are not controlled. |
| `abaqus_library_list` | Search the local versioned material/section library. Returns real IDs, units and revisions; source values are not inferred or converted. |
| `abaqus_library_get` | Read a current or historical library record including exact keyword cards, material references and provenance. Immutable record hashes are checked. |
| `abaqus_library_put_material` | Create/update an elastic or exact-keyword material record with declared units. Existing IDs require expected_revision; old versions remain. No implicit unit conversion. |
| `abaqus_library_put_section` | Create/update a section referencing a specific material revision. Solid sections can be defined directly; other supported types retain actual keyword cards. ELSET is bound explicitly when exporting. |
| `abaqus_library_stage_import` | Stage existing INP/CAE/HM properties without modifying the source or library. CAE uses actual Abaqus writer; HM uses actual solver export. Preview reports original scopes, conflicts and unsupported/unrepresented definitions. |
| `abaqus_library_commit_import` | Publish a staged import atomically after checking source hashes and library revision. No silent overwrites; incomplete native extraction requires explicit partial-import acknowledgment. |
| `abaqus_library_export_template` | Export selected homogeneous solid sections/material revisions to properties.inp with explicit ELSET bindings and a version/hash manifest. Preserve supported orientations/controls; reject missing, conflicting or mesh-dependent dependencies. |
| `abaqus_library_archive` | Soft-archive a library record with explicit reason/current revision. Keep all versions; refuse archiving materials still referenced by active sections. No files are physically deleted. |
| `abaqus_inspect_model` | Inspect a flat tetra INP: actual node/element counts, named NSET/ELSET memberships, material names and existing steps. Preserves source; assemblies are explicitly unsupported by this adapter. |
| `abaqus_resolve_region` | Resolve real node IDs, named node/element sets, coordinate planes/boxes or nearest nodes. Fuzzy descriptions return candidates requiring a user choice. A resolved selection produces VTU for ParaView highlighting. |
| `abaqus_preview_load_case` | Preview node forces and translation constraints without applying them. Preserve input material cards or use an external material/section template. Record targets, distribution, global vectors, source hashes and required fuzzy-description confirmation. |
| `abaqus_apply_load_case` | Apply a succeeded preview to a new static INP. Refuse unresolved choices, missing external properties, stale sources or fuzzy targets/directions without an explicit user response matching the exact plan hash. Confirmation is a host declaration, not identity authentication. |
| `abaqus_inspect_odb` | Inspect ODB with the native C++ reader: steps, frame counts, fields, section points and detected defaults. |
| `abaqus_export_odb` | Submit read-only C++ ODB-to-VTU/PVD conversion. Default last step/frame, U+S:MISES, Avg75 by actual section assignment. Fields/SP/position/frames configurable; missing values remain NaN. |
| `abaqus_prepare_linear_static` | Prepare a new simple linear-elastic case from a flat tetra mesh. Explicit material/units, fixed extreme face, opposite-face equally distributed total force. Does not reinterpret an existing assembly/contact model. |
| `abaqus_validate_tetra_mesh` | Check flat tetra connectivity and signed corner volumes. This is not a full quadratic Jacobian certification. |
| `abaqus_submit_job` | Submit a real Standard/Explicit solve with automatic scale-based CPU/memory defaults or a hash-bound resource_plan_id. Explicit values remain budget-checked. Shared reservations queue competing solves; completion and closed nonempty ODB are required. |
| `abaqus_extract_nodal_results` | Extract stored nodal U/RF (or specified nodal fields) to CSV using Abaqus Python. Reports reaction component totals in the stored coordinate basis; never sums contact sides implicitly. |
| `abaqus_run_python_script` | Advanced: execute a supplied Python script using Abaqus Python or CAE noGUI in an isolated job cwd. User code is not sandboxed; stdout/logs and completion result are captured. |

## hypermesh (13 tools)

| Tool | Purpose |
|---|---|
| `hypermesh_capabilities` | Show detected runtime paths and application availability; license validity is checked by actual execution. |
| `hypermesh_job_status` | Read persistent job state, result paths, errors and current stage. queued/running is not success. |
| `hypermesh_list_jobs` | List recent jobs owned by this application, including failed tasks. |
| `hypermesh_job_artifacts` | List actual input snapshots, scripts, logs and outputs for a job; no guessed paths. |
| `hypermesh_job_logs` | Read bounded tails of process logs for failure diagnosis without rerunning a job. |
| `hypermesh_cancel_job` | Explicitly request cancellation of this job and its owned process tree. Existing output evidence is retained. |
| `hypermesh_import_step` | Import an actual STP/STEP snapshot into a fresh HyperMesh model with verified 2017 step_ct CAD reader. Validate nonempty geometry/bounds; expose scale and declared units. No material assignment is invented. |
| `hypermesh_inspect_model` | Inspect a snapshot of a native HM model: geometry IDs/counts, bounding box, solid volume and element configurations. Does not change the source. |
| `hypermesh_create_block` | Create an axis-aligned solid block using native HyperMesh geometry. Returns a new HM model; default dimensions 10x4x2 and declared mm units. |
| `hypermesh_partition_solids` | Partition selected (or all) native solids with a plane using verified HyperMesh 2017 Tcl. Requires solid count increase and preserved total volume; saves a new model. |
| `hypermesh_mesh_tetra` | Mesh geometry-only HM solids as C3D4/C3D10/C3D10M; default size min bbox extent/3 when omitted. Saves HM+INP and validates actual exported types and corner volumes. Existing mesh is not deleted. |
| `hypermesh_export_abaqus` | Export a snapshot of an existing HM model with the installed Abaqus Standard 3D solver template. Export alone does not add materials, loads or steps. |
| `hypermesh_run_tcl` | Advanced: run supplied Tcl on an optional HM snapshot, then save a new HM model. Batch has no stdout Tcl channel; write logs to files. User script is not a sandbox. |

## paraview (12 tools)

| Tool | Purpose |
|---|---|
| `paraview_capabilities` | Show detected runtime paths and application availability; license validity is checked by actual execution. |
| `paraview_job_status` | Read persistent job state, result paths, errors and current stage. queued/running is not success. |
| `paraview_list_jobs` | List recent jobs owned by this application, including failed tasks. |
| `paraview_job_artifacts` | List actual input snapshots, scripts, logs and outputs for a job; no guessed paths. |
| `paraview_job_logs` | Read bounded tails of process logs for failure diagnosis without rerunning a job. |
| `paraview_cancel_job` | Explicitly request cancellation of this job and its owned process tree. Existing output evidence is retained. |
| `paraview_inspect_data` | Inspect real ParaView reader output: steps, point/cell arrays, component ranges, counts and bounds. |
| `paraview_render` | Render an offscreen PNG and save PVSM state using installed pvpython. Auto color prefers S_MISES; optional U deformation. No point-cleaning or averaging filter is inserted. |
| `paraview_slice` | Create a plane slice as VTP; an empty intersection fails. Derived interpolation is separate from original nodal averaging. |
| `paraview_plot_over_line` | Sample a line to CSV without smoothing. Respect vtkValidPointMask for points outside the mesh. |
| `paraview_get_screenshot` | Return the actual PNG from a succeeded render job as native MCP image content. |
| `paraview_run_python_script` | Advanced: execute supplied Python with pvpython in isolated cwd; capture completion and logs. User code is not sandboxed. |

