"""Original public benchmark diagrams; pilot metrics are read from measured records."""
from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = Path(__file__).resolve().parent
DATA = json.loads((ROOT/"figure_data.json").read_text(encoding="utf-8"))
INK, TEAL, ORANGE, GRAY = "#203746", "#197b77", "#bf6039", "#6a7780"
plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":10, "text.color":INK,
    "axes.labelcolor":INK, "axes.edgecolor":GRAY, "xtick.color":GRAY, "ytick.color":GRAY,
    "pdf.fonttype":42, "axes.spines.top":False, "axes.spines.right":False})


def box(ax, x, y, w, h, text, color=TEAL):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=.012,rounding_size=.015", lw=1, ec=color, fc=color+"0b"))
    ax.text(x+w/2,y+h/2,text,ha="center",va="center",fontsize=10,linespacing=1.7)


def arrow(ax, start, end, color=GRAY):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle="-|>",mutation_scale=12,lw=1.2,color=color))


fig,ax=plt.subplots(figsize=(9,4.3))
ax.set(xlim=(0,1),ylim=(0,1));ax.axis("off")
ax.text(.02,.96,"SEPARATE THE EXPERIMENTAL FACTORS",weight="bold",fontsize=12)
box(ax,.03,.57,.24,.24,"PUBLIC TASK\nfixture + query\nfixed budgets")
box(ax,.37,.57,.25,.24,"HARNESS\nmini / Pi SDK\nMODEL via CCS")
box(ax,.72,.57,.24,.24,"FIXED TOOLS\naxial FEM\nSchur condensation")
arrow(ax,(.28,.69),(.35,.69));arrow(ax,(.64,.69),(.70,.69))
box(ax,.37,.15,.25,.22,"OBSERVABLE TRACE\nquery / output / tools\nartifact hashes",INK)
box(ax,.72,.15,.24,.22,"HOST VALIDATOR\nindependent reference\nchecks, not claims",ORANGE)
arrow(ax,(.50,.55),(.50,.39));arrow(ax,(.84,.55),(.84,.39));arrow(ax,(.64,.26),(.70,.26))
ax.text(.03,.30,"No agent filesystem,\nshell, evaluator or\ncredential access",fontsize=10,color=GRAY,linespacing=1.6)
ax.text(.02,.025,"Live CAE track: 54 MCP tool schemas probed; vendor task execution is not yet evaluated.",fontsize=9,color=GRAY)
fig.subplots_adjust(left=.02,right=.98,top=.96,bottom=.02)
fig.savefig(ROOT/"architecture.pdf")

fig,axes=plt.subplots(2,1,figsize=(9,5.6),gridspec_kw={"height_ratios":[1,1.2]})
ax=axes[0];ax.axis("off");ax.set(xlim=(-.5,6.5),ylim=(-.9,.8))
ax.text(-.45,.65,"AUTONOMOUS PARTITION: 7 DOFs TO 5 RETAINED DOFs",weight="bold",fontsize=11)
for i in range(6):
    color=TEAL if i<3 else ORANGE
    ax.plot([i,i+1],[0,0],lw=5,color=color,solid_capstyle="round")
    ax.text(i+.5,.17,"r"+str(i+1),ha="center",fontsize=10,color=color)
for i in range(7):
    ax.scatter(i,0,s=90,fc="white",ec=INK,zorder=3,lw=1.1)
    ax.text(i,-.25,str(i),ha="center")
ax.text(1.5,-.68,"SUB r1-r3: eliminate DOFs 1 and 2",ha="center",color=TEAL,fontsize=10)
ax.text(4.5,-.68,"CORE r4-r6: retain nonlinear behavior",ha="center",color=ORANGE,fontsize=10)
ax=axes[1]
experiment=DATA["partition_experiment"]
force=[r["force_N"] for r in experiment["correct"]["load_results"]]
ax.plot(force,[r["full_tip_U_mm"] for r in experiment["correct"]["load_results"]],"o-",color=INK,label="Full bilinear assembly")
ax.plot(force,[r["reduced_tip_U_mm"] for r in experiment["correct"]["load_results"]],"x--",color=TEAL,ms=9,label="Linear SUB + nonlinear CORE")
ax.plot(force,[r["reduced_tip_U_mm"] for r in experiment["unsafe"]["load_results"]],"s:",color=ORANGE,label="Incorrect: freeze all regions linear")
ax.set(xlabel="Applied force / N",ylabel="Tip displacement / mm")
ax.legend(frameon=False,fontsize=9,loc="upper left");ax.grid(alpha=.15)
fig.subplots_adjust(left=.10,right=.98,top=.96,bottom=.12,hspace=.30)
fig.savefig(ROOT/"partition.pdf")

rows=[r for r in DATA["pilot"]["rows"] if not r["classification"].startswith("excluded_")]
fig,ax=plt.subplots(figsize=(9,3.8))
labels=[r["task"]+" / "+("Pi + DeepSeek" if r["harness"]=="pi" else "mini + Kimi") for r in rows]
colors=[TEAL if r["classification"]=="passed" else ORANGE for r in rows]
ax.barh(range(len(rows)),[r["elapsed_seconds"] for r in rows],color=colors,height=.48)
ax.set_yticks(range(len(rows)),labels);ax.invert_yaxis()
for i,row in enumerate(rows):
    ax.text(row["elapsed_seconds"]+2,i,"{:.1f}s / {}".format(row["elapsed_seconds"],"passed" if row["classification"]=="passed" else "output budget"),va="center",fontsize=9)
ax.set(xlabel="Task wall time / s",xlim=(0,max(r["elapsed_seconds"] for r in rows)*1.65))
ax.set_title("PILOT ONLY: 4 VALID ATTEMPTS, NO MODEL OR HARNESS RANKING",loc="left",fontsize=11,pad=16)
ax.spines[["left","top","right"]].set_visible(False);ax.grid(axis="x",alpha=.14);ax.set_axisbelow(True)
fig.subplots_adjust(left=.25,right=.98,top=.83,bottom=.17)
fig.savefig(ROOT/"pilot.pdf")
