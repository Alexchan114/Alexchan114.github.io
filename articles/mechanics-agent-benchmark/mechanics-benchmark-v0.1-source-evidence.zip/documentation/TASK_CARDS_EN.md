# Task Cards and Implementation Status

## M01 - Load, units and equilibrium

Status: executable_fixture; tier: mechanics-fixture

Inspect the stepped axial bar. Determine the correct end constraints and force sign; compute tip displacement, support reaction, segment stress and strain energy. Use the provided independent axial solver tool to obtain execution evidence and verify equilibrium. Report all four results in solution and include the solver artifact ID. Do not claim a 3D Abaqus result.

```json
{
  "units": "mm-N-MPa",
  "nodes_mm": [
    0.0,
    12.0,
    30.0,
    50.0
  ],
  "segments": [
    {
      "id": "s1",
      "E_MPa": 110000.0,
      "area_mm2": 2.0
    },
    {
      "id": "s2",
      "E_MPa": 70000.0,
      "area_mm2": 1.5
    },
    {
      "id": "s3",
      "E_MPa": 200000.0,
      "area_mm2": 3.0
    }
  ],
  "applied_tip_force_N": 18.0,
  "fixed_node": 0,
  "load_node": 3
}
```

## M02 - Mechanics-driven mesh allocation

Status: specified_not_executable; tier: cae-live

Import the supplied redistributable solid, choose refinement regions using the specified loads and quantity of interest, generate quadratic tetrahedra and demonstrate mesh sensitivity under the DOF budget. Deliver input decks and complete quality evidence, not screenshots alone.

```json
{
  "required_inputs": [
    "original STEP",
    "material and loads",
    "DOF budget",
    "independent fine-mesh reference"
  ]
}
```

## M03 - Nonlinear preload and contact

Status: specified_not_executable; tier: cae-live

Construct the prescribed preload-then-insert contact analysis without changing material, friction or contact physics. Extract every specified normal contact channel and audit plasticity, endpoint completion and energy measures.

```json
{
  "required_inputs": [
    "public contact mesh",
    "material/section cards",
    "load path",
    "reference solve"
  ]
}
```

## M04 - Autonomous substructure partition

Status: executable_fixture; tier: mechanics-fixture

Choose retained CORE regions and condensable SUB regions for the provided connected 1D assembly. Preserve active nonlinear/contact behavior over the whole declared load envelope, not just the baseline frame. Run condensation_test on your candidate. Your solution must list core_regions, sub_regions, retained_dofs, relative_tip_error and artifact_id. Static accuracy, required interface DOFs and a genuine interior-DOF reduction all matter. Justify the decision. This is a spring-chain mechanics fixture, not an Abaqus substructure benchmark result.

```json
{
  "units": "mm-N",
  "load_envelope_N": [
    1.0,
    5.0,
    12.0
  ],
  "fixed_dof": 0,
  "loaded_dof": 6,
  "regions": [
    {
      "id": "r1",
      "dofs": [
        0,
        1
      ],
      "stiffness_N_mm": 1400.0,
      "law": "linear"
    },
    {
      "id": "r2",
      "dofs": [
        1,
        2
      ],
      "stiffness_N_mm": 900.0,
      "law": "linear"
    },
    {
      "id": "r3",
      "dofs": [
        2,
        3
      ],
      "stiffness_N_mm": 650.0,
      "law": "linear"
    },
    {
      "id": "r4",
      "dofs": [
        3,
        4
      ],
      "stiffness_N_mm": 100.0,
      "law": "bilinear",
      "transition_force_N": 4.0,
      "post_stiffness_N_mm": 25.0
    },
    {
      "id": "r5",
      "dofs": [
        4,
        5
      ],
      "stiffness_N_mm": 150.0,
      "law": "linear"
    },
    {
      "id": "r6",
      "dofs": [
        5,
        6
      ],
      "stiffness_N_mm": 120.0,
      "law": "bilinear",
      "transition_force_N": 7.0,
      "post_stiffness_N_mm": 30.0
    }
  ],
  "max_relative_tip_error": 0.005
}
```

## M05 - Bounded manufacturing variables

Status: specified_not_executable; tier: cae-live

Map geometric shapes, independent plate prelift and terminal X/Y translations to bounded normal amplitudes. Generate samples with explicit scales; verify independent control points, rigid translations, mesh quality and the declared interface strategy.

```json
{
  "required_inputs": [
    "public HM with shapes",
    "component and control mapping",
    "scales and distribution",
    "reference interfaces"
  ]
}
```

## M06 - Library reuse and interface integrity

Status: specified_not_executable; tier: cae-live

Select or reject candidate substructure libraries using provenance, retained DOFs, node labels and coordinates. Assemble only a compatible library, complete datacheck and verify actual interface coverage. Matching filenames and enlarged Tie tolerance are not sufficient.

```json
{
  "required_inputs": [
    "public CORE",
    "matching and mismatching libraries",
    "interface specification"
  ]
}
```

## M07 - Pose failure-boundary search

Status: specified_not_executable; tier: cae-live

At fixed manufacturing amplitudes, choose trials to resolve whole-male initial offset/angle failure boundaries before insertion. Verify terminal contact forces at the declared final displacement. Do not assume global monotonicity or classify solver failure as physical failure.

```json
{
  "required_inputs": [
    "validated public baseline",
    "pose axes and center",
    "threshold and endpoint",
    "solve budget"
  ]
}
```

## M08 - Failure recovery and trusted ranking

Status: specified_not_executable; tier: cae-live

Recover a batch containing numerical, mesh, resource and interruption failures. Preserve successful runs and physical conditions, repair only supported errors, then rank complete contact results with explicit exclusions for missing channels or endpoints.

```json
{
  "required_inputs": [
    "public fault-injected batch",
    "known-good baseline",
    "independent expected classifications"
  ]
}
```
