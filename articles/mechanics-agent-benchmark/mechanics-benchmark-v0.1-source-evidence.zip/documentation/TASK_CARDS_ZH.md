# 题库与执行状态

## M01 - 载荷、单位与平衡

Status: executable_fixture; tier: mechanics-fixture

审查阶梯轴向杆，确定端部约束与载荷符号，求端位移、支座反力、各段应力和应变能。调用所给轴向求解工具获取执行证据并验证平衡。将四类结果和求解产物编号写入solution。不得声称这是三维Abaqus结果。

```json
{
  "units": "mm-N-MPa",
  "nodes_mm": [
    0.0,
    12.0,
    30.0,
    50.0
  ],
  "segments": [
    {
      "id": "s1",
      "E_MPa": 110000.0,
      "area_mm2": 2.0
    },
    {
      "id": "s2",
      "E_MPa": 70000.0,
      "area_mm2": 1.5
    },
    {
      "id": "s3",
      "E_MPa": 200000.0,
      "area_mm2": 3.0
    }
  ],
  "applied_tip_force_N": 18.0,
  "fixed_node": 0,
  "load_node": 3
}
```

## M02 - 力学驱动网格分配

Status: specified_not_executable; tier: cae-live

导入可公开实体，在给定载荷和关注量下自主选择细化区域，划分二阶四面体，在自由度预算内完成网格敏感性验证，交付输入文件及完整质量证据。

```json
{
  "required_inputs": [
    "original STEP",
    "material and loads",
    "DOF budget",
    "independent fine-mesh reference"
  ]
}
```

## M03 - 非线性预压与接触

Status: specified_not_executable; tier: cae-live

实施规定的先预压后插入接触分析，不修改材料、摩擦与接触物理，提取全部指定法向接触通道并核验塑性、终点与能量。

```json
{
  "required_inputs": [
    "public contact mesh",
    "material/section cards",
    "load path",
    "reference solve"
  ]
}
```

## M04 - 自主子结构区域决策

Status: executable_fixture; tier: mechanics-fixture

为给定一维装配选择CORE与可凝聚SUB，在整个载荷包络中保留活动非线性/接触而非仅看基线帧。调用condensation_test验证方案。solution应包含core_regions、sub_regions、retained_dofs、relative_tip_error、artifact_id，并解释依据。这是弹簧链力学算例，不是Abaqus子结构实测。

```json
{
  "units": "mm-N",
  "load_envelope_N": [
    1.0,
    5.0,
    12.0
  ],
  "fixed_dof": 0,
  "loaded_dof": 6,
  "regions": [
    {
      "id": "r1",
      "dofs": [
        0,
        1
      ],
      "stiffness_N_mm": 1400.0,
      "law": "linear"
    },
    {
      "id": "r2",
      "dofs": [
        1,
        2
      ],
      "stiffness_N_mm": 900.0,
      "law": "linear"
    },
    {
      "id": "r3",
      "dofs": [
        2,
        3
      ],
      "stiffness_N_mm": 650.0,
      "law": "linear"
    },
    {
      "id": "r4",
      "dofs": [
        3,
        4
      ],
      "stiffness_N_mm": 100.0,
      "law": "bilinear",
      "transition_force_N": 4.0,
      "post_stiffness_N_mm": 25.0
    },
    {
      "id": "r5",
      "dofs": [
        4,
        5
      ],
      "stiffness_N_mm": 150.0,
      "law": "linear"
    },
    {
      "id": "r6",
      "dofs": [
        5,
        6
      ],
      "stiffness_N_mm": 120.0,
      "law": "bilinear",
      "transition_force_N": 7.0,
      "post_stiffness_N_mm": 30.0
    }
  ],
  "max_relative_tip_error": 0.005
}
```

## M05 - 有界制造公差

Status: specified_not_executable; tier: cae-live

将几何shape、独立小板预抬和端子X/Y平移映射到有界正态幅值，生成含明确物理尺度的样本，核验独立控制点、刚体平移、网格质量与规定接口策略。

```json
{
  "required_inputs": [
    "public HM with shapes",
    "component and control mapping",
    "scales and distribution",
    "reference interfaces"
  ]
}
```

## M06 - 子结构复用与接口完整性

Status: specified_not_executable; tier: cae-live

按来源、保留自由度、节点编号和坐标选择或拒绝候选子结构库，仅装配兼容库并完成datacheck和实际接口覆盖核验，不能只靠同名文件或增大Tie容差。

```json
{
  "required_inputs": [
    "public CORE",
    "matching and mismatching libraries",
    "interface specification"
  ]
}
```

## M07 - 偏位偏角失效边界搜索

Status: specified_not_executable; tier: cae-live

固定制造公差后自主安排试算，探查公端整体初始偏位/偏角下的插入失效边界，核验规定终点的接触力，不假设全局单调、不将求解失败当物理失效。

```json
{
  "required_inputs": [
    "validated public baseline",
    "pose axes and center",
    "threshold and endpoint",
    "solve budget"
  ]
}
```

## M08 - 故障恢复与可信排名

Status: specified_not_executable; tier: cae-live

恢复含数值、网格、资源和中断故障的批次，保留成功结果和物理条件，仅修复有证据的错误，对完整接触结果排名并明确排除缺通道或未达终点的case。

```json
{
  "required_inputs": [
    "public fault-injected batch",
    "known-good baseline",
    "independent expected classifications"
  ]
}
```
