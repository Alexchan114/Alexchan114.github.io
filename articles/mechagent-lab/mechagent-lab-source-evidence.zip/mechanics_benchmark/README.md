# Mechanics Agent Benchmark / 力学工程 Agent 评测

## MechAgent Lab (local V3)

The native-client extension is in `outputs/mechanics_agent_benchmark_v03_20261105`.
It adds actual Claude Code/DeepSeek and Codex CLI loops to the same eight public
tasks. Use `native_suite.py` / `native_probe.py` for the registered native track;
historical mini/Pi evidence remains unchanged. Read the bilingual release
READMEs for budgets, startup exclusions, protocol ambiguity and the Codex S04
tool timeout. Native client names do not imply identical underlying models or
equal token budgets. Public articles are titled **MechAgent Lab**, not V3.

## Historical release v0.2.2

`run_suite.py` supplies eight independently checked public exercises, separate
from the historical v0.1 commands below. S04 uses actual Abaqus/MCP; seven other
exercises explicitly use reduced physics/evidence fixtures. Read the bilingual
READMEs in `outputs/mechanics_agent_benchmark_v02_20261104` or the release ZIP.

Ten attempts are retained: four passes, two valid budget failures, one RPM error
and three protocol-ambiguity exclusions. Final wording v0.2.2 is clarified but
has no further agent retry. This is not a leaderboard or an eight-task native
industrial-CAE evaluation. Frozen source snapshots and protocol review accompany
all evidence. The remainder of this README describes historical v0.1 only.

Development version 0.1.0, 2026-11-03. The eight-family design is approved. **Only M01 and M04 mechanics fixtures are currently executable; six live-CAE task families are specifications, not completed tests.**

本阶段交付题库、独立数值评分、真实模型/Pi调用和完整轨迹。不能把一维算例通过解释为已完成三维连接器、完整Abaqus子结构选择或工业精度验收。

## Architecture

`task -> mini or Pi harness -> existing CCS API route -> fixed mechanics tools -> artifacts -> independent evaluator`

The controlled-tool track gives the model no shell, filesystem, arbitrary Python or network tools. Its tools cannot read evaluator code, CCS credentials or prior answers. Host code and approved SDK dependencies are trusted. This is capability isolation at the agent-tool boundary, not a claim of an OS sandbox for arbitrary native agent programs. Native unrestricted CLI evaluation and live CAE tool access require a separate isolation design before execution.

CCS database is opened read-only. Credentials exist only in host memory and, for Pi, the subprocess stdin pipe and SDK in-memory auth storage. They are not saved to provider files or command-line arguments. No provider switching, active CCS route changes or global Pi configuration changes are performed.

## Local setup

Use Python 3.11+ with NumPy and HTTPX. For Pi, use a project-local SDK install; this tested version works with the existing Node 22.16 runtime:

```powershell
python -m pip install numpy httpx
npm install --prefix outputs/mechanics_agent_benchmark_20261103/pi-runtime --ignore-scripts --no-audit --no-fund @mariozechner/pi-coding-agent@0.73.1
python -m unittest discover -s mechanics_benchmark/tests -v
python -m mechanics_benchmark inventory
python -m mechanics_benchmark tasks
```

Pi 0.73.1 is the intentionally pinned compatibility version, not a claim to be the latest upstream. Its namespace has since moved; installed package-lock.json preserves this pilot's dependency resolution. SDK cost fields are zero placeholders; actual billed cost stays **unknown**, never zero.

## Run an existing CCS route

Run commands from the project root. Select the exact provider ID from `inventory`; do not paste credentials. `--app claude` chooses the CCS configuration namespace, not the harness. A Claude-compatible API can be used by either the mini or Pi adapter.

```powershell
python -m mechanics_benchmark run --task M01 --adapter mini --provider YOUR_CCS_PROVIDER_ID --model EXACT_API_MODEL_ID --output outputs/my_new_run
python -m mechanics_benchmark run --task M04 --adapter pi --provider YOUR_CCS_PROVIDER_ID --model EXACT_API_MODEL_ID --output outputs/my_new_pi_run
```

Existing output directories are refused. Defaults: at most 6 model requests, 4096 output tokens per request, 18 tool calls, 250000 context characters, 180 seconds per request. Provider alias resolution is recorded only when observable; never relabel the underlying model from its self-description. Keys with context decorations such as `[1m]` are not accepted as exact model IDs.

The initial Kimi `kimi-k2.5` route returned model/permission HTTP404. The read-only catalog exposed `kimi-k2.6`, which was selected explicitly without changing CCS. The initial Pi probe had an empty custom-tool allowlist; it is retained but excluded as adapter-invalid. These are not hidden or deleted retries. The Kimi M04 attempt exhausted its per-request output allocation before submission; preserve that budget-dependent result rather than tuning the prompt after seeing the answer.

## Outputs

- `run.json`: task/model/harness, budgets, input/query/schema hashes, status and times.
- `query.json`: complete benchmark system/user prompts and tool definitions.
- `trace.jsonl`: every observable request, response, tool interaction and adapter event.
- `artifacts/`: numerical solver/condensation experiment records.
- `submission.json`, `evaluation.json`: final structured submission and independent numerical checks.
- `pi_messages.json`: Pi's exported session messages when available.

No textual "solve succeeded" assertion counts as execution evidence. M01 uses a direct-stiffness 1D finite-element solve checked against an independent analytical series-bar solution. M04 performs actual Schur condensation on spring-chain blocks and checks the full bilinear load envelope, interfaces and eliminated DOFs independently. Both are explicitly `mechanics-fixture`, not `cae-live`.

## MCP preparation

The existing D:/kimi CAE suite can be read-only probed with an MCP-enabled interpreter:

```powershell
& D:/kimi/cae-mcp/.venv/Scripts/python.exe -m mechanics_benchmark.probe_mcp --output outputs/my_new_mcp_probe
```

This initializes real stdio MCP sessions and captures tool schemas/capabilities from HyperMesh, Abaqus and ParaView. It does not launch vendor jobs. Author setup probes are never added to evaluated-agent query, timing or token totals. The pilot numerical tools are host capability tools, **not calls to the three commercial-software MCPs**.

## Reporting

```powershell
python -m mechanics_benchmark.report outputs/mechanics_agent_benchmark_20261103
```

This retains all attempts, excludes invalid adapter/environment probes from the valid task count, produces bilingual task cards and complete query/output appendices, and locally scans generated evidence against actual CCS credential values without saving those values. Missing billing information remains null. Original traces and per-file SHA256 remain authoritative.

The formal 96-run repeated campaign is not launched by these commands. It requires actual completed fixtures, frozen validators, reference cases, a budget and a registered comparison matrix. Public publication must not expose private geometry or claim superiority from this small mixed-model/mixed-harness pilot.
