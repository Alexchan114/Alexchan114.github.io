from pathlib import Path
import tempfile
import unittest
from mechanics_benchmark.run_suite import freeze
from mechanics_benchmark.suite_v2 import task_cards


class ConfigurationTests(unittest.TestCase):
    def test_final_task_contract_states_recovery_policy(self):
        q=task_cards()['S08']['query']
        self.assertIn('ASCENDING',q)
        self.assertIn('physical failure alone is not a reason to retry',q)
        self.assertIn('completed jobs with missing channels use reextract',q)
    def test_crossed_model_harness_and_source_snapshot(self):
        with tempfile.TemporaryDirectory() as d:
            cfg={'custom-pi':dict(provider='public-id',model='explicit-model',adapter='pi'),
                'custom-mini':dict(provider='public-id',model='explicit-model',adapter='mini')}
            reg=freeze(Path(d),configurations=cfg,matrix=[dict(task='S03',configuration='custom-pi'),dict(task='S03',configuration='custom-mini')])
            self.assertEqual(reg['configurations'],cfg)
            self.assertIn('pi_bridge.mjs',reg['source_hashes'])
            self.assertTrue((Path(d)/'frozen_source/mechanics_benchmark/run_suite.py').is_file())

    def test_no_credential_fields_or_duplicate_attempts(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):freeze(Path(d),configurations={'bad':dict(provider='a',model='b',adapter='pi',secret='never-store')})
            with self.assertRaises(ValueError):freeze(Path(d),matrix=[dict(task='S01',configuration='kimi-mini')]*2)


if __name__=='__main__':unittest.main()
