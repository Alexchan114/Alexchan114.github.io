import json
from pathlib import Path
import tempfile
import unittest
from mechanics_benchmark.native_host import Host,serve_host
from mechanics_benchmark.security import Trace
from mechanics_benchmark.suite_v2 import task_cards,definitions
import urllib.request
import os
import subprocess
from mechanics_benchmark.native_suite import PYTHON,ROOT


class HostTests(unittest.TestCase):
    def test_actual_rpc_evidence_and_unavailable_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);host=Host(task_cards()['S01'],Trace(folder),None,None)
            with serve_host(host) as base:
                def call(method,params={}):
                    req=urllib.request.Request(base+'/broker',data=json.dumps(dict(jsonrpc='2.0',id=1,method=method,params=params)).encode(),
                        headers={'X-Benchmark-Token':host.token,'Content-Type':'application/json'})
                    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req) as r:return json.load(r)
                self.assertEqual(len(call('tools/list')['result']['tools']),3)
                self.assertIn('error',call('files/read'))
                value=call('tools/call',dict(name='experiment',arguments=dict(parameters={})))
                result=json.loads(value['result']['content'][0]['text'])
                call('tools/call',dict(name='submit_solution',arguments=dict(solution={k:result[k] for k in ('artifact_id','U_mm','reaction_N','energy_Nmm')},explanation='Offline')))
                self.assertEqual(json.loads((folder/'evaluation.json').read_text())['status'],'passed')

    def test_missing_tools_never_reaches_upstream(self):
        with tempfile.TemporaryDirectory() as tmp:
            host=Host(task_cards()['S01'],Trace(Path(tmp)),None,None)
            status,result,_=host.infer(dict(tools=[],model='mock'))
            self.assertEqual(status,400);self.assertEqual(host.requests,0)
            self.assertEqual(host.blocked,'unexpected_model_tool_catalog')

    def test_tiny_relay_reads_only_registered_tools(self):
        with tempfile.TemporaryDirectory() as tmp:
            host=Host(task_cards()['S01'],Trace(Path(tmp)),None,None)
            with serve_host(host) as base:
                env=dict(os.environ,PYTHONPATH=str(ROOT),MECH_BROKER_URL=base+'/broker',MECH_BROKER_TOKEN=host.token)
                requests=[dict(jsonrpc='2.0',id=1,method='initialize',params={}),dict(jsonrpc='2.0',method='notifications/initialized'),
                    dict(jsonrpc='2.0',id=2,method='tools/list')]
                proc=subprocess.run([PYTHON,'-m','mechanics_benchmark.native_bridge'],env=env,
                    input='\n'.join(map(json.dumps,requests))+'\n',capture_output=True,text=True,timeout=10)
                answers=[json.loads(l) for l in proc.stdout.splitlines()]
                self.assertEqual(proc.returncode,0)
                self.assertEqual([r['id'] for r in answers],[1,2])
                self.assertEqual({r['name'] for r in answers[1]['result']['tools']},{r['name'] for r in definitions()})


if __name__=='__main__':unittest.main()
