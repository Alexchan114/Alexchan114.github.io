import math
from pathlib import Path
import tempfile
import unittest
import numpy as np
from mechanics_benchmark.suite_v2 import task_cards,definitions
from mechanics_benchmark.suite_tools import Broker
from mechanics_benchmark.suite_evaluate import evaluate
from mechanics_benchmark.security import Trace
from mechanics_benchmark.solid_reference import deck


class SuiteTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.cards=task_cards()

    def broker(self,key):return Broker(self.cards[key],Trace(Path(self.tmp.name)))

    def exp(self,b,p):
        r=b.call('experiment',dict(parameters=p));self.assertNotIn('error',r);return r

    def passed(self,b,s):
        result=evaluate(b.card,s,b.artifacts)
        self.assertEqual(result['status'],'passed',result)
        bad=dict(s,artifact_id='fabricated')
        if 'artifact_id' in s:self.assertEqual(evaluate(b.card,bad,b.artifacts)['score'],0)

    def test_01(self):
        b=self.broker('S01');r=self.exp(b,{})
        self.passed(b,{k:r[k] for k in ('artifact_id','U_mm','reaction_N','energy_Nmm')})

    def test_02(self):
        b=self.broker('S02');r=self.exp(b,dict(n=8))
        self.passed(b,dict(artifact_id=r['artifact_id'],n=8,U_mm=r['U_mm'],relative_error=abs(r['U_mm']/(.01*math.log(2))-1)))
        r=self.exp(b,dict(n=64));self.assertEqual(evaluate(b.card,dict(artifact_id=r['artifact_id'],n=64,U_mm=r['U_mm'],relative_error=0),b.artifacts)['score'],0)

    def test_03(self):
        b=self.broker('S03');f=b.card['fixture']
        a=[max(0,max((.4/f['stiffness_N_per_mm'][j]+f['gaps_mm'][j]-.18-.3348)/.15 for j in [2*i,2*i+1])) for i in range(6)]
        r=self.exp(b,dict(amplitudes=a));self.passed(b,dict(artifact_id=r['artifact_id'],amplitudes=a,forces_N=r['forces_N']))

    def test_04_mocked_validator_not_solver(self):
        b=self.broker('S04')
        retained=list(range(1,10))+list(range(55,64))
        b.artifacts['fixture']=dict(parameters=dict(cut_mm=6),result=dict(engine='actual Abaqus MOCK IN UNIT TEST ONLY',
            checks=dict(a=True),jobs=dict(full='a',generation='b',reduced='c',extract='d'),max_curve_difference_N=0))
        s=dict(artifact_id='fixture',cut_mm=6,retained_nodes=retained,retained_dofs=[1,2,3],eliminated_dofs=135)
        self.passed(b,s)
        self.assertIn('error',b.call('experiment',dict(parameters=dict(cut_mm=8))))
        for cut in [2,4,6]:
            text=deck('generation',cut=cut)
            self.assertNotIn('ELSET=PLASTIC',text)
            self.assertIn(str(1+9*cut),text)

    def test_05(self):
        b=self.broker('S05');rows=[self.exp(b,dict(method=m,seed=20261104)) for m in ('MC','LHS','Sobol','Halton')]
        self.assertNotIn('amplitudes',rows[0])
        self.passed(b,dict(artifact_ids=[r['artifact_id'] for r in rows],first_MC_physical_mm=rows[0]['first_physical_mm']))

    def test_06(self):
        b=self.broker('S06');p=dict(library_id='L17',tie_tolerance_mm=math.sqrt(2)*.1+1e-6,adjust=False)
        r=self.exp(b,p);self.passed(b,dict(artifact_id=r['artifact_id'],**p))
        p['library_id']='L24';r=self.exp(b,p)
        self.assertEqual(evaluate(b.card,dict(artifact_id=r['artifact_id'],**p),b.artifacts)['score'],0)

    def test_07(self):
        b=self.broker('S07');lo,hi=0,2
        for _ in range(11):
            mid=(lo+hi)/2;r=self.exp(b,{'lambda':mid})
            if r['failed']:hi=mid
            else:lo=mid
        a=self.exp(b,{'lambda':lo});c=self.exp(b,{'lambda':hi})
        self.passed(b,dict(lambda_safe=lo,lambda_failed=hi,artifact_ids=[a['artifact_id'],c['artifact_id']]))

    def test_08(self):
        b=self.broker('S08');r=self.exp(b,{})
        s=dict(artifact_id=r['artifact_id'],ranking=['c02','c03','c01','c08'],contact_failures=['c02','c03'],
            actions=dict(c01='done',c02='done',c03='done',c04='retry_solve',c05='reextract',c06='wait',c07='repair_mesh',c08='done'))
        self.passed(b,s);s['actions']['c06']='retry_solve'
        self.assertEqual(evaluate(b.card,s,b.artifacts)['score'],0)

    def test_capabilities_and_no_escape(self):
        b=self.broker('S01')
        self.assertEqual({s['name'] for s in definitions()},{'inspect_fixture','experiment','submit_solution'})
        for name,p in [('shell',{}),('experiment',dict(parameters=dict(path='secret'))),('inspect_fixture',dict(path='secret'))]:
            self.assertIn('error',b.call(name,p))
        self.assertIn('error',b.call('experiment',dict(parameters=dict(x=float('nan')))))


if __name__=='__main__':unittest.main()
