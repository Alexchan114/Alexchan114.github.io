import unittest
import numpy as np
from mechanics_benchmark.solid_reference import grid,deck


class SolidReferenceTests(unittest.TestCase):
    def test_original_mesh_and_positive_orientation(self):
        nodes,elements=grid()
        self.assertEqual(len(nodes),117)
        self.assertEqual(len(elements),48)
        for _,connection in elements.values():
            self.assertEqual(len(set(connection)),8)
            a,b,d,e=(np.array(nodes[connection[i]]) for i in (0,1,3,4))
            self.assertGreater(np.linalg.det(np.array([b-a,d-a,e-a])),0)

    def test_shared_interface_and_dof_reduction(self):
        _,elements=grid()
        left={n for i,conn in elements.values() if i<6 for n in conn}
        right={n for i,conn in elements.values() if i>=6 for n in conn}
        self.assertEqual(left & right,set(range(55,64)))
        retained=set(range(1,10))|set(range(55,64))
        self.assertEqual(3*len(left-retained),135)
        self.assertIn('*RETAINED NODAL DOFS\nRETAINED,1,3',deck('generation'))
        self.assertNotIn('ELSET=PLASTIC\n',deck('generation'))
        with self.assertRaises(ValueError):deck('reduced')

    def test_reduced_has_actual_library_dependency(self):
        text=deck('reduced','D:/public/analysis')
        self.assertIn('TYPE=Z101,ELSET=SUB,FILE=D:/public/analysis',text)
        self.assertIn('*PLASTIC\n1.,0.\n2.,0.02',text)
        self.assertIn('TIP,1,1,0.12',text)


if __name__=='__main__':unittest.main()
