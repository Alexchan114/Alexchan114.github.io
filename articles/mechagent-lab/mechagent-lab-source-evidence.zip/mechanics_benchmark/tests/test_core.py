from copy import deepcopy
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import subprocess
import tempfile
import unittest

from mechanics_benchmark.credentials import inventory, select
from mechanics_benchmark.evaluate import evaluate
from mechanics_benchmark.mechanics import axial_solve, condensation_test
from mechanics_benchmark.security import Trace, confined, scrub
from mechanics_benchmark.tasks import get_task, TASKS
from mechanics_benchmark.tools import Broker
from mechanics_benchmark.report import classify, usage


class BenchmarkTests(unittest.TestCase):
    def test_axial_independent_reference_and_scale(self):
        task = get_task("M01")
        result = axial_solve(task["fixture"])
        self.assertAlmostEqual(result["support_RF_N"], -18)
        self.assertAlmostEqual(result["force_balance_N"], 0, places=9)
        solution = {k: result[k] for k in ("tip_U_mm", "support_RF_N", "stress_MPa", "strain_energy_Nmm")}
        solution["solver_artifact"] = "a"
        score = evaluate(task, solution, {"a": dict(tool="axial_solve")})
        self.assertEqual(score["score"], 100)
        scaled = deepcopy(task["fixture"])
        scaled["applied_tip_force_N"] *= 2
        doubled = axial_solve(scaled)
        self.assertAlmostEqual(doubled["tip_U_mm"], 2*result["tip_U_mm"])
        self.assertAlmostEqual(doubled["strain_energy_Nmm"], 4*result["strain_energy_Nmm"])
        solution["support_RF_N"] = 18
        self.assertEqual(evaluate(task, solution, {"a": dict(tool="axial_solve")})["status"], "failed")

    def test_no_artifact_no_full_credit(self):
        task = get_task("M01")
        answer = dict(axial_solve(task["fixture"]), solver_artifact="fake")
        score = evaluate(task, answer, {})
        self.assertFalse(score["checks"]["executed_artifact"])
        self.assertLess(score["score"], 100)

    def test_safe_condensation(self):
        task = get_task("M04")
        args = dict(core_regions=["r4", "r6"], sub_regions=["r1", "r2", "r3", "r5"], retained_dofs=[0,3,4,5,6])
        result = condensation_test(task["fixture"], **args)
        self.assertEqual(result["eliminated_dofs"], [1,2])
        self.assertEqual(result["relative_tip_error"], 0)
        matrix = result["condensed_blocks"][0]["stiffness_N_mm"]
        stiffness = 1/(1/1400+1/900+1/650)
        self.assertAlmostEqual(matrix[0][0], stiffness)
        solution = dict(args, relative_tip_error=0., artifact_id="a")
        artifacts = {"a": dict(tool="condensation_test", arguments=args)}
        self.assertEqual(evaluate(task, solution, artifacts)["score"], 100)

    def test_unsafe_condensation_rejected(self):
        task = get_task("M04")
        args = dict(core_regions=[], sub_regions=[r["id"] for r in task["fixture"]["regions"]], retained_dofs=[0,6])
        result = condensation_test(task["fixture"], **args)
        self.assertGreater(result["relative_tip_error"], .005)
        solution = dict(args, relative_tip_error=0, artifact_id="a")
        score = evaluate(task, solution, {"a": dict(tool="condensation_test", arguments=args)})
        self.assertFalse(score["checks"]["nonlinear_preserved"])
        self.assertFalse(score["checks"]["reported_error"])
        self.assertFalse(score["checks"]["response_accuracy"])

    def test_all_core_no_reduction_credit(self):
        task = get_task("M04")
        args = dict(core_regions=[r["id"] for r in task["fixture"]["regions"]],sub_regions=[],retained_dofs=list(range(7)))
        score = evaluate(task, dict(args, relative_tip_error=0., artifact_id="a"),
                         {"a": dict(tool="condensation_test", arguments=args)})
        self.assertFalse(score["checks"]["genuine_reduction"])

    def test_missing_interface(self):
        task = get_task("M04")
        args = dict(core_regions=["r4", "r6"], sub_regions=["r1", "r2", "r3", "r5"], retained_dofs=[0,4,5,6])
        result = condensation_test(task["fixture"], **args)
        self.assertIn(3, result["missing_required_dofs"])

    def test_secrets_and_path_escape(self):
        value = scrub(dict(api_key="private-key", text="private-key Bearer abcd123", nested=[dict(auth_token="x")]), ["private-key"])
        self.assertNotIn("private-key", json.dumps(value))
        self.assertNotIn("abcd123", json.dumps(value))
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaises(ValueError):
                confined(root, "../outside.json")

    def test_readonly_ccs_and_duplicate_namespace(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder)/"ccs.db"
            with closing(sqlite3.connect(db)) as connection:
                connection.execute("CREATE TABLE providers(id TEXT, app_type TEXT, name TEXT, settings_config TEXT)")
                for app in ("claude", "claude-desktop"):
                    connection.execute("INSERT INTO providers VALUES (?,?,?,?)", ("same", app, "test",
                        json.dumps(dict(env=dict(ANTHROPIC_BASE_URL="https://example.com/anthropic",
                                                 ANTHROPIC_AUTH_TOKEN="private-key", ANTHROPIC_MODEL="test-model")))))
                connection.commit()
            old = db.read_bytes()
            self.assertEqual(len(inventory(db)), 2)
            route = select("same", db)
            self.assertEqual(route.app, "claude")
            self.assertNotIn("private-key", repr(route))
            self.assertNotIn("private-key", json.dumps(route.public()))
            self.assertEqual(old, db.read_bytes())

    def test_tools_do_not_expose_evaluator(self):
        with tempfile.TemporaryDirectory() as folder:
            broker = Broker("M01", get_task("M01"), Trace(folder))
            self.assertIn("error", broker.call("read_file", dict(path="evaluate.py")))
            self.assertIn("error", broker.call("axial_solve", dict(path="anything")))
            result = broker.call("axial_solve", {})
            self.assertIn(result["artifact_id"], broker.artifacts)

    def test_status_does_not_pretend_all_tasks_executable(self):
        self.assertEqual(len(TASKS), 8)
        self.assertEqual(sum(t["status"] == "executable_fixture" for t in TASKS.values()), 2)

    def test_invalid_adapter_probe_not_a_model_score(self):
        meta = dict(adapter="pi",task_id="M04",status="no_submission")
        events = [dict(kind="pi_harness_ready",active_tools=[])]
        self.assertEqual(classify(meta,events), "excluded_adapter_invalid")
        self.assertIsNone(usage([])["output"])

    def test_output_budget_classification(self):
        meta = dict(adapter="mini",task_id="M04",status="no_submission")
        events = [dict(kind="model_response",response=dict(stop_reason="max_tokens"))]
        self.assertEqual(classify(meta,events), "output_budget_exhausted")

    def test_pi_actual_tool_registration_without_inference(self):
        root = Path(__file__).resolve().parents[2]
        module = root/"outputs/mechanics_agent_benchmark_20261103/pi-runtime/node_modules/@mariozechner/pi-coding-agent/dist/index.js"
        node = Path("D:/NodeJs/node.exe")
        if not module.exists() or not node.exists():
            self.skipTest("Optional pinned Pi runtime is not installed")
        from mechanics_benchmark.api import SYSTEM
        from mechanics_benchmark.tools import definitions
        config = dict(type="init", module=str(module),cwd=str(root),secret="synthetic-test-value",
            model="test-model",protocol="anthropic",base_url="https://example.invalid",query="dry run",
            system=SYSTEM,tools=definitions("M01"),max_turns=1,max_output_tokens=256,timeout_ms=1000,dry_run=True)
        result = subprocess.run([str(node),str(root/"mechanics_benchmark/pi_bridge.mjs")],input=json.dumps(config)+"\n",
            capture_output=True,text=True,encoding="utf-8",timeout=30)
        events = [json.loads(line) for line in result.stdout.splitlines()]
        ready = next(e for e in events if e["type"] == "harness_ready")
        self.assertEqual(set(ready["active_tools"]), {"inspect_fixture","axial_solve","submit_solution"})
        self.assertFalse(any(e["type"] == "model_request" for e in events))
        self.assertNotIn("synthetic-test-value",result.stdout)


if __name__ == "__main__":
    unittest.main()
