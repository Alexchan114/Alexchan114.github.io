import asyncio
import json
from pathlib import Path
import tempfile
import unittest
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mechanics_benchmark.native_suite import command, PYTHON, ROOT
from mechanics_benchmark.suite_v2 import definitions, task_cards


class NativeTests(unittest.TestCase):
    def test_commands_do_not_add_file_tools(self):
        for client in ('claude-code', 'codex-native'):
            cmd = command(client, Path('C:/empty-trial'), Path('C:/empty-workspace'))
            text = ' '.join(cmd)
            self.assertNotIn('ANTHROPIC_API_KEY', text)
            if client == 'claude-code':
                self.assertEqual(set(cmd[cmd.index('--tools')+1].split(',')),
                                 {'mcp__mechanics__'+t['name'] for t in definitions()})
                self.assertIn('--bare', cmd)
            else:
                self.assertIn('shell_tool', cmd)
                self.assertIn('--ignore-user-config', cmd)

    def test_real_mcp_catalog_and_evidence(self):
        async def check(folder):
            (folder/'task.json').write_text(json.dumps(task_cards()['S01']))
            (folder/'query.json').write_text(json.dumps(dict(tools=definitions())))
            config = StdioServerParameters(command=PYTHON,
                args=['-m','mechanics_benchmark.native_mcp','--folder',str(folder),
                      '--reference','unused','--solver-root','unused'],env={'PYTHONPATH':str(ROOT)})
            async with stdio_client(config) as (rd,wr):
                async with ClientSession(rd,wr) as session:
                    await session.initialize()
                    tools = await session.list_tools()
                    self.assertEqual({t.name for t in tools.tools},{t['name'] for t in definitions()})
                    for actual, expected in zip(tools.tools, definitions()):
                        self.assertEqual(actual.inputSchema, expected['input_schema'])
                    result = await session.call_tool('experiment', dict(parameters={}))
                    data = json.loads(result.content[0].text)
                    self.assertTrue(data['artifact_id'].startswith('artifact_'))
                    sol = {k:data[k] for k in ('artifact_id','U_mm','reaction_N','energy_Nmm')}
                    await session.call_tool('submit_solution',dict(solution=sol,explanation='offline transport test'))
                    scoring = json.loads((folder/'evaluation.json').read_text())
                    self.assertEqual(scoring['status'],'passed')
                    rejected = await session.call_tool('experiment',dict(parameters={}))
                    self.assertIn('Already submitted', rejected.content[0].text)
        with tempfile.TemporaryDirectory() as tmp:
            asyncio.run(check(Path(tmp)))


if __name__ == '__main__': unittest.main()
