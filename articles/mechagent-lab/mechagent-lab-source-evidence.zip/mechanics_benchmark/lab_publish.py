"""Stage an allowlisted blog release, never the engineering worktree."""
import json
import subprocess
from .lab_delivery import SITE,OUT,secret_values
from .publish_preview import semantic


def git(*args):
    return subprocess.run(['git','-C',str(SITE),*args],capture_output=True,check=True).stdout.decode('utf-8').strip()


def stage():
    if git('remote','get-url','origin')!='https://github.com/Alexchan114/Alexchan114.github.io.git':raise ValueError('Wrong site remote')
    if git('diff','--cached','--name-only'):raise ValueError('Unexpected staged work')
    selected=[]
    for name in git('diff','--name-only').splitlines():
        if name.startswith('site-src/'):raise ValueError('Unexpected tracked source edit '+name)
        old=git('show','HEAD:'+name);new=(SITE/name).read_text(encoding='utf-8')
        if (semantic(old)!=semantic(new)) if name.endswith(('.html','.xml')) else old.strip()!=new.strip():selected.append(name)
    for root in ('articles/mechagent-lab','post/2026/11/05/mechagent-lab','en/post/2026/11/05/mechagent-lab','site-src/static/articles/mechagent-lab'):
        selected += [p.relative_to(SITE).as_posix() for p in (SITE/root).rglob('*') if p.is_file()]
    selected += ['site-src/content/post/mechagent-lab.md','site-src/content/post/mechagent-lab.en.md']
    selected=sorted(set(selected));secrets=secret_values()
    for name in selected:
        if any(s in (SITE/name).read_bytes() for s in secrets):raise ValueError('Credential scan blocked '+name)
    git('add','--',*selected);git('diff','--cached','--check')
    staged=git('diff','--cached','--name-only').splitlines()
    if staged!=selected:raise ValueError('Staged files differ from reviewed selection')
    (OUT/'qa/publish_manifest.json').write_text(json.dumps(dict(files=selected),indent=2),encoding='utf-8')
    print(json.dumps(dict(staged_files=len(selected),files=selected),indent=2))


if __name__=='__main__':stage()
