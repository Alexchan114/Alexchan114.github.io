"""Independent release checks and post-hoc diagnostics, never a score rewrite."""
import hashlib
import json
from pathlib import Path
import zipfile
import numpy as np
from .native_suite import OUT,ROOT
from .security import digest
from .suite_evaluate import evaluate


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))


def verify():
    mapping={'preregistration.json':'frozen_source','amendment_registration.json':'amendment_frozen_source',
        'native_extension_registration.json':'native_extension_frozen_source','codex_transport_registration.json':'codex_transport_frozen_source'}
    registrations={}
    for name,dirname in mapping.items():
        reg=read(OUT/name);registrations[digest(reg)]=reg
        for filename,expected in reg['source_hashes'].items():
            path=OUT/dirname/'mechanics_benchmark'/filename
            if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise ValueError('Frozen source mismatch: '+str(path))
    checked=0;native_jobs={};diagnostics={}
    summary=read(OUT/'summary.json')
    for row in summary['rows']:
        folder=OUT/'pilot'/row['attempt'];m=read(folder/'run.json')
        reg=registrations[m['preregistration_hash']]
        if read(folder/'task.json')!=reg['tasks'][row['task']]:raise ValueError('Trial task differs from registration')
        artifacts={}
        for p in (folder/'artifacts').glob('*.json'):
            a=read(p)
            if p.stem!='artifact_'+digest(a)[:20]:raise ValueError('Artifact identity changed')
            artifacts[p.stem]=a;checked+=1
        if (folder/'submission.json').exists():
            solution=read(folder/'submission.json')['solution']
            actual=evaluate(read(folder/'task.json'),solution,artifacts)
            if actual!=read(folder/'evaluation.json'):raise ValueError('Independent re-evaluation differs')
            if row['task']=='S04' and actual['status']=='passed':
                result=artifacts[solution['artifact_id']]['result'];native_jobs[row['attempt']]=result['jobs']
            if row['task']=='S05' and actual['status']=='failed':
                a=artifacts[solution['artifact_ids'][0]]['result'];expected=np.asarray(a['first_physical_mm'])
                sent=np.asarray(solution['first_MC_physical_mm']);correct_again=np.r_[.15*expected[:42],.3348+.15*expected[42:48],.1*expected[48:]]
                diagnostics[row['attempt']]=dict(kind='physical_mapping',max_abs_error_mm=float(abs(sent-expected).max()),
                    matches_double_conversion=bool(np.allclose(sent,correct_again,atol=1e-12,rtol=0)),scoring_changed=False)
            if row['classification']=='protocol_ambiguity':
                converted=dict(solution,artifact_ids=[solution['artifact_ids']['safe'],solution['artifact_ids']['fail']])
                posthoc=evaluate(read(folder/'task.json'),converted,artifacts)
                diagnostics[row['attempt']]=dict(kind='array_vs_named_object_contract',raw_evaluation=actual,
                    posthoc_endpoint_check=posthoc,scoring_changed=False,no_retry=True)
    for lang in ('zh','en'):
        log=OUT/'publication'/('mechagent_lab_'+lang+'.log')
        if log.exists() and any(word in log.read_text(encoding='utf-8',errors='replace') for word in ('Overfull','Missing character','Undefined control','! LaTeX Error')):
            raise ValueError('PDF layout/glyph problem '+lang)
    archive=OUT/'mechagent-lab-source-evidence.zip'
    if archive.exists():
        with zipfile.ZipFile(archive) as z:
            for name,expected in json.loads(z.read('release_manifest.json')).items():
                if hashlib.sha256(z.read(name)).hexdigest()!=expected:raise ValueError('Archive content differs')
            for regname,dirname in mapping.items():
                reg=json.loads(z.read(regname))
                for name,expected in reg['source_hashes'].items():
                    if hashlib.sha256(z.read(dirname+'/mechanics_benchmark/'+name)).hexdigest()!=expected:
                        raise ValueError('Public frozen source bytes differ: '+name)
    result=dict(passed=True,registrations=len(mapping),retained_records=len(summary['rows']),artifact_hashes=checked,
        independent_evaluations_match=True,native_solver_jobs=native_jobs,posthoc_diagnostics=diagnostics)
    (OUT/'qa/verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


def sheets():
    from PIL import Image,ImageDraw
    for lang in ('zh','en'):
        pages=sorted((OUT/'qa').glob(lang+'-*.png'))
        w,h=430,630;canvas=Image.new('RGB',(3*w,((len(pages)+2)//3)*h),'#e0e5e7');draw=ImageDraw.Draw(canvas)
        for i,p in enumerate(pages):
            im=Image.open(p).convert('RGB');im.thumbnail((w-18,h-30));x,y=(i%3)*w,(i//3)*h
            canvas.paste(im,(x+(w-im.width)//2,y+23));draw.text((x+10,y+5),p.name,fill='#233b49')
        canvas.save(OUT/'qa'/('contact_sheet_'+lang+'.png'))


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--sheets',action='store_true');args=p.parse_args()
    sheets() if args.sheets else verify()
