"""MechAgent Lab public/local delivery; never alters registered trial sources."""
import argparse
from collections import Counter
import csv
import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile
from .native_suite import OUT,ROOT,CONFIGS
from .suite_v2 import task_cards
from .credentials import inventory
from .security import digest

SITE=OUT/'website-publish'
ASSET='/articles/mechagent-lab/'
STEMS=('architecture','tasks','solid','sampling','outcomes','boundary')


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))


def public_text(text):
    text=re.sub(r'org-[A-Za-z0-9<>_-]+','[ACCOUNT REDACTED]',text)
    return text.replace(str(Path.home()),'[USER_HOME]').replace(str(Path.home()).replace('\\','\\\\'),'[USER_HOME]')


def secret_values():
    values=[r.secret for r in inventory() if r.secret]
    for p in (Path.home()/'.codex/auth.json',Path.home()/'.claude/.credentials.json'):
        if not p.exists():continue
        def collect(obj):
            if isinstance(obj,dict):
                for k,v in obj.items():
                    if isinstance(v,str) and re.search('token|key|secret',k,re.I) and len(v)>=8:values.append(v)
                    elif isinstance(v,(dict,list)):collect(v)
            elif isinstance(obj,list):
                for v in obj:collect(v)
        collect(read(p))
    return [v.encode() for v in values]


def events(folder):
    result=[]
    for name in ('trace.jsonl','client_trace.jsonl'):
        p=folder/name
        if p.exists():
            for line in p.read_text(encoding='utf-8').splitlines():
                event=json.loads(line);event['source_stream']=name;result.append(event)
    return sorted(result,key=lambda e:(e['utc'],e['source_stream'],e['index']))


def summarize():
    reg=read(OUT/'codex_transport_registration.json');rows=[]
    for folder in sorted((OUT/'pilot').iterdir()):
        if not (folder/'run.json').exists():continue
        m=read(folder/'run.json')
        if m['status']=='running':raise ValueError('Unresolved trial '+folder.name)
        ev=events(folder);result_events=[e['event'] for e in ev if e['kind']=='native_stdout' and e['event'].get('type')=='result']
        subtype=result_events[-1].get('subtype') if result_events else None
        if folder.name in reg['excluded_setup_attempts'] or m['status']=='adapter_invalid':classification='adapter_invalid'
        elif m['task']=='S04' and any('timed out' in str(e).lower() for e in ev if e['kind']=='native_stdout') and not list((folder/'artifacts').glob('*.json')):classification='environment_or_incomplete'
        elif m.get('evaluation',{} ) and m['evaluation']['status']=='passed':classification='passed'
        elif m['status']=='submitted':classification='failed'
        elif m['status']=='wall_budget_exhausted' or subtype=='error_max_turns' or m.get('model_gateway_blocked')=='model_request_budget_exhausted':classification='budget_exhausted'
        else:classification='environment_or_incomplete'
        protocol_note=None
        if m['status']=='submitted' and m['task']=='S07':
            solution=read(folder/'submission.json')['solution']
            if isinstance(solution.get('artifact_ids'),dict):
                protocol_note='Task descriptor says safe/fail IDs without explicitly requiring an array. Submitted named endpoint object is rejected by the frozen array-indexing validator. Raw grade retained; exclude this formatting-ambiguous cell from capability conclusions.'
                classification='protocol_ambiguity'
        usages=[]
        if result_events:usages=[result_events[-1].get('usage',{})]
        else:usages=[e['event'].get('usage',{}) for e in ev if e['kind']=='native_stdout' and e['event'].get('type')=='turn.completed']
        usage={k:sum(u.get(k,0) for u in usages) if usages else None for k in ('input_tokens','output_tokens','cached_input_tokens')}
        sdk_cost=result_events[-1].get('total_cost_usd') if result_events else None
        raw_score=(m.get('evaluation') or {}).get('score')
        score=None if classification in ('adapter_invalid','protocol_ambiguity','environment_or_incomplete') else (raw_score or 0)
        row=dict(attempt=folder.name,task=m['task'],configuration=m['configuration'],model=m['model'],
            classification=classification,status=m['status'],raw_score=raw_score,score=score,
            elapsed_seconds=m['elapsed_seconds'],tool_calls=m['tool_calls'],solver_tests=m['solver_tests'],
            sdk_estimated_usd=sdk_cost,actual_billed_usd=None,protocol_note=protocol_note,**usage)
        rows.append(row)
    formal=[r for r in rows if r['attempt'] not in reg['excluded_setup_attempts']]
    if len(formal)!=16:raise ValueError('Expected16 resolved registered attempts; found '+str(len(formal)))
    summary=dict(public_name='MechAgent Lab',internal_release='V3',tasks=8,formal_attempts=16,
        retained_records=len(rows),setup_exclusions=len(rows)-len(formal),counts=dict(Counter(r['classification'] for r in formal)),
        capability_valid_attempts=sum(r['classification'] not in ('protocol_ambiguity','environment_or_incomplete','adapter_invalid') for r in formal),
        rows=rows,configurations=CONFIGS,actual_billed_usd=None,
        historical='mini/Kimi and Pi/DeepSeek historical records remain unchanged in the prior release',
        limitation='One attempt per cell; native clients/models/routes and budgets differ; no causal model/harness ranking.')
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    with (OUT/'summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    docs=OUT/'documentation';docs.mkdir(exist_ok=True)
    for lang in ('zh','en'):
        b=['# '+('逐轮输入、输出与工具证据' if lang=='zh' else 'Observable inputs, outputs and tool evidence'),'',
            'Native hidden system/context and private computation are not reconstructed. Separate stream indices are preserved; UTC provides the merged reading order. Every retained attempt is included, including two startup exclusions.','']
        for row in rows:
            folder=OUT/'pilot'/row['attempt'];b+=['## '+row['attempt'],'','### Query','```json',public_text(json.dumps(read(folder/'query.json'),ensure_ascii=False,indent=2)),'```']
            for e in events(folder):b+=['### '+e['source_stream']+' / '+str(e['index'])+' / '+e['kind'],'```json',public_text(json.dumps(e,ensure_ascii=False,indent=2)),'```','']
        (docs/('QUERY_OUTPUTS_'+lang.upper()+'.md')).write_text('\n'.join(b),encoding='utf-8')
    return summary


def figure_data():
    s=read(OUT/'summary.json');cards=task_cards();solid={};pose={}
    for c in CONFIGS:
        row=next(r for r in s['rows'] if r['configuration']==c and r['task']=='S04' and r['classification']!='adapter_invalid')
        folder=OUT/'pilot'/row['attempt'];candidate=Path('D:/kimi/benchmark_public/v03_native_20261105')/folder.name
        if row['classification']=='passed' and (candidate/'curves.json').exists():solid[c]=read(candidate/'curves.json')
        pose_row=next(r for r in s['rows'] if r['configuration']==c and r['task']=='S07' and r['classification']!='adapter_invalid')
        pose[c]=[read(p) for p in (OUT/'pilot'/pose_row['attempt']/'artifacts').glob('*.json')]
    from .suite_physics import sample
    data=dict(summary=s,cards=cards,solid=solid,pose=pose,
        sampling={m:sample(cards['S05']['fixture'],m,cards['S05']['fixture']['seed'])['amplitudes'] for m in ('MC','LHS','Sobol','Halton')},
        provenance=dict(solid='new native-client actual Abaqus ODB extractions',pose='frozen spring law; actual recorded agent experiment markers',sampling='author illustration; not an agent score or method-efficiency experiment'))
    figures=OUT/'figures';figures.mkdir(exist_ok=True)
    (figures/'figure_data.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    shutil.copy2(Path(__file__).with_name('lab_figures.py'),figures/'lab_figures.py')


def tavotto(port):
    import urllib.request
    import urllib.error
    session=Path.home()/'AppData/Local/Tavotto/session'/('port-'+str(port)+'.json')
    secret=read(session)['secret']
    def call(path,value):
        req=urllib.request.Request('http://127.0.0.1:'+str(port)+path,data=json.dumps(value).encode(),
            headers={'X-Tavotto-Auth':secret,'Content-Type':'application/json'})
        try:
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=240) as r:result=json.load(r)
        except urllib.error.HTTPError as error:
            detail=error.read().decode('utf-8',errors='replace')
            (OUT/'qa/tavotto_error.json').write_text(json.dumps(dict(endpoint=path,status=error.code,detail=detail)),encoding='utf-8')
            raise RuntimeError('Tavotto export: '+detail) from error
        if result.get('error'):raise RuntimeError(result['error'])
        return result
    probe=call('/api/registry/probe',dict(script='lab_figures.py',cost='medium'))
    (OUT/'qa/tavotto_probe.json').write_text(json.dumps(probe,indent=2),encoding='utf-8')
    if not probe.get('registered'):raise RuntimeError('Figure source did not register in Tavotto')
    publication=OUT/'publication';publication.mkdir(exist_ok=True)
    for stem in STEMS:
        asset=next(d['asset_id'] for d in probe['descriptors'] if d['stem']==stem)
        receipt=call('/api/export',dict(scope='canvas',filename=stem,formats=['pdf','png'],ppi=180,
            background='white',overwrite='replace',canvas=dict(page_w_mm=254,page_h_mm=152.4,
                objects=[dict(type='panel',id=asset,x_mm=0,y_mm=0,w_mm=254,h_mm=152.4)])))
        (OUT/'qa'/(stem+'_tavotto_receipt.json')).write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        for suffix in ('.pdf','.png'):shutil.copy2(OUT/'figures/tavottofile/export'/(stem+suffix),publication/(stem+suffix))
        print('Actual Tavotto export: '+stem,flush=True)


NARRATIVE={
 'zh':[
 ('为什么把力学放进 Agent 评测',[
  '工程仿真中的难点往往不是把命令写出来，而是在物理假设、数值离散和软件状态之间作出一致的选择。一个能够解释子结构原理的模型，未必能够选择可凝聚的区域；一个能读出接触力的模型，也可能把未到终点的中止算例误判为接触失效。因此，这个实验室把评价对象从“回答是否像工程师”改为“决策能否落到可核验的产物”。',
  'MechAgent Lab 从连接器仿真工作流中抽取八个公开任务：量纲与平衡、网格分配、小板预抬、子结构分区、有界公差、接口复用、偏位偏角边界和批次恢复。题目使用原创公开杆件及简化力学数据，不上传客户模型、合同或工业连接器结果。',
  '本轮新增两个真实原生执行循环：Claude Code 接入既有 DeepSeek 路线，Codex CLI 使用既有 ChatGPT 登录。CLI 是 Command-Line Interface，即命令行界面；CCS 在本文中指本机 CC Switch 配置管理工具，不是模型或 Agent。此前受控 mini/Kimi 与 Pi/DeepSeek 的轨迹仍可阅读，但它们不是本轮相同矩阵上的重跑成绩。框架、模型和服务路线是三个不同的变量，不能因为名字叫 Claude Code 就把成绩归给 Claude 模型。']),
 ('先约定证据，再讨论成绩',[
  '每个 Agent 只能通过三个 MCP 工具读取题目、执行实验和提交结构化答案。MCP 的全称为 Model Context Protocol，中文为模型上下文协议；这里它是工具调用的接口，不是力学求解器本身。工具参数中没有任意脚本、文件路径或终端命令。参考解与判分器由主机持有，不通过工具开放。',
  '原生表示各客户端仍自行完成推理、工具选择和上下文管理，而不是把其模型装进自制循环。Claude Code 关闭无关工具、插件及全局配置发现；Codex 关闭终端、浏览器和其他无关能力，只使用显式配置的力学 MCP。这里声称的是配置约束和可观察工具审计，不是操作系统级的恶意程序隔离。',
  '代码、题面和判分规则在正式调用前冻结并保存 SHA256。每个客户端对每题只保留一次正式尝试；模型失败不追加调参重试。两次 Claude 工具未加载和七次 Codex 握手失败的启动记录完整保留并单列排除，已经有效的 Codex 第一题及全部 Claude 正式记录不重跑。连接修正只涉及接入层，没有修改力学题面或答案。',
  '预算也必须公开：每题最多 24 次受控工具调用和 360 秒墙钟时间，子结构题最多一次候选实际求解。Claude 另有限定的原生轮次及模型请求输出上限；Codex 未声称有相同的输出 token 硬上限。不同默认系统指令和预算意味着，本轮可以描述发生了什么，但不能据此推出纯粹的模型或框架因果排名。']),
 ('八道题如何检查力学而不是措辞',[
  'S01 采用串联轴向杆，要求先把 GPa 转成 MPa，再独立核对端位移、根部反力和应变能。有限元法的英文全称为 Finite Element Method，简称 FEM。评分不仅看最终数字，还检查数字是否对应真实执行过的工具产物。',
  'S02 使用截面积随位置变化的杆件。Agent 需要选满足端位移误差限值的最少单元数，而不是无条件使用最细网格。独立参考来自连续体柔度积分，离散模型则使用单元中点面积。该设计将准确性和计算资源选择联系起来。',
  'S03 将六块小板建成六个独立控制量，每块影响两对单边接触。抬升在名义值上叠加，目标为所有法向力不低于 0.4 N，同时使幅值平方和最小。单边弹簧在分离时返回零法向力，因此不能用摩擦力来补足接触阈值。该题是可独立核验的简化接触题，而不是三维摩擦接触仿真。',
  'S04 才是本轮真实商业求解器题。原创三维杆件一半为线弹性材料，另一半为 J2 弹塑性材料。Agent 在候选截面中选择可凝聚区域，保留根部和接口的三向平移，并实际生成子结构、装配求解、提取 ODB 数据。ODB 的全称为 Output Database，中文为结果数据库。',
  'S05 生成 72 维公差样本，包括 42 个 Z 向形状变量、6 个小板预抬和 24 个公端子 X/Y 局部平移。MC 是 Monte Carlo（蒙特卡洛），LHS 是 Latin Hypercube Sampling（拉丁超立方抽样），Sobol 与 Halton 是低差异序列。四种方法先生成单位超立方体样本，再用截断标准正态的逆累积分布映射到 [-1,1]，而不是把超界正态数裁剪到端点。',
  '物理映射不能混淆：形状变化为 0.15a mm，小板预抬为 0.3348+0.15a mm，公端子的刚体局部平移为 0.1a mm。局部制造偏移不移动子结构，也不改变端子尺寸；整套公端相对母端的装配偏位是另一种姿态变量。',
  'S06 同时检查子结构库身份和 Tie 接口覆盖。CORE 指仍以完整有限元描述的区域，SUB 指凝聚为子结构的区域；二者不是特定软件实体名称。只有拓扑、材料和保留节点坐标都一致的库才能复用。Tie 位置容差只扩大几何搜索范围，不能修复错误材料或错误网格；关闭节点调整，才能避免把制造偏移吸回原位置。',
  'S07 沿指定的偏位偏角耦合路径寻找首个失效边界。每次实验计算 12 对法向力，取最小值与 0.4 N 比较；最终需要实测安全端与失效端两个产物，而不是只给一个看似收敛的角度。这个题目使用刚体杠杆与单边弹簧，不把其数值当成工业连接器极限。',
  'S08 聚焦容易被忽视的工程可信性。只有求解成功、达到最终位移且 12 个通道完整的 case 才进入排名；case 指一组输入及其对应结果。对每个有效 case 先取绝对法向力的最小值，再按该值升序排序。物理接触失效的已完成算例不重算；活动任务等待，缺通道只重提取，中断任务重算，负体积输入先修网格。']),
 ('真正运行子结构：少保留哪些自由度',[
  '三维公开杆件尺寸为 12×2×2 mm，共 117 个节点和 48 个 C3D8 单元。可线性凝聚的范围不能跨入可能塑性的区域。消去内部自由度后，界面刚度由 Schur 补得到；DOF 是 Degree of Freedom，即自由度。最大安全截面为 6 mm，消去 135 个内部平移自由度。',
  '完整模型先独立求解，Agent 不能读取该参考。它提交分区后，主机工具通过真实 Abaqus/MCP 生成 SIM 子结构库、进行降阶装配并求解，再将存储帧反力曲线与完整模型比较。微型算例用于证明执行和等价性，不用于宣称工业级加速比。图中曲线来自本轮成功的 Claude Code/DeepSeek 实际提取，不是理论曲线替代软件计算。',
  'Codex 同样选出 6 mm 截面和 135 个可消去自由度，但实际工具在 240 秒内未返回产物；再次调用被单候选预算拒绝。它明确提交空产物编号而没有捏造求解成功。其独立后台求解随后完成，但没有在尝试结束前返回给模型，也没有完成该次曲线提取核验。原始验收零分保留，单列为工具超时／证据未完成；后台迟到的成功不能补算 Agent 通过，也不替它画一条已验证曲线。']),
 ('怎样阅读结果和失败',[
  '结果矩阵的每个格子对应一个已冻结的“题目×原生客户端”组合。通过必须同时满足独立数值检查和产物引用；预算耗尽、没有提交、服务错误和接入失败分别记录。不能因为工具文本写着成功，就把未完成求解当成证据。',
  '耗时包含客户端启动、模型等待和实际工具执行，S04 还包含真实商业求解器阶段。它不是纯模型推理速度，也不是求解器加速比。费用字段同样区分 SDK 估算与真实账单；第三方路线的 SDK 美元估算不一定对应实际收费，未知账单保持为空。',
  '失败轨迹比单一通过率更能说明工程问题：正确推导但未提交是闭环失败，完整数据映射错误是物理语义失败，服务限流是环境问题，MCP 未加载是接入问题。本轮不通过追加尝试掩盖这些差异。',
  'Claude 的 S07 找到了安全端 1.223 和失效端 1.224，却以含 safe/fail 键的对象提交产物，而冻结判分器按数组读取。题面没有显式限定这一字段为数组，因此原始零分保留，并将该格标为协议歧义，不解释为接触力边界判断错误。它没有获得追加尝试或事后满分。']),
 ('复现：从一条工具调用追到一份产物',[
  '下载包包含题卡、冻结源码、四份连续注册记录、所有保留尝试、逐轮输入输出附录、独立判分、原创公开 INP、实际 MCP 任务标识、绘图源数据以及 Tavotto 导出回执。所有图均在实际 Tavotto 中执行、注册并导出为矢量 PDF 和 PNG。正文由 LaTeX 编译，中英文各保留一份。',
  '复现前先运行离线测试和本地假服务的工具加载检查，再配置自己的 API 或原生登录、MCP 环境及商业软件许可证。不要把密钥写入题目或上传 CCS 数据库。注册完成后不修改题面、工具和判分器；若需要改变协议，应另建记录并保留旧证据。',
  '这个基准的下一步不是把八道题都包装成商业软件任务，而是逐步增加真正需要三维接触、网格质量和路径依赖的公开算例，并建立重复、交叉配置和费用受控的研究设计。在此之前，清楚说明证据来自哪里，比给出一个漂亮排行榜更重要。'])],
 'en':[
 ('Why put mechanics in an agent benchmark?',[
  'Engineering simulation is not primarily a command-generation problem. It requires consistent decisions across physical assumptions, discretization and software state. An agent may explain substructuring yet choose a nonlinear region for condensation, or read a small contact force from an aborted case and call it physical failure. MechAgent Lab therefore evaluates inspectable decisions and artifacts, not engineer-like prose.',
  'Eight public tasks cover units and equilibrium, mesh allocation, independent prelift, substructure partitioning, bounded tolerances, interface reuse, coupled pose boundaries and batch recovery. Original public solids and reduced-physics fixtures replace client geometry, contracts and industrial results.',
  'This extension adds actual Claude Code and Codex Command-Line Interface (CLI) loops. Claude Code uses an existing DeepSeek route; Codex uses an existing ChatGPT login. CCS here refers to the local CC Switch configuration manager, not a model or agent. Earlier controlled-mini/Kimi and Pi/DeepSeek traces remain historical evidence, not matched reruns. A harness name does not identify the underlying model.']),
 ('Agree on evidence before reading scores',[
  'Each agent receives exactly three mechanics capabilities: inspect a fixture, execute an experiment and submit a structured solution. Model Context Protocol (MCP) is the invocation interface, not the solver. Tool arguments expose no arbitrary scripts, paths or terminal commands. Reference solutions and validators stay with the host.',
  'Native means the installed client still owns reasoning, tool selection and context management; no custom inference loop impersonates it. Unrelated Claude tools/plugins and Codex shell/browser capabilities are disabled. This is configuration control plus observable tool auditing, not an operating-system isolation claim.',
  'Task text, execution sources and validators are hashed before formal calls. Each client gets one formal attempt per task. Two Claude starts without tools and seven Codex handshake failures remain as startup exclusions. The valid Codex first task and completed Claude outcomes are not repeated. Transport amendments change the adapter, not physics or scoring.',
  'Every task has at most 24 broker calls and 360 seconds wall time; the partition task permits one native candidate. Claude also has native-turn/request-output limits. Codex does not claim the same hard output-token cap. Different models, native instructions and budgets prevent a causal harness or model ranking.']),
 ('Eight tasks that test mechanics rather than wording',[
  'S01 uses axial bars in series. The agent converts GPa to MPa and checks tip displacement, root reaction and strain energy. Finite Element Method (FEM) results must cite an executed artifact; plausible numbers alone are insufficient.',
  'S02 varies cross-sectional area with position. The objective is the smallest allowed mesh meeting a tip-displacement error bound, not the finest mesh. The independent reference is a continuum compliance integral, whereas elements use midpoint area.',
  'S03 gives six plates six independent controls, each influencing two unilateral contacts. Minimize squared amplitudes while all final normal forces reach 0.4 N. Prelift adds to a nominal displacement; separation produces zero normal force, and friction cannot make up a normal-force deficit. This is a reduced spring model, not a 3D frictional-contact solve.',
  'S04 is the actual commercial-solver task. An original 3D bar has linear-elastic and J2-plastic halves. The agent selects a condensation cut, retains root/interface translations, and executes generation, reduced assembly and Output Database (ODB) extraction through Abaqus/MCP.',
  'S05 samples 72 variables: 42 Z-shape changes, six independent prelifts and 24 local male-terminal X/Y translations. Monte Carlo (MC), Latin Hypercube Sampling (LHS), Sobol and Halton first sample the unit cube, then apply the inverse standard-normal CDF conditioned on [-1,1]. Conditioning is not endpoint clipping.',
  'The physical maps are 0.15a mm for shape change, 0.3348+0.15a mm for prelift, and 0.1a mm for rigid local translation. Local manufacturing offsets preserve terminal dimensions and do not move the substructure. Whole-male assembly pose is a different variable.',
  'S06 checks both library identity and Tie coverage. CORE denotes explicitly represented finite elements; SUB denotes the condensed region. Reuse requires matching topology, material and retained-node coordinates. A search tolerance cannot repair a wrong material or mesh, and disabling adjustment prevents the Tie from pulling a manufacturing offset back to nominal.',
  'S07 finds first contact loss along a prescribed coupled offset/angle path. Each experiment returns twelve normal forces; the minimum is compared with 0.4 N. Two actual artifacts must prove a safe/failing bracket. The lever-arm/unilateral-spring numbers are not industrial connector limits.',
  'S08 tests evidence reliability and recovery. Rank only completed cases at final displacement with all twelve channels, then sort by minimum absolute normal force. A case is one input/output instance. Completed physical failures stay done; active jobs wait, missing channels require re-extraction, interrupted jobs require re-solving, and negative-volume input requires mesh repair.']),
 ('An actual substructure decision',[
  'The public 12 by 2 by 2 mm solid has 117 nodes and 48 C3D8 elements. Condensation cannot extend into potentially plastic material. A Schur complement eliminates internal Degrees of Freedom (DOFs). The maximal safe cut at 6 mm eliminates 135 internal translations.',
  'An independent full solve precedes agent execution and is not visible through its tools. Actual Abaqus/MCP generates a SIM library, assembles/solves the reduced model and compares stored-frame reactions. This tiny model establishes execution and equivalence, not an industrial speedup. The plotted curves come from the successful Claude Code/DeepSeek extraction, not a theoretical substitute.',
  'Codex also chose the 6 mm cut and 135 eliminated DOFs, but its actual tool returned no artifact within 240 seconds; another candidate request was denied by the one-candidate budget. It submitted an empty artifact ID rather than invent solver success. Its independently scheduled solve later finished, but returned neither an agent-observed artifact before the deadline nor an extracted/checked curve for this attempt. The raw zero remains a tool-timeout/incomplete-evidence outcome; late host success does not retroactively pass the agent. No validated Codex curve is invented.']),
 ('Read failures as engineering evidence',[
  'Each matrix cell is a frozen task/client combination. Passing requires independent checks and artifact references. Budget exhaustion, missing submission, service error and adapter failure remain distinct. A success-shaped tool message cannot prove a completed solver run.',
  'Elapsed time includes client startup, model waiting and tools; S04 includes commercial-solver work. It is neither pure inference latency nor a solver speedup. SDK dollar estimates are separate from invoices and may be inappropriate for a third-party route; unknown actual billing stays null.',
  'A correct derivation without submission is a workflow failure. A wrong physical mapping is a semantics failure. Rate limits are environmental, and absent MCP tools are an adapter problem. We retain these distinctions instead of retrying until a clean table appears.',
  'Claude S07 found safe/failing endpoints 1.223 and 1.224 but submitted artifact IDs as an object with safe/fail keys. The frozen validator indexes an array, while the task did not explicitly require that type. Its raw zero stays in the evidence, but this cell is labeled protocol ambiguity rather than a mechanics-boundary error. No extra attempt or retroactive full score is awarded.']),
 ('Reproduce a decision from its evidence',[
  'The archive contains task cards, frozen sources, linked registrations, all retained attempts, complete observable-query appendices, independent scores, original public INP decks, actual MCP job identities, figure data and Tavotto receipts. Every figure is executed/registered/exported in actual Tavotto as PDF and PNG. Both reading editions are compiled from LaTeX.',
  'Start with offline tests and local-mock tool checks. Then configure your own API/native login, MCP installation and commercial-software license. Never put keys in tasks or upload the CCS database. After registration, do not silently alter prompts, tools or validators; amend with preserved history.',
  'Future work should add public problems genuinely requiring 3D contact, mesh quality and path dependence, followed by repeated crossed configurations and explicit spending controls. Until then, evidence provenance is more useful than a polished leaderboard.'])]
}


CAPTIONS={
 'zh':['模型、原生框架、受控工具和主机判分分层；mini 与 Pi 为历史路线。','八题的决策对象及证据层级，只有 S04 调用真实 Abaqus。','本轮原生 Agent 的实际完整／降阶反力曲线与公开分区。','四种有界抽样的代表变量示意；16 个样本不用于比较统计效率。','逐题状态及墙钟耗时；不同模型、路线和预算不能作因果排名。','S07 简化力学路径与实际 Agent 实验点；曲线不是工业连接器预测。'],
 'en':['Model, native harness, finite tools and host scoring; mini/Pi are historical routes.','Eight decisions and evidence tiers; only S04 uses actual Abaqus.','Actual full/reduced reaction curves and the public partition from this native campaign.','One representative bounded marginal per sampler; sixteen samples do not establish efficiency.','Task outcomes and wall time; different models/routes/budgets prevent causal ranking.','S07 reduced-physics path and actual agent experiments; not an industrial connector prediction.']}


def tex(s):
    return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}'}.get(c,c) for c in str(s))


def documents():
    s=read(OUT/'summary.json');pub=OUT/'publication';pub.mkdir(exist_ok=True)
    for lang in ('zh','en'):
        zh=lang=='zh';b=[r'\documentclass[11pt,a4paper]{ctexart}',r'\usepackage[margin=23mm,headheight=14pt]{geometry}',
            r'\usepackage{amsmath,amssymb,graphicx,booktabs,tabularx,longtable,xcolor,fancyhdr,caption,float,placeins}',
            r'\usepackage[hidelinks,unicode]{hyperref}',r'\setmainfont{TeX Gyre Pagella}',r'\setsansfont{TeX Gyre Heros}',r'\setmonofont{Consolas}[Scale=.8]',
            r'\definecolor{Ink}{HTML}{203746}\definecolor{Teal}{HTML}{197B77}',
            r'\ctexset{section={format=\Large\bfseries\color{Ink}}}',r'\setlength{\parskip}{.4em}\setlength{\emergencystretch}{3em}',
            r'\captionsetup{font=small,labelfont=bf}',r'\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small MechAgent Lab}\fancyhead[R]{\small AlexanderChan}\fancyfoot[C]{\thepage}',
            r'\newcommand{\labfig}[2]{\begin{figure}[htbp]\centering\includegraphics[width=\linewidth]{#1.pdf}\caption{#2}\end{figure}}',
            r'\begin{document}\thispagestyle{empty}',r'{\sffamily\color{Teal}ENGINEERING FIELD NOTES / 2026.11.05}\par\vspace{1em}',
            r'{\Huge\bfseries\color{Ink}MechAgent Lab}\par\vspace{.5em}',
            r'{\LARGE '+('力学在环的 Agent 评测' if zh else 'Mechanics in the Loop')+r'}\par\vspace{1em}',
            ('从一项力学决策，到原生 Agent、实际求解和可审计产物。' if zh else 'From mechanics decisions to native agents, actual solves and auditable artifacts.'),
            r'\par AlexanderChan / 2026-11-05\par\vspace{1em}',
            ('八道公开题，两个原生客户端，16 次正式尝试。Claude Code 使用 DeepSeek；Codex 使用既有 ChatGPT 登录。只在 S04 运行实际商业求解器，其余题为明确标注的简化力学或工程证据算例。' if zh else 'Eight public tasks, two native clients and sixteen formal attempts. Claude Code uses DeepSeek; Codex uses an existing ChatGPT login. Only S04 executes a commercial solver; other tasks explicitly use reduced physics or engineering evidence.'),
            r'\tableofcontents\newpage']
        if not zh:
            b.insert(b.index(r'\begin{document}\thispagestyle{empty}')+1,r'\renewcommand{\contentsname}{Contents}\renewcommand{\figurename}{Figure}')
        for i,(title,paras) in enumerate(NARRATIVE[lang]):
            b += [r'\section{'+title+'}']
            for p in paras:b += [tex(p),r'\par']
            if i==0:b += [r'\labfig{architecture}{'+CAPTIONS[lang][0]+'}']
            if i==2:
                b += [r'\labfig{tasks}{'+CAPTIONS[lang][1]+'}',r'\[u=F\sum_i\frac{L_i}{E_iA_i},\quad R=-F,\quad W=\tfrac12Fu\]',
                    r'\[a=\Phi^{-1}\!\left[\Phi(-1)+u\bigl(\Phi(1)-\Phi(-1)\bigr)\right],\quad u\in(0,1)\]',
                    r'\labfig{sampling}{'+CAPTIONS[lang][3]+'}',r'\[g(\lambda)=\min_{j=1,\ldots,12}N_j(\lambda)-0.4\;\mathrm{N}\]',
                    r'\labfig{boundary}{'+CAPTIONS[lang][5]+'}']
            if i==3:b += [r'\[K_c=K_{bb}-K_{bi}K_{ii}^{-1}K_{ib}\]',r'\labfig{solid}{'+CAPTIONS[lang][2]+'}']
            if i==4:
                counts=s['counts'];b += [tex((f"正式尝试中，通过 {counts.get('passed',0)} 次，数值／语义未通过 {counts.get('failed',0)} 次，预算耗尽 {counts.get('budget_exhausted',0)} 次，环境或未完成 {counts.get('environment_or_incomplete',0)} 次，协议歧义 {counts.get('protocol_ambiguity',0)} 次。另保留 {s['setup_exclusions']} 次接入排除。" if zh else f"Formal attempts: {counts.get('passed',0)} passed, {counts.get('failed',0)} failed, {counts.get('budget_exhausted',0)} budget-exhausted, {counts.get('environment_or_incomplete',0)} environmental/incomplete and {counts.get('protocol_ambiguity',0)} protocol-ambiguous. Another {s['setup_exclusions']} startup exclusions remain.")),
                    r'\labfig{outcomes}{'+CAPTIONS[lang][4]+'}',r'\begin{longtable}{llrrl}\toprule Task & Client & s & Tools & Outcome\\\midrule\endhead']
                for r in s['rows']:
                    client='CC' if r['configuration']=='claude-code' else 'Codex'
                    status={'passed':'Pass','failed':'Fail','adapter_invalid':'Setup excluded','budget_exhausted':'Budget','environment_or_incomplete':'Incomplete','protocol_ambiguity':'Contract excluded'}[r['classification']]
                    b += [f"{r['task']} & {client} & {r['elapsed_seconds']:.1f} & {r['tool_calls']} & {status} "+r'\\']
                b += [r'\bottomrule\end{longtable}']
        b += [r'\section{'+('资料与实现依据' if zh else 'References and implementation')+'}',
            r'\url{https://learn.chatgpt.com/docs/non-interactive-mode}\par',r'\url{https://code.claude.com/docs/en/headless}\par',
            r'\url{https://alexchan114.github.io/post/2026/11/04/mechanics-benchmark-v02/}\par',r'\end{document}']
        (pub/('mechagent_lab_'+lang+'.tex')).write_text('\n\n'.join(b),encoding='utf-8')
        readme=['# MechAgent Lab','',('本地归档版本：V3。公开名称不带版本号。' if zh else 'Local archive: V3. Public-facing title has no version suffix.'),'',
            ('正文：publication/mechagent_lab_zh.pdf；英文：publication/mechagent_lab_en.pdf。' if zh else 'Reading editions: publication/mechagent_lab_zh.pdf and mechagent_lab_en.pdf.'),'',
            'Claude Code: DeepSeek deepseek-v4-flash, existing CCS Anthropic route. Codex CLI: gpt-6.1-sol, existing ChatGPT login. Native model internals are not inferred. No purchases; actual invoices unknown.','',
            'Offline: python -m unittest discover -s mechanics_benchmark/tests -v','',
            'Native local startup mock: python -m mechanics_benchmark.native_probe','',
            'Frozen campaign: python -m mechanics_benchmark.native_suite remaining','',
            'Original absolute paths in native_suite.py describe the author environment. Set your own OUT/PYTHON/REFERENCE/SOLVER_ROOT and exact credential routes before a NEW registration. Never overwrite an executed registry. Original commercial software/MCP/credentials are not bundled.','',
            'All retained attempts, including nine adapter-invalid startup records, are in pilot/. Complete observable event appendices: documentation/QUERY_OUTPUTS_ZH.md and QUERY_OUTPUTS_EN.md. Hidden native prompts/computation are not reconstructed.','',
            'Every figure: figures/lab_figures.py + figure_data.json + qa/*_tavotto_receipt.json. Final published figures come from Tavotto exports.','',
            'Only S04 executes actual Abaqus. Seven other tasks are reduced physics/evidence fixtures. No industrial model or APP is changed. Different native models/routes/budgets prevent causal rankings.']
        (OUT/('README_'+lang.upper()+'.md')).write_text('\n'.join(readme),encoding='utf-8')


def website():
    s=read(OUT/'summary.json');static=SITE/'site-src/static/articles/mechagent-lab';static.mkdir(parents=True,exist_ok=True)
    for p in (OUT/'publication').iterdir():
        if p.suffix in ('.pdf','.png','.tex'):shutil.copy2(p,static/p.name)
    for name in ('summary.json','summary.csv','native_extension_registration.json','codex_transport_registration.json','mechagent-lab-source-evidence.zip'):
        shutil.copy2(OUT/name,static/name)
    for lang in ('zh','en'):
        zh=lang=='zh';title='MechAgent Lab｜力学在环的 Agent 评测' if zh else 'MechAgent Lab: Mechanics in the Loop'
        b=['---','title: '+json.dumps(title,ensure_ascii=False),'date: 2026-11-05T01:00:00+08:00','slug: "mechagent-lab"','author: "AlexanderChan"',
            'description: '+json.dumps('让原生 Agent 做力学决策：Claude Code、Codex、受控 MCP、实际子结构与可审计证据。' if zh else 'Native agents make mechanics decisions: Claude Code, Codex, finite MCP, actual substructures and auditable evidence.',ensure_ascii=False),
            'categories: ["Engineering"]','tags: ["Mechanics", "Agent", "Benchmark", "MCP"]','connector_article: true','---',
            '<article class="cae-article">','<p class="article-downloads">'+f'<a href="{ASSET}mechagent_lab_zh.pdf">中文 PDF</a> · <a href="{ASSET}mechagent_lab_en.pdf">English PDF</a> · <a href="{ASSET}mechagent-lab-source-evidence.zip">'+('源码与完整证据' if zh else 'Source and evidence')+'</a></p>',
            '<p><strong>'+('8 道题 · 2 个新增原生客户端 · 16 次正式尝试 · 所有配图由 Tavotto 导出' if zh else '8 tasks · 2 added native clients · 16 formal attempts · every figure exported by Tavotto')+'</strong></p>',
            '<details class="article-toc"><summary>'+('文章目录' if zh else 'On this page')+'</summary><ol>'+''.join(f'<li><a href="#lab-{i}">{html.escape(h)}</a></li>' for i,(h,_) in enumerate(NARRATIVE[lang]))+'</ol></details>']
        def fig(stem):
            cap=CAPTIONS[lang][STEMS.index(stem)]
            return f'<figure><a href="{ASSET}{stem}.pdf"><img src="{ASSET}{stem}.png" alt="{html.escape(cap)}" loading="lazy" width="1800" height="1080" style="width:100%;height:auto"></a><figcaption>{html.escape(cap)}</figcaption></figure>'
        for i,(heading,paras) in enumerate(NARRATIVE[lang]):
            b+=[f'<h2 id="lab-{i}">'+heading+'</h2>']+['<p>'+html.escape(p)+'</p>' for p in paras]
            if i==0:b+=[fig('architecture')]
            if i==1:
                b+=['<div class="table-scroll"><table><thead><tr><th>Harness</th><th>Model / Route</th><th>'+('证据位置' if zh else 'Evidence')+'</th></tr></thead><tbody>',
                    '<tr><td>Controlled mini</td><td>Kimi kimi-k2.6</td><td>'+('历史冻结试跑' if zh else 'Historical frozen pilot')+'</td></tr>',
                    '<tr><td>Pi SDK</td><td>DeepSeek deepseek-v4-flash</td><td>'+('历史冻结试跑' if zh else 'Historical frozen pilot')+'</td></tr>',
                    '<tr><td>Claude Code 2.1.154</td><td>DeepSeek deepseek-v4-flash / CCS</td><td>'+('本轮八题' if zh else 'Eight tasks in this campaign')+'</td></tr>',
                    '<tr><td>Codex CLI 0.166.0-alpha.5.1</td><td>gpt-6.1-sol / ChatGPT login</td><td>'+('本轮八题' if zh else 'Eight tasks in this campaign')+'</td></tr></tbody></table></div>']
            if i==2:b += [fig('tasks'),fig('sampling'),fig('boundary')]
            if i==3:b += ['<math display="block" xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>K</mi><mi>c</mi></msub><mo>=</mo><msub><mi>K</mi><mrow><mi>b</mi><mi>b</mi></mrow></msub><mo>−</mo><msub><mi>K</mi><mrow><mi>b</mi><mi>i</mi></mrow></msub><msubsup><mi>K</mi><mrow><mi>i</mi><mi>i</mi></mrow><mrow><mo>−</mo><mn>1</mn></mrow></msubsup><msub><mi>K</mi><mrow><mi>i</mi><mi>b</mi></mrow></msub></math>',fig('solid')]
            if i==4:
                counts=s['counts']
                b += ['<p>'+('16 次正式尝试中，12 次通过，1 次物理映射未通过，1 次预算耗尽，1 次工具证据未完成，1 次协议歧义；另保留 9 次接入排除记录。' if zh else 'The sixteen formal attempts comprise twelve passes, one physical-mapping failure, one budget exhaustion, one incomplete tool-evidence outcome and one protocol ambiguity. Nine additional startup exclusions are retained.')+'</p>',
                    fig('outcomes'),'<details class="article-toc"><summary>'+('查看全部 25 条尝试记录（含接入排除）' if zh else 'View all 25 retained attempts, including startup exclusions')+'</summary>',
                    '<div class="table-scroll"><table><thead><tr><th>Attempt</th><th>Client</th><th>State</th><th>s</th><th>Tools</th></tr></thead><tbody>']
                for r in s['rows']:b += [f"<tr><td>{r['attempt']}</td><td>{r['configuration']}</td><td>{r['classification']}</td><td>{r['elapsed_seconds']:.1f}</td><td>{r['tool_calls']}</td></tr>"]
                b += ['</tbody></table></div></details>']
        b += ['<h2>'+('延伸阅读与可检查文件' if zh else 'Further reading and inspectable files')+'</h2>',
            '<p><a href="https://learn.chatgpt.com/docs/non-interactive-mode">Codex non-interactive execution</a> · <a href="https://code.claude.com/docs/en/headless">Claude Code programmatic execution</a> · <a href="/post/2026/11/04/mechanics-benchmark-v02/">'+('历史 mini / Pi 记录' if zh else 'Historical mini / Pi records')+'</a></p>',
            f'<p><a href="{ASSET}summary.csv">CSV</a> · <a href="{ASSET}summary.json">JSON</a> · <a href="{ASSET}native_extension_registration.json">'+('冻结注册' if zh else 'Frozen registration')+'</a></p>','</article>']
        target=SITE/'site-src/content/post'/('mechagent-lab'+('.en' if not zh else '')+'.md')
        target.write_text('\n'.join(b),encoding='utf-8')


def bundle():
    entries={}
    for p in (ROOT/'mechanics_benchmark').rglob('*'):
        if p.is_file() and p.suffix in ('.py','.mjs','.md','.txt') and '__pycache__' not in p.parts:entries['mechanics_benchmark/'+p.relative_to(ROOT/'mechanics_benchmark').as_posix()]=p
    for dirname in ('pilot','frozen_source','amendment_frozen_source','native_extension_frozen_source','codex_transport_frozen_source','documentation','figures','publication','qa'):
        for p in (OUT/dirname).rglob('*'):
            if p.is_file() and p.suffix in ('.json','.jsonl','.py','.mjs','.txt','.md','.tex','.pdf','.png') and '__pycache__' not in p.parts and p.name not in ('release_audit.json',):
                entries[p.relative_to(OUT).as_posix()]=p
    for name in ('preregistration.json','amendment_registration.json','native_extension_registration.json','codex_transport_registration.json','summary.csv','summary.json','README_ZH.md','README_EN.md'):entries[name]=OUT/name
    summary=read(OUT/'summary.json')
    solids=[(r['configuration'],Path('D:/kimi/benchmark_public/v03_native_20261105')/r['attempt']) for r in summary['rows'] if r['task']=='S04' and r['solver_tests']]
    for tag,folder in [('reference',Path('D:/kimi/benchmark_public/solid_20261104_03'))]+solids:
        for name in ('full.inp','generation.inp','reduced.inp','curves.json','progress.json','candidate_result.json','validation.json','mcp_trace.jsonl'):
            p=folder/name
            if p.is_file():entries['public_solid/'+tag+'/'+name]=p
    known=secret_values()
    manifest={};archive=OUT/'mechagent-lab-source-evidence.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for name,p in sorted(entries.items()):
            data=p.read_bytes()
            if p.suffix not in ('.pdf','.png'):data=public_text(data.decode('utf-8-sig')).encode()
            if any(k in data for k in known):raise ValueError('Credential scan blocked '+name)
            manifest[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
        z.writestr('release_manifest.json',json.dumps(manifest,indent=2))
    receipt=dict(passed=True,files=len(entries),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
        bytes=archive.stat().st_size,private_engineering_files=False,credentials_included=False,
        credential_scan='exact CCS secret values; public account/user-home redaction; no auth files or native session stores included')
    (OUT/'qa/release_audit.json').write_text(json.dumps(receipt,indent=2));print(receipt)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['summary','figure-data','tavotto','documents','bundle','website']);p.add_argument('--port',type=int,default=26905);a=p.parse_args()
    {'summary':summarize,'figure-data':figure_data,'documents':documents,'bundle':bundle,'website':website,'tavotto':lambda:tavotto(a.port)}[a.command]()
