"""Real CLI startup against a local mock: no model or solver charge."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile
from .native_suite import command,OUT,ROOT
from .native_host import Host,serve_host
from .security import Trace
from .suite_v2 import task_cards,definitions


def probe():
    records=[]
    for attempt in range(3):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);host=Host(task_cards()['S01'],Trace(folder),None,None)
            def mock(body):
                host.actual_tools.append([t.get('name') for t in body.get('tools',[])])
                return 200,dict(id='offline_mock',type='message',role='assistant',model='offline-mock',
                    content=[dict(type='text',text='Offline transport only')],stop_reason='end_turn',
                    usage=dict(input_tokens=1,output_tokens=1)),'application/json'
            host.infer=mock;host.route=True
            with serve_host(host) as base:
                env=os.environ.copy();env.pop('CLAUDECODE',None);env.pop('ANTHROPIC_AUTH_TOKEN',None)
                env.update(PYTHONPATH=str(ROOT),MECH_BROKER_URL=base+'/broker',MECH_BROKER_TOKEN=host.token,
                    ANTHROPIC_API_KEY=host.token,ANTHROPIC_BASE_URL=base,ENABLE_TOOL_SEARCH='false',
                    CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC='1')
                proc=subprocess.run(command('claude-code',folder,folder),input='Offline startup check only.',
                    capture_output=True,text=True,encoding='utf-8',errors='replace',env=env,cwd=folder,timeout=40,
                    creationflags=subprocess.CREATE_NO_WINDOW)
            expected={'mcp__mechanics__'+r['name'] for r in definitions()}
            ok=bool(host.actual_tools) and all(set(t)==expected for t in host.actual_tools)
            record=dict(probe=attempt,passed=ok,model_request_tools=host.actual_tools,returncode=proc.returncode,
                stdout=proc.stdout,stderr=proc.stderr,inference_forwarded=False,solver_submitted=False)
            record['host_events']=(folder/'trace.jsonl').read_text(encoding='utf-8')
            records.append(record)
            if not ok:break
    (OUT/'qa/verified_native_startup.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    print(json.dumps([dict(probe=r['probe'],passed=r['passed'],tools=r['model_request_tools']) for r in records],indent=2))
    if not all(r['passed'] for r in records):raise RuntimeError('Native startup did not expose the exact three tools')


if __name__=='__main__':probe()
