"""Original technical-blog panels; execute/register/export with actual Tavotto."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Rectangle

ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'figure_data.json').read_text(encoding='utf-8'))
INK,TEAL,RUST,GRAY,PAPER='#233b49','#117f7d','#b75a36','#7a8790','#faf9f5'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'text.color':INK,'axes.labelcolor':INK,
    'axes.edgecolor':GRAY,'xtick.color':GRAY,'ytick.color':GRAY,'axes.spines.top':False,'axes.spines.right':False,
    'pdf.fonttype':42,'savefig.facecolor':'white'})


def save(fig,name):
    fig.set_size_inches(10,6);fig.savefig(ROOT/(name+'.pdf'));plt.close(fig)


def heading(fig,index,title,subtitle):
    fig.text(.055,.945,index+' / '+title,color=INK,fontsize=15,weight='bold')
    fig.text(.055,.898,subtitle,color=GRAY,fontsize=9)


def box(ax,x,y,w,h,title,body,color=TEAL):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.012,rounding_size=.01',ec=color,fc=color+'0b',lw=1.1))
    ax.text(x+.017,y+h-.045,title,fontsize=10,color=color,weight='bold',va='top')
    ax.text(x+.017,y+h-.11,body,fontsize=9,va='top',linespacing=1.5)


fig,ax=plt.subplots();ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1));fig.subplots_adjust(left=.04,right=.98,bottom=.08,top=.83)
heading(fig,'01','A DECISION MUST REACH AN ARTIFACT','Native loops remain native. The host owns physics, evidence and scoring.')
box(ax,.03,.47,.27,.43,'NATIVE AGENTS','Claude Code\n  DeepSeek / existing CCS\nCodex CLI\n  configured OpenAI model')
box(ax,.37,.47,.24,.43,'FINITE MCP','inspect_fixture\nexperiment\nsubmit_solution')
box(ax,.69,.47,.27,.43,'HOST-ONLY','Independent validators\nReference solutions\nActual Abaqus dispatcher',RUST)
box(ax,.03,.07,.27,.23,'HISTORICAL ROUTES','controlled mini / Kimi\nPi SDK / DeepSeek',GRAY)
box(ax,.37,.07,.24,.23,'AUDIT TRAIL','queries + outputs\nartifacts + source hashes',INK)
box(ax,.69,.07,.27,.23,'OBSERVED OUTCOME','pass / fail / budget\nservice / startup exclusion',TEAL)
for a,b in [((.31,.69),(.35,.69)),((.62,.69),(.67,.69)),((.49,.45),(.49,.32)),((.83,.45),(.83,.32)),((.62,.18),(.67,.18))]:
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=14,lw=1.4,color=GRAY))
save(fig,'architecture')

fig,ax=plt.subplots();ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1));fig.subplots_adjust(left=.04,right=.98,bottom=.055,top=.83)
heading(fig,'02','EIGHT ENGINEERING DECISIONS','Seven reduced-physics/evidence exercises; one actual commercial-solver task.')
items=[('S01','Units + equilibrium','U, reaction and energy'),('S02','Mesh allocation','coarsest admissible mesh'),
    ('S03','Independent prelift','12 unilateral contacts'),('S04','3D partition selection','actual SIM + solve + ODB'),
    ('S05','Bounded tolerances','72 variables / four samplers'),('S06','Library + Tie coverage','identity before tolerance'),
    ('S07','First-loss boundary','safe / failing evidence'),('S08','Recovery + ranking','physical vs numerical failure')]
for i,(key,title,body) in enumerate(items):
    x=.035+(i%2)*.49;y=.735-(i//2)*.235;c=RUST if key=='S04' else TEAL
    ax.add_patch(Rectangle((x,y),.035,.18,fc=c,ec='none'))
    ax.text(x+.052,y+.15,key+'  '+title,color=c,weight='bold',fontsize=11)
    ax.text(x+.052,y+.08,body,color=INK,fontsize=9)
    ax.text(x+.052,y+.025,'ACTUAL ABAQUS / MCP' if key=='S04' else 'REDUCED PHYSICS / EVIDENCE',color=GRAY,fontsize=7)
save(fig,'tasks')

fig,axes=plt.subplots(1,2,gridspec_kw={'width_ratios':[1,1.1]});heading(fig,'05','CONDENSE ONLY WHAT MAY STAY LINEAR','Original public solid: 117 nodes / 48 C3D8. Independent full model remains host-only.')
ax=axes[0];ax.axvspan(0,6,color=TEAL,alpha=.1);ax.axvspan(6,12,color=RUST,alpha=.12)
for x in range(13):ax.plot([x,x],[0,2],color=GRAY,lw=.6)
for y in range(3):ax.plot([0,12],[y,y],color=GRAY,lw=.6)
ax.plot([6,6],[-.2,2.2],color=TEAL,lw=2.5)
ax.text(3,2.55,'LINEAR SUB',ha='center',weight='bold',color=TEAL)
ax.text(9,2.55,'PLASTIC CORE',ha='center',weight='bold',color=RUST)
ax.text(3,-.45,'135 translations\neliminated',ha='center',va='top',fontsize=9)
ax.text(9,-.45,'nonlinear material\nretained',ha='center',va='top',fontsize=9)
ax.set(xlim=(-.5,12.5),ylim=(-2.3,4),xlabel='x / mm',ylabel='y / mm');ax.set_aspect('equal')
ax=axes[1];styles={'claude-code':(TEAL,'o'),'codex-native':(RUST,'x')}
first=True
for name,curves in D['solid'].items():
    if first:
        r=curves['full_odb'];ax.plot([v['U1'] for v in r],[v['tip_RF1'] for v in r],color=INK,lw=2.8,label='Independent full 3D');first=False
    c,m=styles[name];r=curves['reduced_odb'];ax.plot([v['U1'] for v in r],[v['tip_RF1'] for v in r],'--',color=c,marker=m,
        markevery=3,ms=5,lw=1.2,label='Reduced / '+('Claude Code' if name=='claude-code' else 'Codex'))
ax.set(xlabel='Tip U1 / mm',ylabel='Tip RF1 / N');ax.grid(alpha=.16);ax.legend(frameon=False,fontsize=8,loc='lower right')
fig.subplots_adjust(left=.08,right=.98,bottom=.16,top=.79,wspace=.26);save(fig,'solid')

fig,axes=plt.subplots(2,2,sharex=True,sharey=True);heading(fig,'03','BOUNDED IS NOT CLIPPED','Author illustration from frozen task inputs; not a statistical-efficiency experiment.')
x=np.linspace(-1,1,300);norm=np.sqrt(2*np.pi)*.6826894921370859
for ax,(name,matrix) in zip(axes.flat,D['sampling'].items()):
    values=[v[0] for v in matrix];ax.hist(values,bins=np.linspace(-1,1,9),density=True,color=TEAL,alpha=.65,edgecolor='white')
    ax.plot(x,np.exp(-x*x/2)/norm,color=RUST,lw=1.8);ax.set_title(name+' / n = 16',loc='left',fontsize=11)
    ax.set(xlim=(-1,1),ylim=(0,2));ax.grid(axis='y',alpha=.12)
for ax in axes[-1,:]:ax.set_xlabel('Dimensionless amplitude')
for ax in axes[:,0]:ax.set_ylabel('Probability density')
fig.subplots_adjust(left=.085,right=.97,bottom=.11,top=.79,hspace=.44,wspace=.15);save(fig,'sampling')

fig=plt.figure();heading(fig,'06','OUTCOMES ARE MORE THAN A PASS RATE','One formal attempt per task/client. Models, routes and native budgets differ: no causal ranking.')
gs=fig.add_gridspec(2,1,height_ratios=[1,1.5],left=.19,right=.97,bottom=.12,top=.79,hspace=.44)
ax=fig.add_subplot(gs[0]);colors={'passed':TEAL,'failed':RUST,'budget_exhausted':'#cda047','environment_or_incomplete':GRAY,'adapter_invalid':GRAY,'protocol_ambiguity':'#596f9a'}
letters={'passed':'PASS','failed':'FAIL','budget_exhausted':'BUDGET','environment_or_incomplete':'INCOMPLETE','adapter_invalid':'EXCLUDED','protocol_ambiguity':'CONTRACT'}
formal=[r for r in D['summary']['rows'] if r['classification']!='adapter_invalid']
for yi,name in enumerate(('claude-code','codex-native')):
    for xi,key in enumerate(D['cards']):
        r=next(r for r in formal if r['configuration']==name and r['task']==key)
        ax.add_patch(Rectangle((xi-.47,yi-.39),.94,.78,fc=colors[r['classification']]+'20',ec='white'))
        ax.text(xi,yi,letters[r['classification']],ha='center',va='center',color=colors[r['classification']],fontsize=8,weight='bold')
ax.set(xlim=(-.5,7.5),ylim=(1.5,-.5));ax.set_xticks(range(8),D['cards']);ax.set_yticks([0,1],['Claude Code','Codex CLI']);ax.tick_params(length=0)
for spine in ax.spines.values():spine.set_visible(False)
ax=fig.add_subplot(gs[1]);x=np.arange(8)
for shift,name,color in [(-.18,'claude-code',TEAL),(.18,'codex-native',RUST)]:
    vals=[next(r['elapsed_seconds'] for r in formal if r['configuration']==name and r['task']==key) for key in D['cards']]
    ax.bar(x+shift,vals,width=.33,color=color,alpha=.85,label='Claude Code' if name=='claude-code' else 'Codex CLI')
ax.set_xticks(x,D['cards']);ax.set_ylabel('Wall time / s');ax.grid(axis='y',alpha=.13);ax.set_axisbelow(True);ax.legend(frameon=False,fontsize=8,ncol=2)
fig.text(.19,.025,'Nine MCP-startup exclusions are retained separately. Time includes native startup, model waits and tools.',fontsize=8,color=GRAY)
save(fig,'outcomes')

fig,axes=plt.subplots(1,2,gridspec_kw={'width_ratios':[1.25,1]});heading(fig,'04','A BOUNDARY NEEDS TWO EXECUTED ENDPOINTS','Reduced unilateral-spring mechanics, not an industrial connector prediction.')
f=D['cards']['S07']['fixture'];lam=np.linspace(0,2,401)
forces=np.array([f['k_N_per_mm'][j]*np.maximum(0,f['initial_overlap_mm'][j]-.1*f['normal_x'][j]*lam-f['lever_mm'][j]*np.sin(2*lam*np.pi/180)) for j in range(12)])
ax=axes[0]
for row in forces:ax.plot(lam,row,color=GRAY,lw=.6,alpha=.35)
ax.plot(lam,forces.min(axis=0),color=INK,lw=2,label='Author reference: min of 12')
ax.axhline(.4,color=RUST,lw=1.3,ls='--',label='0.4 N threshold')
for name,records in D['pose'].items():
    if not records:continue
    x=[r['parameters']['lambda'] for r in records];y=[min(r['result']['forces_N']) for r in records]
    ax.scatter(x,y,color=TEAL if name=='claude-code' else RUST,marker='o' if name=='claude-code' else 'x',s=30,
        zorder=4,label='Actual '+('Claude Code' if name=='claude-code' else 'Codex')+' experiments')
ax.set(xlabel='Path parameter lambda',ylabel='Normal force / N',xlim=(0,2),ylim=(0,2));ax.grid(alpha=.14)
ax.legend(frameon=False,fontsize=7,loc='upper right')
ax=axes[1];ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
box(ax,.08,.64,.82,.24,'KINEMATIC PATH','offset X = 0.1 lambda mm\nangle = 2 lambda degrees')
box(ax,.08,.30,.82,.24,'EVIDENCE CONTRACT','g(lambda_safe) >= 0\ng(lambda_failed) < 0',RUST)
ax.text(.10,.19,'Bracket width <= 0.002\nDifferent artifacts prove both ends.\nA numerical abort is not contact loss.',fontsize=9,va='top',linespacing=1.6)
fig.subplots_adjust(left=.08,right=.98,bottom=.16,top=.80,wspace=.22);save(fig,'boundary')
