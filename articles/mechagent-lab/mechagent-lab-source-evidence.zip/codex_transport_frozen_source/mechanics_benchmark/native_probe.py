"""Real CLI startup against a local mock: no model or solver charge."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile
import threading
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from .native_suite import command,OUT,ROOT
from .native_host import Host,serve_host
from .security import Trace
from .suite_v2 import task_cards,definitions


def probe():
    records=[]
    for attempt in range(3):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);host=Host(task_cards()['S01'],Trace(folder),None,None)
            def mock(body):
                host.actual_tools.append([t.get('name') for t in body.get('tools',[])])
                return 200,dict(id='offline_mock',type='message',role='assistant',model='offline-mock',
                    content=[dict(type='text',text='Offline transport only')],stop_reason='end_turn',
                    usage=dict(input_tokens=1,output_tokens=1)),'application/json'
            host.infer=mock;host.route=True
            with serve_host(host) as base:
                env=os.environ.copy();env.pop('CLAUDECODE',None);env.pop('ANTHROPIC_AUTH_TOKEN',None)
                env.update(PYTHONPATH=str(ROOT),MECH_BROKER_URL=base+'/broker',MECH_BROKER_TOKEN=host.token,
                    ANTHROPIC_API_KEY=host.token,ANTHROPIC_BASE_URL=base,ENABLE_TOOL_SEARCH='false',
                    CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC='1')
                proc=subprocess.run(command('claude-code',folder,folder),input='Offline startup check only.',
                    capture_output=True,text=True,encoding='utf-8',errors='replace',env=env,cwd=folder,timeout=40,
                    creationflags=subprocess.CREATE_NO_WINDOW)
            expected={'mcp__mechanics__'+r['name'] for r in definitions()}
            ok=bool(host.actual_tools) and all(set(t)==expected for t in host.actual_tools)
            record=dict(probe=attempt,passed=ok,model_request_tools=host.actual_tools,returncode=proc.returncode,
                stdout=proc.stdout,stderr=proc.stderr,inference_forwarded=False,solver_submitted=False)
            record['host_events']=(folder/'trace.jsonl').read_text(encoding='utf-8')
            records.append(record)
            if not ok:break
    (OUT/'qa/verified_native_startup.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    print(json.dumps([dict(probe=r['probe'],passed=r['passed'],tools=r['model_request_tools']) for r in records],indent=2))
    if not all(r['passed'] for r in records):raise RuntimeError('Native startup did not expose the exact three tools')


def codex_probe():
    captured=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            body=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
            runtime_tools=[t for item in body.get('input',[]) if item.get('type')=='additional_tools' for t in item.get('tools',[])]
            captured.append(dict(path=self.path,tools=body.get('tools',[]),runtime_namespaces=[t.get('name') for t in runtime_tools]))
            data=json.dumps(dict(error=dict(message='Intentional offline stop after catalog capture',type='invalid_request_error'))).encode()
            self.send_response(400);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);(folder/'task.json').write_text(json.dumps(task_cards()['S01']))
            (folder/'query.json').write_text(json.dumps(dict(tools=definitions())))
            home=folder/'home';home.mkdir()
            env=dict(os.environ,CODEX_HOME=str(home),BENCHMARK_OFFLINE_KEY='offline-placeholder')
            env.pop('OPENAI_API_KEY',None)
            cmd=command('codex-native',folder,folder)
            values={'model_provider':'offline','model_providers.offline.name':'Offline benchmark',
                'model_providers.offline.base_url':'http://127.0.0.1:'+str(server.server_port)+'/v1',
                'model_providers.offline.wire_api':'responses','model_providers.offline.env_key':'BENCHMARK_OFFLINE_KEY',
                'model_providers.offline.request_max_retries':0,'model_providers.offline.stream_max_retries':0}
            for k,v in values.items():cmd += ['-c',k+'='+json.dumps(v)]
            cmd+=['--disable','api_key_model_discovery']
            result=subprocess.run(cmd,input='Offline startup only. Do not attempt a solution.',env=env,cwd=folder,
                capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
            names=[t.get('name') for c in captured for t in c['tools']]
            banned=[n for n in names if any(s in str(n) for s in ('exec_command','shell','apply_patch','write_stdin','view_image','web_search'))]
            host_events=[json.loads(l) for l in (folder/'trace.jsonl').read_text(encoding='utf-8').splitlines()] if (folder/'trace.jsonl').exists() else []
            catalogs=[e['tools'] for e in host_events if e['kind']=='native_mcp_catalog']
            catalog_names=[t['name'] for catalog in catalogs for t in catalog]
            expected={t['name'] for t in definitions()}
            # This installed model uses Responses-lite Code Mode. Deferred MCP
            # schemas are not flattened into the outer Responses tools array.
            ok=bool(captured) and expected==set(catalog_names) and not banned
            report=dict(passed=ok,tools=names,requests=captured,stdout=result.stdout,stderr=result.stderr,
                mechanics_catalog=catalog_names,transport='Responses-lite Code Mode; outer tools are not a complete capability inventory',
                inference_forwarded=False,solver_submitted=False,returncode=result.returncode)
            (OUT/'qa/offline_codex_startup.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
            print(json.dumps(dict(passed=ok,tools=names),indent=2))
            if not ok:raise RuntimeError('Codex startup/catalog verification failed')
    finally:server.shutdown();server.server_close()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--client',choices=['claude-code','codex-native','both'],default='both');a=p.parse_args()
    if a.client in ('claude-code','both'):probe()
    if a.client in ('codex-native','both'):codex_probe()
