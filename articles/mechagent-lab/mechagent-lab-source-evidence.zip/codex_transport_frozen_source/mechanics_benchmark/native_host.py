"""Task-scoped finite MCP broker and optional bounded Anthropic gateway."""
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
import secrets
import threading
import httpx
from urllib.parse import urlsplit
from .api import endpoint
from .suite_v2 import definitions
from .suite_tools import Broker
from .suite_evaluate import evaluate


class Host:
    def __init__(self,card,trace,reference,solver_root,route=None):
        self.trace=trace;self.broker=Broker(card,trace,solver_root,reference)
        self.route=route;self.token=secrets.token_urlsafe(32);self.lock=threading.RLock()
        self.requests=0;self.blocked=None;self.actual_tools=[];self.responses=[]

    def rpc(self,request):
        method=request['method'];params=request.get('params',{})
        with self.lock:
            if method=='initialize':result=dict(protocolVersion=request.get('params',{}).get('protocolVersion','2024-11-05'),
                capabilities=dict(tools=dict(listChanged=False)),serverInfo=dict(name='mechanics',version='0.3.0'))
            elif method=='ping':result={}
            elif method=='tools/list':
                result=dict(tools=[dict(name=t['name'],description=t['description'],inputSchema=t['input_schema']) for t in definitions()])
                self.trace.write('native_mcp_catalog',tools=result['tools'])
            elif method=='tools/call':
                value=self.broker.call(params['name'],params.get('arguments',{}),'native_'+str(self.broker.calls+1))
                result=dict(content=[dict(type='text',text=json.dumps(value,ensure_ascii=False,allow_nan=False))],isError='error' in value)
                state=dict(calls=self.broker.calls,solver_calls=self.broker.solver_calls,submitted=self.broker.submission is not None)
                if self.broker.submission:
                    scoring=evaluate(self.broker.card,self.broker.submission['solution'],self.broker.artifacts)
                    self.trace.save('evaluation.json',scoring);state['evaluation']=scoring
                self.trace.save('broker_state.json',state)
            else:return dict(jsonrpc='2.0',id=request.get('id'),error=dict(code=-32601,message='Method unavailable'))
            return dict(jsonrpc='2.0',id=request.get('id'),result=result)

    def infer(self,body):
        names=[t.get('name') for t in body.get('tools',[])]
        expected={'mcp__mechanics__'+t['name'] for t in definitions()}
        self.actual_tools.append(names)
        self.trace.write('model_request',protocol='anthropic-native',request=body)
        if set(names)!=expected:
            self.blocked='unexpected_model_tool_catalog'
        if self.requests>=6:self.blocked='model_request_budget_exhausted'
        if self.blocked:return 400,dict(type='error',error=dict(type='invalid_request_error',message=self.blocked)),'application/json'
        self.requests+=1
        body['max_tokens']=min(body.get('max_tokens',6144),6144)
        with httpx.Client(timeout=300,trust_env=False,follow_redirects=False) as client:
            response=client.post(endpoint(self.route),json=body,
                headers={'x-api-key':self.route.secret,'anthropic-version':'2023-06-01'})
        text=response.text
        self.responses.append(dict(status=response.status_code,body=text))
        self.trace.write('native_model_response',status=response.status_code,body=text)
        if response.status_code!=200:self.blocked='upstream_error_no_automatic_retry'
        return response.status_code,text,response.headers.get('content-type','application/json')


@contextmanager
def serve_host(host):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            try:
                path=urlsplit(self.path).path
                host.trace.write('native_http_route',path=path,header_names=list(self.headers.keys()))
                size=int(self.headers.get('Content-Length','0'))
                if size>2_000_000:raise ValueError('Request too large')
                body=json.loads(self.rfile.read(size))
                if path=='/broker' and secrets.compare_digest(self.headers.get('X-Benchmark-Token',''),host.token):
                    status,value,kind=200,host.rpc(body),'application/json'
                elif path in ('/v1/messages','/messages') and host.route and secrets.compare_digest(self.headers.get('x-api-key',''),host.token):
                    status,value,kind=host.infer(body)
                elif path=='/v1/messages/count_tokens':
                    status,value,kind=400,dict(error=dict(type='invalid_request_error',message='No count-token service in benchmark')),'application/json'
                else:status,value,kind=403,dict(error='Task-scoped endpoint only'),'application/json'
                data=value.encode() if isinstance(value,str) else json.dumps(value).encode()
            except Exception as error:
                status,kind=500,'application/json';data=json.dumps(dict(error=str(error))).encode()
            self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)))
            self.end_headers();self.wfile.write(data)
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:yield 'http://127.0.0.1:'+str(server.server_port)
    finally:server.shutdown();server.server_close()
