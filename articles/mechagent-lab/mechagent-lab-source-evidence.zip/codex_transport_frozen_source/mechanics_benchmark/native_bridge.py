"""Tiny stdio MCP relay. Native clients receive no paths or host credentials."""
import json
import os
import sys
import urllib.request


def main():
    url=os.environ['MECH_BROKER_URL'];token=os.environ['MECH_BROKER_TOKEN']
    for line in sys.stdin:
        try:
            request=json.loads(line)
            if 'id' not in request:continue
            data=json.dumps(request).encode()
            req=urllib.request.Request(url,data=data,headers={'X-Benchmark-Token':token,'Content-Type':'application/json'})
            # Avoid forwarding loopback requests through the user's web proxy.
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=260) as response:
                result=json.load(response)
            print(json.dumps(result,ensure_ascii=False),flush=True)
        except Exception as error:
            print(json.dumps(dict(jsonrpc='2.0',id=locals().get('request',{}).get('id'),
                error=dict(code=-32603,message=str(error)))),flush=True)


if __name__=='__main__':main()
