"""Finite capability broker: no shell, arbitrary paths, evaluator or network access."""
from copy import deepcopy
import json
from .mechanics import axial_solve, condensation_test
from .security import digest


def definitions(task_id):
    tools = [dict(name="inspect_fixture", description="Read the complete public mechanics fixture and output schema.",
                  input_schema=dict(type="object", properties={}, additionalProperties=False))]
    if task_id == "M01":
        tools.append(dict(name="axial_solve", description="Execute an independent 1D direct-stiffness axial FEM solve of this immutable fixture; not Abaqus.",
                          input_schema=dict(type="object", properties={}, additionalProperties=False)))
    elif task_id == "M04":
        tools.append(dict(name="condensation_test", description="Test a proposed CORE/SUB partition using Schur condensation and the nonlinear load envelope. Returns measured errors and eliminated DOFs.",
            input_schema=dict(type="object", properties={
                "core_regions": dict(type="array", items=dict(type="string")),
                "sub_regions": dict(type="array", items=dict(type="string")),
                "retained_dofs": dict(type="array", items=dict(type="integer"))},
                required=["core_regions", "sub_regions", "retained_dofs"], additionalProperties=False)))
    tools.append(dict(name="submit_solution", description="Submit the final structured engineering solution with explanation. This ends this attempt.",
        input_schema=dict(type="object", properties=dict(solution=dict(type="object"), explanation=dict(type="string")),
                          required=["solution", "explanation"], additionalProperties=False)))
    return tools


class Broker:
    def __init__(self, task_id, task, trace, max_calls=18):
        self.task_id, self.task, self.trace = task_id, deepcopy(task), trace
        self.artifacts, self.submission = {}, None
        self.calls, self.max_calls = 0, max_calls

    def call(self, name, arguments, call_id=None):
        self.calls += 1
        self.trace.write("tool_request", name=name, arguments=arguments, call_id=call_id)
        try:
            if self.calls > self.max_calls:
                raise ValueError("Tool-call budget exhausted")
            if self.submission is not None:
                raise ValueError("Attempt already submitted")
            if not isinstance(arguments, dict) or len(json.dumps(arguments, allow_nan=False)) > 40000:
                raise ValueError("Tool arguments must be a bounded JSON object")
            if name == "inspect_fixture" and not arguments:
                result = dict(fixture=self.task["fixture"], output_schema=self.task.get("output_schema", {}))
            elif name == "axial_solve" and self.task_id == "M01" and not arguments:
                result = self.artifact(name, arguments, axial_solve(self.task["fixture"]))
            elif name == "condensation_test" and self.task_id == "M04":
                if set(arguments) != {"core_regions", "sub_regions", "retained_dofs"} or any(
                        not isinstance(arguments[k], list) for k in arguments):
                    raise ValueError("Expected exactly the three partition arrays")
                result = self.artifact(name, arguments, condensation_test(self.task["fixture"], **arguments))
            elif name == "submit_solution" and set(arguments) == {"solution", "explanation"}:
                if not isinstance(arguments["solution"], dict) or not isinstance(arguments["explanation"], str):
                    raise ValueError("Expected solution object and explanation string")
                self.submission = deepcopy(arguments)
                self.trace.save("submission.json", self.submission)
                result = dict(submitted=True)
            else:
                raise ValueError("Tool unavailable or invalid argument fields")
        except (ValueError, TypeError, KeyError) as error:
            result = dict(error=str(error))
        self.trace.write("tool_response", name=name, result=result, call_id=call_id)
        return result

    def artifact(self, tool, arguments, result):
        record = dict(tool=tool, arguments=deepcopy(arguments), result=result)
        identity = "artifact_" + digest(record)[:20]
        self.artifacts[identity] = record
        self.trace.save("artifacts/" + identity + ".json", record)
        return dict(artifact_id=identity, **result)
