"""Auditable mechanics-agent evaluation, isolated from production CAE tools."""

__version__ = "0.1.0"
