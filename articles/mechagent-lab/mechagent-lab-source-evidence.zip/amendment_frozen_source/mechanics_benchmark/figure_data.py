"""Prepare only original fixture and measured pilot data for Tavotto sources."""
import json
from pathlib import Path
from .tasks import get_task
from .mechanics import condensation_test


def main():
    root = Path(__file__).resolve().parents[1]/"outputs/mechanics_agent_benchmark_20261103"
    fixture = get_task("M04")["fixture"]
    correct = condensation_test(fixture, ["r4","r5","r6"], ["r1","r2","r3"], [0,3,4,5,6])
    unsafe = condensation_test(fixture, [], ["r1","r2","r3","r4","r5","r6"], [0,6])
    data = dict(pilot=json.loads((root/"pilot_summary.json").read_text(encoding="utf-8")),
                partition_experiment=dict(correct=correct,unsafe=unsafe))
    (root/"figures/figure_data.json").write_text(json.dumps(data,indent=2),encoding="utf-8")


if __name__ == "__main__":
    main()
