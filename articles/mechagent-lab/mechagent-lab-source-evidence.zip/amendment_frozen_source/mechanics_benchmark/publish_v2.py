"""Stage only v0.2 assets and semantically changed generated indexes/navigation."""
import json
from pathlib import Path
import subprocess
from .publish_preview import semantic
from .credentials import inventory

OUT=Path(__file__).resolve().parents[1]/'outputs/mechanics_agent_benchmark_v02_20261104'
SITE=OUT/'website'


def git(*args):
    return subprocess.run(['git','-C',str(SITE),*args],capture_output=True,check=True).stdout.decode('utf-8').strip()


def stage():
    if git('remote','get-url','origin')!='https://github.com/Alexchan114/Alexchan114.github.io.git':raise ValueError('Unexpected repository')
    if git('diff','--cached','--name-only'):raise ValueError('Unexpected staged files')
    selected=[]
    for name in git('diff','--name-only').splitlines():
        if name.startswith('site-src/'):raise ValueError('Unexpected tracked source edits')
        old=git('show','HEAD:'+name);new=(SITE/name).read_text(encoding='utf-8')
        if (semantic(old)!=semantic(new)) if name.endswith(('.html','.xml')) else old.strip()!=new.strip():
            selected.append(name)
    for root in ('articles/mechanics-benchmark-v02','post/2026/11/04','en/post/2026/11/04',
        'site-src/static/articles/mechanics-benchmark-v02'):
        selected += [p.relative_to(SITE).as_posix() for p in (SITE/root).rglob('*') if p.is_file()]
    selected += ['site-src/content/post/mechanics-benchmark-v02.md','site-src/content/post/mechanics-benchmark-v02.en.md']
    selected=sorted(set(selected))
    values=[r.secret.encode() for r in inventory() if len(r.secret)>=8]
    for name in selected:
        if any(value in (SITE/name).read_bytes() for value in values):raise ValueError('Credential scan blocked publication')
    git('switch','-c','codex/mechanics-benchmark-v02-20261104')
    git('add','--',*selected);git('diff','--cached','--check')
    staged=git('diff','--cached','--name-only').splitlines()
    if staged!=selected:raise ValueError('Review manifest mismatch')
    (OUT/'qa/publish_manifest.json').write_text(json.dumps(dict(files=staged),indent=2))
    print(json.dumps(dict(staged_files=len(staged),files=staged),indent=2))


if __name__=='__main__':stage()
