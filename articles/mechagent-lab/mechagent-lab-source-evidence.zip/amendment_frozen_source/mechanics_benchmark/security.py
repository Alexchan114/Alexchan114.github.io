"""Trace sanitization and path confinement for the controlled-tool track."""
import hashlib
import json
from pathlib import Path
import re


SENSITIVE = re.compile(r"api[_-]?key|authorization|auth[_-]?token|password|secret", re.I)


def scrub(value, secrets=()):
    if isinstance(value, dict):
        return {k: "[REDACTED]" if SENSITIVE.search(k) else scrub(v, secrets) for k, v in value.items()}
    if isinstance(value, list):
        return [scrub(v, secrets) for v in value]
    if isinstance(value, str):
        for secret in secrets:
            if secret:
                value = value.replace(secret, "[REDACTED]")
        return re.sub(r"(?i)Bearer\s+[A-Za-z0-9_.~+/=-]+", "Bearer [REDACTED]", value)
    return value


def confined(root, name):
    root = Path(root).resolve()
    path = (root / name).resolve()
    if path != root and root not in path.parents:
        raise ValueError("Path escapes run workspace")
    return path


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
                                     allow_nan=False).encode()).hexdigest()


class Trace:
    def __init__(self, root, secrets=()):
        self.root, self.secrets, self.index = Path(root), tuple(secrets), 0

    def write(self, kind, **value):
        from datetime import datetime, timezone
        self.index += 1
        event = dict(index=self.index, utc=datetime.now(timezone.utc).isoformat(), kind=kind, **value)
        with (self.root / "trace.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(scrub(event, self.secrets), ensure_ascii=False, allow_nan=False) + "\n")

    def save(self, name, value):
        path = confined(self.root, name)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(scrub(value, self.secrets), indent=2, ensure_ascii=False,
                                   allow_nan=False) + "\n", encoding="utf-8")
