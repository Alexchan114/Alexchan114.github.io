"""Run with an MCP-enabled Python. Connectivity evidence, never task scores."""
import argparse
import asyncio
from contextlib import AsyncExitStack
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def probe(root, output):
    output.mkdir(parents=True, exist_ok=False)
    environment = {k: v for k, v in os.environ.items() if k.upper() in
        ("SYSTEMROOT", "WINDIR", "PATH", "TEMP", "TMP", "USERPROFILE", "APPDATA", "LOCALAPPDATA")}
    environment["CAE_MCP_ROOT"] = str(root)
    inventory = dict(scope="author setup probe; excluded from agent queries, costs and scores", services={})
    async with AsyncExitStack() as stack:
        for domain in ("hypermesh", "abaqus", "paraview"):
            streams = await stack.enter_async_context(stdio_client(StdioServerParameters(
                command=sys.executable, args=["-m", "cae_mcp", "serve", domain],
                cwd=str(root), env=environment)))
            session = await stack.enter_async_context(ClientSession(*streams))
            await session.initialize()
            tools = await session.list_tools()
            result = await session.call_tool(domain+"_capabilities", {})
            inventory["services"][domain] = dict(
                tools=[dict(name=t.name, description=t.description, input_schema=t.inputSchema) for t in tools.tools],
                capabilities=result.model_dump(mode="json"))
    (output/"mcp_probe.json").write_text(json.dumps(inventory, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(dict(scope=inventory["scope"], services={k:len(v["tools"]) for k,v in inventory["services"].items()})))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("D:/kimi/cae-mcp"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    asyncio.run(probe(args.root.resolve(), args.output.resolve()))
