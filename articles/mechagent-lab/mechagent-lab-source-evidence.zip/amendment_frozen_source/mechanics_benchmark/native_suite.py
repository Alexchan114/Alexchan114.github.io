"""Bounded native-client campaign. No agent is replaced by a custom inference loop."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import queue
import shutil
import subprocess
import threading
import time
from .suite_v2 import task_cards, definitions, query
from .api import SYSTEM
from .credentials import inventory, select
from .security import Trace, digest, scrub

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/mechanics_agent_benchmark_v03_20261105'
PYTHON = str(OUT / '.venv/Scripts/python.exe')
REFERENCE = 'D:/kimi/benchmark_public/solid_20261104_03'
SOLVER_ROOT = 'D:/kimi/benchmark_public/v03_native_20261105'
TOOL_NAMES = {'inspect_fixture', 'experiment', 'submit_solution'}


class ClientTrace(Trace):
    """Client and MCP host each own one stream; indices are local to a stream."""
    def write(self, kind, **value):
        self.index += 1
        event = dict(index=self.index, utc=datetime.now(timezone.utc).isoformat(), kind=kind, **value)
        with (self.root / 'client_trace.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(scrub(event, self.secrets), ensure_ascii=False, allow_nan=False)+'\n')
CONFIGS = {
    'claude-code': dict(harness='Claude Code', client_version='2.1.154', model='deepseek-v4-flash',
                        provider_id='ab26ff7c-b94a-4228-a0b0-a5b40a926362', auth='existing CCS route'),
    'codex-native': dict(harness='Codex CLI', client_version='0.166.0-alpha.5.1', model='gpt-6.1-sol',
                         auth='existing ChatGPT login', reasoning_effort='xhigh'),
}


def hashes():
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.iterdir()
            if p.suffix in ('.py', '.mjs') or p.name == 'requirements.txt'}


def freeze():
    value = dict(internal_version='V3', public_title='力学工程 Agent 实测：从任务决策到求解证据',
                 created_utc=datetime.now(timezone.utc).isoformat(), configurations=CONFIGS,
                 tasks=task_cards(), tools=definitions(), source_hashes=hashes(),
                 matrix=[dict(configuration=c, task=t) for c in CONFIGS for t in task_cards()],
                 repetitions=1, automatic_benchmark_retries=0, maximum_attempts=16,
                 budgets=dict(tool_calls=24, wall_seconds=360, claude_native_turns=6,
                              claude_max_output_tokens_per_request=6144,
                              codex_output_token_cap=None, codex_token_usage='reported after run'),
                 scope='seven reduced-physics exercises; S04 actual Abaqus via host broker',
                 isolation='CLI configuration and observed-tool audit; no claim of OS-level isolation',
                 comparison='descriptive matched tasks; different models/routes/native budgets; no causal ranking',
                 native_transport_retries='client-internal retries may occur; observable events retained')
    target = OUT / 'preregistration.json'
    if target.exists():
        original = json.loads(target.read_text(encoding='utf-8'))
        value['amendment_of_hash'] = digest(original)
        value['reason'] = ('Offline mock proved Claude --tools empty suppresses MCP as well as built-ins. '
                           'Explicit MCP-only list replaces it. No physics, task, tool schema or evaluator changed. '
                           'Client and host event streams separated to avoid duplicate indices. '
                           'Use existing Windows proxy for Codex, scoped to this process only.')
        value['retained_valid_attempts'] = ['codex-native-S01-a1']
        value['excluded_setup_attempts'] = ['claude-code-S01-a1']
        value['additional_attempts'] = 'Claude S01 once with corrected adapter; remaining 14 first attempts'
        target = OUT / 'amendment_registration.json'
        if target.exists(): raise ValueError('Amendment already frozen')
    target.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')
    snap = OUT / ('amendment_frozen_source' if 'amendment_of_hash' in value else 'frozen_source') / 'mechanics_benchmark'
    snap.mkdir(parents=True)
    for name in value['source_hashes']:
        shutil.copy2(Path(__file__).with_name(name), snap / name)
    print('Frozen', digest(value), flush=True)


def command(client, folder, workspace):
    server = dict(command=PYTHON, args=['-m', 'mechanics_benchmark.native_mcp', '--folder', str(folder),
                   '--reference', REFERENCE, '--solver-root', SOLVER_ROOT],
                   env={'PYTHONPATH': str(ROOT)})
    if client == 'claude-code':
        return [shutil.which('claude'), '--bare', '-p', '--model', CONFIGS[client]['model'],
                '--tools', ','.join('mcp__mechanics__' + s for s in sorted(TOOL_NAMES)),
                '--strict-mcp-config', '--mcp-config', json.dumps({'mcpServers': {'mechanics': server}}),
                '--allowedTools', ','.join('mcp__mechanics__' + s for s in sorted(TOOL_NAMES)),
                '--permission-mode', 'dontAsk', '--disable-slash-commands', '--setting-sources', '',
                '--no-session-persistence', '--no-chrome', '--output-format', 'stream-json', '--verbose',
                '--max-turns', '6', '--system-prompt', SYSTEM]
    configs = {
        'model_reasoning_effort': 'xhigh', 'approval_policy': 'never', 'web_search': 'disabled',
        'project_doc_max_bytes': 0, 'skills.include_instructions': False,
        'developer_instructions': SYSTEM,
        'mcp_servers.mechanics.command': server['command'],
        'mcp_servers.mechanics.args': server['args'],
        'mcp_servers.mechanics.env.PYTHONPATH': str(ROOT),
        'mcp_servers.mechanics.required': True,
        'mcp_servers.mechanics.enabled_tools': sorted(TOOL_NAMES),
        'mcp_servers.mechanics.tool_timeout_sec': 240,
        'mcp_servers.mechanics.default_tools_approval_mode': 'approve',
    }
    cmd = [shutil.which('codex'), 'exec', '--json', '--ephemeral', '--ignore-user-config', '--ignore-rules',
           '--skip-git-repo-check', '--sandbox', 'read-only', '--model', CONFIGS[client]['model'], '--cd', str(workspace)]
    for feature in ('shell_tool', 'unified_exec', 'view_image', 'computer_use', 'browser_use',
                    'browser_use_external', 'apps', 'plugins', 'hooks', 'multi_agent', 'sleep_tool',
                    'image_generation', 'workspace_dependencies', 'memories'):
        cmd += ['--disable', feature]
    cmd += ['--enable', 'skip_host_skill_discovery']
    for key, value in configs.items():
        cmd += ['-c', key + '=' + json.dumps(value, ensure_ascii=False)]
    cmd += ['-']
    return cmd


def run(client, key):
    regpath = OUT / 'amendment_registration.json'
    if not regpath.exists(): regpath = OUT / 'preregistration.json'
    reg = json.loads(regpath.read_text(encoding='utf-8'))
    if hashes() != reg['source_hashes']:
        raise ValueError('Source changed after freeze')
    if dict(configuration=client, task=key) not in reg['matrix']:
        raise ValueError('Outside frozen campaign')
    folder = OUT / 'pilot' / (client + '-' + key + '-a1')
    if folder.name in reg.get('excluded_setup_attempts', []):
        folder = folder.with_name(client + '-' + key + '-a2')
    folder.mkdir(parents=True, exist_ok=False)
    workspace = OUT / 'private_workspaces' / folder.name
    workspace.mkdir(parents=True, exist_ok=False)
    secrets = [r.secret for r in inventory() if r.secret]
    trace = ClientTrace(folder, secrets)
    card = reg['tasks'][key]
    trace.save('task.json', card)
    trace.save('query.json', dict(system=SYSTEM, user=query(card), tools=definitions()))
    env = os.environ.copy()
    env['PYTHONPATH'] = str(ROOT)
    env.pop('CLAUDECODE', None)
    env['CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC'] = '1'
    env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'] = '6144'
    env['MAX_THINKING_TOKENS'] = '0'
    if client == 'claude-code':
        route = select(CONFIGS[client]['provider_id'])
        env['ANTHROPIC_API_KEY'] = route.secret
        env['ANTHROPIC_BASE_URL'] = route.base_url
        env.pop('ANTHROPIC_AUTH_TOKEN', None)
    elif os.name == 'nt':
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Windows\CurrentVersion\Internet Settings') as k:
            enabled = winreg.QueryValueEx(k, 'ProxyEnable')[0]
            proxy = winreg.QueryValueEx(k, 'ProxyServer')[0]
        if enabled and proxy == 'http://127.0.0.1:12450':
            env['HTTPS_PROXY'] = proxy
            env['HTTP_PROXY'] = proxy
            env['NO_PROXY'] = 'localhost,127.0.0.1,::1'
    cmd = command(client, folder, workspace)
    metadata = dict(configuration=client, **CONFIGS[client], task=key, tier=card['tier'], status='running',
                    started_utc=datetime.now(timezone.utc).isoformat(), preregistration_hash=digest(reg),
                    automatic_benchmark_retry=False, actual_billed_usd=None)
    trace.save('run.json', metadata)
    trace.write('native_launch', command=cmd, cwd=str(workspace),
                environment_policy='credentials passed only in process environment; settings not changed')
    started = time.monotonic()
    proc = subprocess.Popen(cmd, cwd=workspace, env=env, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                            encoding='utf-8', errors='replace', creationflags=subprocess.CREATE_NO_WINDOW)
    lines = queue.Queue()
    def drain(stream, channel):
        for line in stream:
            lines.put((channel, line.rstrip('\n')))
    threads = [threading.Thread(target=drain, args=(s, n), daemon=True)
               for s, n in ((proc.stdout, 'stdout'), (proc.stderr, 'stderr'))]
    for thread in threads: thread.start()
    proc.stdin.write(query(card) + '\nUse only the three mechanics MCP capabilities. Submit through submit_solution.\n')
    proc.stdin.close()
    observed = []
    killed = None
    while proc.poll() is None or any(t.is_alive() for t in threads) or not lines.empty():
        try:
            channel, line = lines.get(timeout=.2)
            if line:
                try: event = json.loads(line)
                except ValueError: event = dict(text=line)
                trace.write('native_' + channel, event=event)
                if channel == 'stdout': observed.append(event)
        except queue.Empty: pass
        if proc.poll() is None and time.monotonic() - started > 360:
            killed = 'wall_budget_exhausted'
            subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True,
                           creationflags=subprocess.CREATE_NO_WINDOW)
    state = json.loads((folder / 'broker_state.json').read_text()) if (folder / 'broker_state.json').exists() else {}
    illegal = []
    for event in observed:
        item = event.get('item', {})
        if item.get('type') in ('command_execution', 'file_change', 'web_search'):
            illegal.append(item.get('type'))
        if event.get('type') == 'system' and event.get('subtype') == 'init':
            active = event.get('tools', [])
            trace.save('active_tools.json', active)
            if set(active) != {'mcp__mechanics__' + s for s in TOOL_NAMES}:
                illegal.append('unexpected_claude_tool_catalog')
    metadata.update(status=killed or ('submitted' if state.get('submitted') else 'no_submission'),
                    elapsed_seconds=time.monotonic()-started, returncode=proc.returncode,
                    tool_calls=state.get('calls', 0), solver_tests=state.get('solver_calls', 0),
                    evaluation=state.get('evaluation'), observed_prohibited_tools=illegal,
                    finished_utc=datetime.now(timezone.utc).isoformat())
    if illegal: metadata['status'] = 'adapter_invalid'
    trace.save('run.json', metadata)
    print(json.dumps(metadata, ensure_ascii=False), flush=True)
    return metadata


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('command', choices=['freeze', 'run'])
    p.add_argument('--client', choices=CONFIGS)
    p.add_argument('--task', choices=task_cards())
    a = p.parse_args()
    if a.command == 'freeze': freeze()
    else: run(a.client, a.task)
