// Pi SDK harness with a fixed tool surface; credentials arrive only over stdin.
import readline from 'node:readline';
import {pathToFileURL} from 'node:url';
import path from 'node:path';

const lines = readline.createInterface({input: process.stdin, crlfDelay: Infinity});
const pending = new Map();
let initialize;
const configPromise = new Promise(resolve => { initialize = resolve; });
lines.on('line', line => {
  const message = JSON.parse(line);
  if (message.type === 'init') initialize(message);
  else if (message.type === 'tool_result') {
    const resolve = pending.get(message.id);
    if (resolve) { pending.delete(message.id); resolve(message.result); }
  }
});
const emit = value => process.stdout.write(JSON.stringify(value) + '\n');
let session;
try {
  const cfg = await configPromise;
  const sdk = await import(pathToFileURL(cfg.module).href);
  const auth = sdk.AuthStorage.inMemory();
  auth.setRuntimeApiKey('ccs-benchmark', cfg.secret);
  const registry = sdk.ModelRegistry.inMemory(auth);
  registry.registerProvider('ccs-benchmark', {
    api: cfg.protocol === 'anthropic' ? 'anthropic-messages' : 'openai-completions',
    baseUrl: cfg.base_url, apiKey: 'BENCHMARK_KEY_IS_IN_MEMORY',
    models: [{id: cfg.model, name: cfg.model, reasoning: false, input: ['text'],
      contextWindow: 32768, maxTokens: cfg.max_output_tokens,
      cost: {input: 0, output: 0, cacheRead: 0, cacheWrite: 0}}]
  });
  const settings = sdk.SettingsManager.inMemory({
    compaction: {enabled: false}, retry: {enabled: false, maxRetries: 0},
    providerRetry: {maxRetries: 0, timeoutMs: cfg.timeout_ms}, telemetry: {enabled: false}
  });
  // No resource discovery/reload: empty extension runtime and no ancestor files.
  const loader = new sdk.DefaultResourceLoader({cwd: cfg.cwd, agentDir: path.join(cfg.cwd, 'pi-empty'),
    settingsManager: settings, noExtensions: true, noSkills: true, noPromptTemplates: true,
    noThemes: true, noContextFiles: true});
  loader.getSystemPrompt = () => cfg.system;
  loader.getAppendSystemPrompt = () => [];
  loader.getAgentsFiles = () => ({agentsFiles: []});
  const customTools = cfg.tools.map(tool => ({
    name: tool.name, label: tool.name, description: tool.description, parameters: tool.input_schema,
    execute: async (id, args) => {
      const promise = new Promise(resolve => pending.set(id, resolve));
      emit({type: 'tool_request', id, name: tool.name, arguments: args});
      const result = await promise;
      return {content: [{type: 'text', text: JSON.stringify(result)}], details: result};
    }
  }));
  ({session} = await sdk.createAgentSession({cwd: cfg.cwd, agentDir: path.join(cfg.cwd, 'pi-empty'),
    authStorage: auth, modelRegistry: registry, settingsManager: settings,
    sessionManager: sdk.SessionManager.inMemory(cfg.cwd), resourceLoader: loader,
    model: registry.find('ccs-benchmark', cfg.model), thinkingLevel: 'off',
    tools: customTools.map(tool => tool.name), customTools}));
  if (JSON.stringify([...session.getActiveToolNames()].sort()) !== JSON.stringify(customTools.map(t => t.name).sort())) {
    throw new Error('Pi tool capability registration mismatch; aborting before inference');
  }
  let calls = 0;
  const originalStream = session.agent.streamFn;
  session.agent.streamFn = (model, context, options) => originalStream(model, context, {
    ...options, maxTokens: cfg.max_output_tokens, maxRetries: 0, timeoutMs: cfg.timeout_ms,
    onPayload: payload => {
      if (calls >= cfg.max_turns) throw new Error('Model turn budget exhausted');
      if (JSON.stringify(payload).length > 250000) throw new Error('Context character budget exhausted');
      calls++;
      emit({type: 'model_request', request: payload, turn: calls});
      return payload;
    }
  });
  session.subscribe(event => {
    if (event.type === 'message_end' || event.type === 'tool_execution_end') emit({type: 'pi_event', event});
  });
  emit({type: 'harness_ready', system: session.systemPrompt, active_tools: session.getActiveToolNames(),
    harness: 'pi-coding-agent@0.73.1', reasoning: 'off', cost_metadata: 'SDK zero prices are placeholders, not measured costs'});
  if (!cfg.dry_run) await session.prompt(cfg.query);
  emit({type: 'done', turns: calls, messages: session.messages, final_text: session.getLastAssistantText()});
} catch (error) {
  emit({type: 'bridge_error', error: String(error)});
} finally {
  session?.dispose();
  lines.close();
  process.exit(0);
}
