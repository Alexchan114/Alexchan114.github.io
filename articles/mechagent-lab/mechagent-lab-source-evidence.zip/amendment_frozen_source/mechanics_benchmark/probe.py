"""Read-only model catalog probe, separate from evaluated engineering runs."""
import argparse
import json
from urllib.parse import urlsplit
import httpx
from .credentials import select
from .security import Trace


def main():
    from pathlib import Path
    parser = argparse.ArgumentParser()
    parser.add_argument("--provider", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    route = select(args.provider)
    host = urlsplit(route.base_url).hostname
    if host not in ("api.moonshot.cn", "api.moonshot.ai", "api.deepseek.com"):
        raise ValueError("Catalog derivation only verified for Moonshot and DeepSeek")
    url = "https://" + host + "/v1/models"
    root = Path(args.output)
    root.mkdir(parents=True, exist_ok=False)
    trace = Trace(root, [route.secret])
    with httpx.Client(timeout=30, trust_env=False, follow_redirects=False) as client:
        response = client.get(url, headers={"Authorization": "Bearer " + route.secret})
    try:
        payload = response.json()
    except ValueError:
        payload = dict(message=response.text[:1200])
    trace.save("catalog.json", dict(scope="read-only connectivity/catalog probe; not benchmark result",
               provider=route.public(), http_status=response.status_code, response=payload))
    print(json.dumps(dict(provider=route.name, status=response.status_code,
        models=[r.get("id") for r in payload.get("data", [])]), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
