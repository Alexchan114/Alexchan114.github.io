"""Original public 3D elastic/plastic reference decks; no industrial inputs."""
from pathlib import Path
import json


def node(i,j,k):
    return 1+9*i+3*j+k


def grid():
    nodes={node(i,j,k):(float(i),float(j),float(k)) for i in range(13) for j in range(3) for k in range(3)}
    elements={}
    for i in range(12):
        for j in range(2):
            for k in range(2):
                elements[1+4*i+2*j+k]=(i,[node(i,j,k),node(i+1,j,k),node(i+1,j+1,k),node(i,j+1,k),
                    node(i,j,k+1),node(i+1,j,k+1),node(i+1,j+1,k+1),node(i,j+1,k+1)])
    return nodes,elements


def nset(name,values):
    values=list(values)
    return '*NSET,NSET='+name+'\n'+'\n'.join(','.join(map(str,values[i:i+12])) for i in range(0,len(values),12))+'\n'


def deck(kind,library=None,cut=6):
    if cut not in (2,4,6,8):
        raise ValueError('Cut must be 2, 4, 6 or 8 mm')
    nodes,elements=grid()
    if kind=='generation':
        selected={e:v for e,v in elements.items() if v[0]<cut}
    elif kind=='reduced':
        selected={e:v for e,v in elements.items() if v[0]>=cut}
    else:
        selected=elements
    wanted={n for _,conn in selected.values() for n in conn}
    retained=list(range(1,10))+list(range(node(cut,0,0),node(cut,0,0)+9))
    if kind=='reduced':wanted.update(retained)
    text='*HEADING\nOriginal public elastic/plastic solid bar; mm-N-MPa\n*NODE\n'
    text+=''.join('{}, {}, {}, {}\n'.format(n,*nodes[n]) for n in sorted(wanted))
    for group,predicate in [('LINEAR',lambda i:i<6),('PLASTIC',lambda i:i>=6)]:
        values={e:v for e,v in selected.items() if predicate(v[0])}
        if not values:continue
        text+='*ELEMENT,TYPE=C3D8,ELSET='+group+'\n'
        text+=''.join(str(e)+','+','.join(map(str,conn))+'\n' for e,(_,conn) in values.items())
        text+='*SOLID SECTION,ELSET='+group+',MATERIAL='+group+'\n,\n'
    if kind=='reduced':
        if not library:raise ValueError('Generated library path required')
        text+='*ELEMENT,TYPE=Z101,ELSET=SUB,FILE='+str(library).replace('\\','/')+'\n'
        text+='999,'+','.join(map(str,retained[:14]))+',\n'+','.join(map(str,retained[14:]))+'\n'
        text+='*SUBSTRUCTURE PROPERTY,ELSET=SUB\n0.,0.,0.\n'
    text+='*MATERIAL,NAME=LINEAR\n*ELASTIC\n1000.,0.\n'
    text+='*MATERIAL,NAME=PLASTIC\n*ELASTIC\n1000.,0.\n*PLASTIC\n1.,0.\n2.,0.02\n'
    if kind=='generation':
        text+=nset('RETAINED',retained)
        return text+'*STEP,NAME=Generate\n*SUBSTRUCTURE GENERATE,TYPE=Z101,RECOVERY MATRIX=NO\n*RETAINED NODAL DOFS\nRETAINED,1,3\n*END STEP\n'
    text+=nset('ROOT',range(1,10))+nset('TIP',range(109,118))
    text+='*BOUNDARY\nROOT,1,3\n*STEP,NAME=Pull,NLGEOM=NO,INC=100\n*STATIC\n0.05,1.,1e-8,0.05\n'
    text+='*BOUNDARY\nTIP,1,1,0.12\n*OUTPUT,FIELD,FREQUENCY=1\n*NODE OUTPUT\nU,RF\n*ELEMENT OUTPUT\nS,PEEQ\n*END STEP\n'
    return text


def prepare(root,cut=6):
    root=Path(root).resolve()
    root.mkdir(parents=True,exist_ok=False)
    for kind in ('full','generation'):
        (root/(kind+'.inp')).write_text(deck(kind,cut=cut),encoding='ascii')
    (root/'fixture.json').write_text(json.dumps(dict(
        scope='original public reference calibration, not an evaluated agent attempt or contact model',
        units='mm-N-MPa',dimensions_mm=[12,2,2],element_type='C3D8',elements=48,nodes=117,
        linear_region_x_mm=[0,6],plastic_region_x_mm=[6,12],E_MPa=1000,nu=0,
        yield_MPa=1,plastic_hardening_MPa=50,final_U1_mm=.12,
        expected_final_force_N=4*(.12+.12)/(.012+.12),
        retained_nodes=list(range(1,10))+list(range(55,64)),
        expected_eliminated_translational_dofs=135),indent=2),encoding='utf-8')
    return root
