"""Render contact sheets for all report pages; page PNGs remain authoritative."""
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw


def main():
    root=Path(__file__).resolve().parents[1]/"outputs/mechanics_agent_benchmark_20261103/publication"
    for language in ("zh","en"):
        pages=sorted(root.glob("qa_"+language+"-*.png"))
        columns=3
        width,height=420,620
        sheet=Image.new("RGB",(columns*width,((len(pages)+columns-1)//columns)*height),"#dbe0e1")
        draw=ImageDraw.Draw(sheet)
        for index,page in enumerate(pages):
            image=Image.open(page).convert("RGB")
            image.thumbnail((width-20,height-32))
            x,y=(index%columns)*width,(index//columns)*height
            sheet.paste(image,(x+(width-image.width)//2,y+24))
            draw.text((x+10,y+5),page.name,fill="black")
        sheet.save(root/("contact_sheet_"+language+".png"))


if __name__ == "__main__":
    main()
