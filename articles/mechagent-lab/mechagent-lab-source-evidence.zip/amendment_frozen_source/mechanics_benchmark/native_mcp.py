"""Three public mechanics capabilities for unmodified native CLI agent loops."""
import argparse
import asyncio
import json
from pathlib import Path
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
from .suite_tools import Broker
from .suite_evaluate import evaluate
from .security import Trace
from .credentials import inventory


async def serve(folder, reference, solver_root):
    folder = Path(folder)
    card = json.loads((folder / 'task.json').read_text(encoding='utf-8'))
    specs = json.loads((folder / 'query.json').read_text(encoding='utf-8'))['tools']
    trace = Trace(folder, [r.secret for r in inventory() if r.secret])
    broker = Broker(card, trace, solver_root, reference)
    server = Server('public-mechanics')
    lock = asyncio.Lock()
    trace.write('native_mcp_start', tool_names=[s['name'] for s in specs])

    @server.list_tools()
    async def list_tools():
        trace.write('native_mcp_catalog', tools=specs)
        return [Tool(name=s['name'], description=s['description'], inputSchema=s['input_schema']) for s in specs]

    @server.call_tool()
    async def call_tool(name, arguments):
        async with lock:
            result = await asyncio.to_thread(broker.call, name, arguments, 'native_' + str(broker.calls + 1))
            state = dict(calls=broker.calls, solver_calls=broker.solver_calls, submitted=broker.submission is not None)
            if broker.submission:
                scoring = evaluate(card, broker.submission['solution'], broker.artifacts)
                trace.save('evaluation.json', scoring)
                state['evaluation'] = scoring
            trace.save('broker_state.json', state)
        return [TextContent(type='text', text=json.dumps(result, ensure_ascii=False, allow_nan=False))]

    async with stdio_server() as (reader, writer):
        await server.run(reader, writer, server.create_initialization_options())


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--folder', required=True)
    p.add_argument('--reference', required=True)
    p.add_argument('--solver-root', required=True)
    a = p.parse_args()
    asyncio.run(serve(a.folder, a.reference, a.solver_root))
