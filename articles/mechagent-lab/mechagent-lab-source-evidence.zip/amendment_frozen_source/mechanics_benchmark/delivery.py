"""Bilingual pilot delivery with real Tavotto export receipts and LaTeX sources."""
import argparse
import html
import json
from pathlib import Path
import shutil
import subprocess
import urllib.request
import zipfile

from .tasks import TASKS


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/"outputs/mechanics_agent_benchmark_20261103"


def tavotto(port):
    session = Path.home()/"AppData/Local/Tavotto/session"/("port-"+str(port)+".json")
    secret = json.loads(session.read_text(encoding="utf-8"))["secret"]
    figures, qa = OUT/"figures", OUT/"qa"
    qa.mkdir(exist_ok=True)

    def call(endpoint, payload=None):
        req = urllib.request.Request("http://127.0.0.1:"+str(port)+endpoint,
            data=None if payload is None else json.dumps(payload).encode(),
            headers={"X-Tavotto-Auth":secret,"Content-Type":"application/json"})
        with urllib.request.urlopen(req, timeout=180) as response:
            result = json.load(response)
        if result.get("error"):
            raise RuntimeError("Tavotto export error: "+str(result["error"]))
        return result

    probe = call("/api/registry/probe", dict(script="benchmark_figures.py",cost="medium"))
    (qa/"tavotto_probe.json").write_text(json.dumps(probe,indent=2),encoding="utf-8")
    if not probe.get("registered"):
        raise RuntimeError("Tavotto did not register executable figure source")
    registry = call("/api/registry")
    (qa/"tavotto_registry.json").write_text(json.dumps(registry,indent=2),encoding="utf-8")
    for stem,height in (("architecture",109.22),("partition",142.24),("pilot",96.52)):
        receipt=call("/api/export",dict(scope="canvas",filename=stem,formats=["pdf","png"],ppi=180,
            background="white",overwrite="replace",canvas=dict(page_w_mm=228.6,page_h_mm=height,
            objects=[dict(type="panel",id=stem+".pdf",x_mm=0,y_mm=0,w_mm=228.6,h_mm=height)])))
        (qa/(stem+"_tavotto_receipt.json")).write_text(json.dumps(receipt,indent=2),encoding="utf-8")
        for suffix in (".pdf",".png"):
            path=figures/"tavottofile/export"/(stem+suffix)
            if not path.is_file():
                raise FileNotFoundError(path)
        print("Verified Tavotto export:",stem,flush=True)


def tex(value):
    table={"\\":r"\textbackslash{}","&":r"\&","%":r"\%","$":r"\$","#":r"\#",
           "_":r"\_","{":r"\{","}":r"\}","~":r"\textasciitilde{}","^":r"\textasciicircum{}"}
    return "".join(table.get(c,c) for c in str(value))


def build():
    summary=json.loads((OUT/"pilot_summary.json").read_text(encoding="utf-8"))
    folder=OUT/"publication"
    folder.mkdir(exist_ok=True)
    for stem in ("architecture","partition","pilot"):
        for suffix in (".pdf",".png"):
            shutil.copy2(OUT/"figures/tavottofile/export"/(stem+suffix),folder/(stem+suffix))
    preamble=r"""\documentclass[UTF8,a4paper,11pt,fontset=windows]{ctexart}
\usepackage[margin=23mm,headheight=15pt]{geometry}
\usepackage{fontspec,amsmath,amssymb,booktabs,tabularx,graphicx,xcolor,enumitem,fancyhdr,caption,placeins}
\usepackage[hidelinks,unicode]{hyperref}
\setmainfont{TeX Gyre Pagella}
\setsansfont{TeX Gyre Heros}
\setmonofont{Consolas}[Scale=.85]
\definecolor{Ink}{HTML}{203746}
\definecolor{Teal}{HTML}{197B77}
\definecolor{Orange}{HTML}{BF6039}
\ctexset{section={format=\Large\bfseries\color{Ink}},subsection={format=\large\bfseries\color{Teal}}}
\setlength{\parskip}{.35em}
\setlength{\emergencystretch}{2em}
\setlist{nosep,leftmargin=1.5em}
\captionsetup{font=small,labelfont=bf}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\small Mechanics Agent Benchmark / v0.1}
\fancyhead[R]{\small AlexanderChan}
\fancyfoot[C]{\thepage}
\newcommand{\code}[1]{\texttt{\detokenize{#1}}}
\newcommand{\fig}[2]{\begin{figure}[htbp]\centering\includegraphics[width=\linewidth]{#1.pdf}\caption{#2}\end{figure}}
\begin{document}
"""
    valid=[r for r in summary["rows"] if not r["classification"].startswith("excluded_")]
    statuses={"passed":("通过","Passed"),"output_budget_exhausted":("输出预算耗尽","Output budget exhausted")}
    for lang in ("zh","en"):
        zh=lang=="zh"
        heading="力学工程自主决策 Agent Benchmark" if zh else "Mechanics Engineering Agent Benchmark"
        body=[preamble+("" if zh else r"\renewcommand{\figurename}{Figure}\renewcommand{\tablename}{Table}"),r"\thispagestyle{empty}",r"{\color{Teal}\sffamily ENGINEERING EVALUATION / 2026.11.03}\par\vspace{1em}",
              r"{\Huge\bfseries\color{Ink}"+(tex(heading) if zh else r"Mechanics Engineering\\Agent Benchmark")+r"}\par\vspace{.8em}",
              r"{\large "+("八道任务设计、受控工具执行与第一轮真实试跑" if zh else "Eight task families, controlled execution and an initial measured pilot")+r"}\par",
              r"\vspace{.8em}AlexanderChan\par\vspace{1em}"]
        body += [r"\noindent\fbox{\parbox{.94\linewidth}{\textbf{"+("开发版范围" if zh else "Development scope")+r".} "+(
            "已定义8道任务，当前2道一维力学算例可执行。4次有效试跑中3次通过，1次输出预算耗尽；另保留2次环境或适配器无效探测。尚未完成三维工业算例、商业求解器任务评测或模型排行榜。"
            if zh else "Eight task families are defined; two 1D mechanics fixtures are executable. Four valid pilot attempts produced three passes and one output-budget exhaustion. Two invalid setup attempts are retained separately. No 3D industrial or vendor-solver task evaluation is claimed.")+r"}}"]
        body += [r"\section{"+("为什么评测力学决策" if zh else "Why evaluate mechanical decisions?")+"}",
            ("评测关注模型能否从物理要求出发，选择区域、载荷、离散精度和验证方法，并交付可检查的工程结果。完成消息不是求解证据，工具调用格式正确也不是力学正确。CORE表示保留细节的核心区，SUB表示凝聚后的子结构区；两者应由响应与适用条件决定，而不是预先赋予重要性标签。"
             if zh else "The benchmark asks whether an agent can turn physical requirements into defensible regions, loads, discretization and verification, then deliver inspectable artifacts. A completion claim is not solve evidence; a valid tool call is not proof of mechanics. CORE denotes the retained detailed region and SUB a condensed substructure, not a predetermined importance label."),
            r"\fig{architecture}{"+("模型、执行框架、受控工具与独立评分分层。图中实线表示当前试跑路径；54个商业CAE MCP工具仅完成连接与schema预检，尚未作为参评任务调用。"
              if zh else "Separate model, harness, controlled tools and host validation. The pilot uses numerical fixture tools; 54 commercial-CAE MCP schemas were connectivity-probed, not exercised as evaluated task calls.")+"}"]
        body += [r"\section{"+("八道任务与执行状态" if zh else "Task families and implementation state")+"}",
                 r"\noindent\begin{tabularx}{\linewidth}{@{}l X l@{}}\toprule ID & "+("任务" if zh else "Task")+" & "+("状态" if zh else "Status")+r" \\\midrule"]
        for key,task in TASKS.items():
            state=("力学算例可执行" if zh else "Fixture executable") if task["status"]=="executable_fixture" else ("规范已定义" if zh else "Specified only")
            body += [tex(key)+" & "+tex(task["title_zh" if zh else "title"])+" & "+state+r" \\"]
        body += [r"\bottomrule\end{tabularx}",
            ("每道任务均需独立输入、产物清单与评分器。后续隐藏变体不能用于调试提示词；八道任务不能支撑广泛的能力排名。"
             if zh else "Each task requires independent inputs, deliverables and validators. Held-out variants must not be used for prompt tuning; eight families do not support broad capability rankings.")]
        for key,task in TASKS.items():
            body += [r"\subsection{"+key+": "+tex(task["title_zh" if zh else "title"])+"}",tex(task["query_"+lang])]
        body += [r"\section{"+("两道已执行任务的力学依据" if zh else "Mechanics behind the executable fixtures")+"}",
            r"\subsection{"+("M01：力平衡与解析对照" if zh else "M01: equilibrium and analytical reference")+"}",
            ("阶梯杆采用毫米、牛顿、兆帕单位制。工具通过直接刚度法求解，评分器另用串联杆解析解核验。检查位移、反力符号、各段应力和应变能。"
             if zh else "The stepped bar uses mm, N and MPa. A direct-stiffness solver produces the artifact; the independent validator uses the analytical series-bar solution, checking displacement, reaction sign, segment stress and strain energy."),
            r"\begin{align} u_{\rm tip}&=F\sum_i\frac{L_i}{E_i A_i}, & R&=-F,\\ \sigma_i&=\frac{F}{A_i}, & \mathcal{U}&=\frac12 F u_{\rm tip}.\end{align}",
            r"\subsection{"+("M04：活动非线性与静力凝聚" if zh else "M04: active nonlinearity and static condensation")+"}",
            ("任务不是将所有低应力区域删除。六段串联系统中，r4与r6在载荷包络内进入不同刚度分支，因此必须保留其活动非线性。线性连续段r1至r3可凝聚内部自由度1、2，固定端0与接口3仍保留。下式通过求解线性系统实现，而不显式求逆。"
             if zh else "The task is not to delete every low-stress region. Regions r4 and r6 change stiffness within the load envelope and must retain their active nonlinearity. Linear regions r1--r3 can eliminate interior DOFs 1 and 2 while retaining fixed DOF 0 and interface DOF 3. Implement the following expression through linear solves, not explicit inversion."),
            r"\begin{equation}\overline{\mathbf{K}}=\mathbf{K}_{rr}-\mathbf{K}_{ri}\mathbf{K}_{ii}^{-1}\mathbf{K}_{ir}.\end{equation}",
            ("正确分区的端位移在1、5、12 N载荷下与完整双线性系统一致。错误地把所有段冻结为线性时，高载荷端位移发生偏差。此验证仅针对一维力学算例，不代表Abaqus工业子结构性能。"
             if zh else "The accepted partition reproduces the full bilinear tip response at 1, 5 and 12 N. Incorrectly freezing the whole assembly as linear changes the high-load response. This verifies a 1D mechanics fixture, not industrial Abaqus substructure performance."),
            r"\fig{partition}{"+("分区与载荷包络验证。曲线来自公开算例的实际数值计算，不是连接器试验数据。"
             if zh else "Partition and load-envelope verification from actual calculations on the public fixture; these are not connector experimental measurements.")+"}"]
        body += [r"\section{"+("真实试跑结果及边界" if zh else "Measured pilot and its limits")+"}",
            ("Kimi使用CCS现有密钥与只读清单返回的kimi-k2.6。DeepSeek使用原配置的deepseek-v4-flash请求标识，通过真实Pi SDK执行。服务商内部别名映射并非始终可观测，不能仅凭模型自述确认底层版本。"
             if zh else "Kimi used existing CCS credentials with the catalog-returned kimi-k2.6 ID. DeepSeek used the configured deepseek-v4-flash request ID through the actual Pi SDK. Internal provider alias resolution is not always observable; self-identification is not version evidence."),
            r"\noindent\begin{tabularx}{\linewidth}{@{}l X r X@{}}\toprule "+("题目 & 配置 & 秒 & 结果" if zh else "Task & Configuration & Seconds & Outcome")+r" \\\midrule"]
        for row in valid:
            body += [row["task"]+" & "+("Pi + DeepSeek" if row["harness"]=="pi" else "mini + Kimi")+" & "+str(round(row["elapsed_seconds"],2))+" & "+statuses[row["classification"]][0 if zh else 1]+r" \\"]
        body += [r"\bottomrule\end{tabularx}",
            ("输出预算为每请求4096 token；Kimi的M04试跑在该预算下未提交解答。该结果是预算条件下的未完成，不代表无条件的力学能力判断。原kimi-k2.5返回404、首次Pi工具注册错误，均保留且从有效次数中排除。模型和框架在两组之间同时改变，因此不得把耗时差异归因于单一因素。"
             if zh else "The per-request output allocation was 4096 tokens. Kimi's M04 run did not submit under that allocation; this is a budget-conditioned outcome, not an unconditional mechanics judgment. The unavailable kimi-k2.5 route and the first Pi tool-registration error are retained but excluded. Both model and harness differ between groups, so timing differences are not attributable to one factor."),
            r"\fig{pilot}{"+("四次有效试跑的墙钟时间与结果，不构成模型或框架排名。橙色表示预算耗尽，不是接触失效或求解器失效。"
             if zh else "Wall times and outcomes of four valid pilot attempts, not a model/harness ranking. Orange denotes an output-budget outcome, not mechanical or solver failure.")+"}"]
        body += [r"\section{"+("评分、轨迹与费用" if zh else "Scoring, traces and costs")+"}",
            ("两道已执行题均使用明确数值子项，而不是语言模型主观裁判。没有求解或凝聚产物不能满分；错误分区、漏接口、伪报误差及没有任何实际自由度减少的方案分别扣分。全保留方案可能物理正确，但不获得降阶收益分。完整三维赛道的误差阈值、资源预算和指标仍需独立参考算例标定后冻结。"
             if zh else "Executable fixtures use numerical checks, not an LLM judge. Missing artifacts prevent full credit; incorrect partitions, missing interfaces, fabricated error and zero DOF elimination are scored separately. An all-CORE model may be physically correct but receives no reduction benefit. Full 3D error thresholds and compute budgets require independent calibration before registration."),
            ("每次请求和返回、工具参数和结果、Pi可导出会话、最终提交与评分均写入JSONL和中英文可阅读附录。原始轨迹保留，包括被排除的探测；不重构厂商未暴露的提示或思维过程。文件以SHA256校验。参评模型没有文件、shell、任意代码或网络工具；这不是对任意原生agent的操作系统隔离承诺。"
             if zh else "Every observable request/response, tool call/result, exported Pi session, submission and score is retained in JSONL and readable bilingual appendices, including excluded probes. Unexposed internal prompts or reasoning are not reconstructed. SHA256 identifies artifacts. Evaluated models have no filesystem, shell, arbitrary-code or network tools; this does not claim OS isolation for unrestricted native agents."),
            ("输入、缓存读写与输出token分别记录，推理若已含于输出不重复累加。API账单未知；Pi SDK的零成本字段只是元数据占位，不能解释为免费。作者的连接探测、写报告和制图不计入参评任务耗时或token。正式96次重复评测尚未启动。"
             if zh else "Input, cache reads/writes and output tokens are separate; reasoning included in output is not added twice. API invoices are unavailable. Pi SDK zero-cost fields are placeholders, not free usage. Author probes, documentation and figure preparation are excluded from task time and tokens. The proposed 96-run campaign has not started.")]
        body += [r"\section{"+("复现与下一阶段" if zh else "Reproduction and next stage")+"}",
            ("在项目根目录运行下列命令。密钥由CCS只读数据库解析，无需复制到命令或配置文件。输出目录必须不存在。"
             if zh else "Run from the project root. Credentials are resolved read-only from CCS and are not copied into commands or provider files. Choose a new output directory."),
            r"\begin{quote}\small\code{python -m mechanics_benchmark inventory}\\\code{python -m mechanics_benchmark tasks}\\\code{python -m unittest discover -s mechanics_benchmark/tests -v}\end{quote}",
            ("下一阶段为M02、M03、M05至M08补齐可公开三维输入、真实软件执行及独立评分，扩展M04至实际子结构区域决策，再冻结比较矩阵与费用上限。原APP、工业模型、历史任务和CCS当前线路均未改动。"
             if zh else "Next, supply public 3D inputs, real application execution and independent validators for M02, M03 and M05--M08, extend M04 to actual substructure-region decisions, then freeze the comparison matrix and spending limits. Production APP, industrial models, historical tasks and active CCS routes were not modified."),
            r"\subsection{"+("随附证据" if zh else "Accompanying evidence")+"}",
            ("源码包包含题目卡、中英文逐轮query/output附录、原始轨迹、数值产物、汇总CSV/JSON、哈希清单及Tavotto脚本与导出回执。未包含CCS数据库、商业软件、API密钥、私有几何或工业仿真数据。"
             if zh else "The source/evidence bundle contains task cards, bilingual query/output appendices, raw traces, numerical artifacts, CSV/JSON summaries, hashes and Tavotto sources/export receipts. It excludes the CCS database, commercial software, API credentials, private geometry and industrial simulation data."),r"\end{document}"]
        (folder/("benchmark_"+lang+".tex")).write_text("\n\n".join(body),encoding="utf-8")
    return folder


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--tavotto-port",type=int)
    args=parser.parse_args()
    if args.tavotto_port:
        tavotto(args.tavotto_port)
    else:
        print(build())
