"""Host reference calibration via real MCP, excluded from model evaluation counts."""
import argparse
import asyncio
from contextlib import AsyncExitStack
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from .solid_reference import prepare,deck


async def main(root,resume=False,cut=6):
    if resume:
        for kind in ('full','generation'):
            if (root/(kind+'.inp')).read_text(encoding='ascii')!=deck(kind,cut=cut):
                raise ValueError('Reference inputs changed; use a new directory')
    else:
        root=prepare(root,cut=cut)
    trace=root/'mcp_trace.jsonl'
    records=json.loads((root/'progress.json').read_text()) if resume else {}
    async with AsyncExitStack() as stack:
        streams=await stack.enter_async_context(stdio_client(StdioServerParameters(command=sys.executable,
            args=['-m','cae_mcp','serve','abaqus'],cwd='D:/kimi/cae-mcp',
            env=dict(os.environ,CAE_MCP_ROOT='D:/kimi/cae-mcp'))))
        session=await stack.enter_async_context(ClientSession(*streams))
        await session.initialize()

        async def call(name,args):
            with trace.open('a',encoding='utf-8') as f:f.write(json.dumps(dict(event='request',tool=name,arguments=args,time=time.time()))+'\n')
            value=await session.call_tool(name,args)
            data=value.structuredContent
            if data is None:
                raw=next(c.text for c in value.content if c.type=='text')
                try:data=json.loads(raw)
                except ValueError:data=dict(error=raw)
            with trace.open('a',encoding='utf-8') as f:f.write(json.dumps(dict(event='response',tool=name,result=data,time=time.time()))+'\n')
            if value.isError:raise RuntimeError(str(data))
            return data

        async def stage(label,tool,args):
            previous=records.get(label,{})
            if previous.get('state',{}).get('status')=='succeeded':
                state=await call('abaqus_job_status',dict(job_id=previous['submitted']['job_id']))
                if state['status']!='succeeded':raise ValueError('Reference job state changed')
                return state['result']
            submitted=await call(tool,args)
            records[label]=dict(submitted=submitted,previous_attempts=([previous] if previous else []))
            (root/'progress.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
            for _ in range(400):
                state=await call('abaqus_job_status',dict(job_id=submitted['job_id']))
                if state['status'] in ('succeeded','failed','cancelled','timed_out','orphaned'):
                    records[label]['state']=state
                    (root/'progress.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
                    if state['status']!='succeeded':raise RuntimeError(label+' failed: '+str(state))
                    return state['result']
                await asyncio.sleep(2)
            raise TimeoutError(label)

        options=dict(cpus=1,memory_percent=10,datacheck=False)
        full=await stage('full','abaqus_submit_job',dict(request=dict(inp_path=str(root/'full.inp'),**options)))
        generated=await stage('generation','abaqus_submit_job',dict(request=dict(inp_path=str(root/'generation.inp'),**options)))
        library=Path(generated['odb_path']).with_suffix('')
        if not Path(str(library)+'_Z101.sim').is_file():raise FileNotFoundError('Missing actual generated SIM library')
        (root/'reduced.inp').write_text(deck('reduced',library,cut=cut),encoding='ascii')
        reduced=await stage('reduced','abaqus_submit_job',dict(request=dict(inp_path=str(root/'reduced.inp'),**options)))
        paths=dict(full_odb=full['odb_path'],reduced_odb=reduced['odb_path'])
        script=root/'extract_reference.py'
        script.write_text("""from odbAccess import openOdb
import json
paths = %r
result = {}
for label,path in paths.items():
    odb=openOdb(path,readOnly=True)
    rows=[]
    for frame in odb.steps['Pull'].frames:
        u=[v for v in frame.fieldOutputs['U'].values if 109<=v.nodeLabel<=117]
        rf=[v for v in frame.fieldOutputs['RF'].values if 109<=v.nodeLabel<=117]
        root=[v for v in frame.fieldOutputs['RF'].values if 1<=v.nodeLabel<=9]
        if len(u)!=9 or len(rf)!=9 or len(root)!=9:
            raise ValueError('Reference endpoint node coverage differs')
        peeq=frame.fieldOutputs['PEEQ'] if 'PEEQ' in frame.fieldOutputs else None
        rows.append(dict(time=frame.frameValue,U1=sum(v.data[0] for v in u)/len(u),
            tip_RF1=sum(v.data[0] for v in rf),root_RF1=sum(v.data[0] for v in root),
            max_PEEQ=max([v.data for v in peeq.values] or [0]) if peeq else 0))
    result[label]=rows
    odb.close()
with open(%r,'w') as f: json.dump(result,f,indent=2)
"""%(paths,str(root/'curves.json')),encoding='ascii')
        await stage('extract','abaqus_run_python_script',dict(request=dict(script_path=str(script),mode='python')))
    curves=json.loads((root/'curves.json').read_text())
    expected=json.loads((root/'fixture.json').read_text())['expected_final_force_N']
    a,b=(curves[k][-1] for k in ('full_odb','reduced_odb'))
    elastic=[r for r in curves['full_odb'] if 1e-7<r['U1']<.011]
    full_curve,reduced_curve=curves['full_odb'],curves['reduced_odb']
    aligned=len(full_curve)==len(reduced_curve) and all(abs(x['time']-y['time'])<1e-8 for x,y in zip(full_curve,reduced_curve))
    max_curve_error=max(abs(x['tip_RF1']-y['tip_RF1']) for x,y in zip(full_curve,reduced_curve)) if aligned else None
    checks=dict(endpoint=all(abs(r['time']-1)<1e-8 and abs(r['U1']-.12)<1e-7 for r in (a,b)),
        elastic_analytic=bool(elastic) and all(abs(r['tip_RF1']-1000*4*r['U1']/12)<1e-4 for r in elastic),
        force_balance=all(abs(r['tip_RF1']+r['root_RF1'])<1e-5 for r in (a,b)),
        plastic_active=all(r['max_PEEQ']>0 for r in (a,b)),
        reduced_force=abs(a['tip_RF1']-b['tip_RF1'])/abs(a['tip_RF1'])<.001,
        curve_equivalence=aligned and max_curve_error<1e-4)
    output=dict(scope='host calibration; not agent score; no contact or industrial speedup claim',
        checks=checks,passed=all(checks.values()),full_final=a,reduced_final=b,
        validation_basis='elastic analytical check plus independent full/reduced 3D solves; not a 1D plastic exact solution',
        plastic_1d_diagnostic=dict(approximation_force_N=expected,full_3d_force_N=a['tip_RF1'],
            relative_difference=abs(a['tip_RF1']-expected)/expected,
            note='Not an exact 3D solution: lateral plastic contraction and interface constraints are absent from the 1D approximation. Original strict-check failure retained in validation_history.'),
        max_curve_difference_N=max_curve_error,
        input_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.inp')},jobs=records)
    if (root/'validation.json').is_file():
        history=root/'validation_history.jsonl'
        with history.open('a',encoding='utf-8') as f:f.write(json.dumps(json.loads((root/'validation.json').read_text()))+'\n')
    (root/'validation.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(json.dumps(dict(checks=checks,passed=output['passed'],directory=str(root)),indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--resume',action='store_true');a=p.parse_args()
    asyncio.run(main(a.output.resolve(),a.resume))
