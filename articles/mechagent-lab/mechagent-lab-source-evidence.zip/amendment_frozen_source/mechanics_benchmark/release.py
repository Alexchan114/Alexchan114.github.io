"""Stage an allowlisted, secret-scanned preview; publishing remains an explicit git action."""
import hashlib
import html
import json
from pathlib import Path
import shutil
import zipfile

from .credentials import inventory
from .tasks import TASKS


ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs/mechanics_agent_benchmark_20261103"
ASSET="/articles/mechanics-agent-benchmark/"


def main():
    summary=json.loads((OUT/"pilot_summary.json").read_text(encoding="utf-8"))
    website=OUT/"website"
    source=website/"site-src"
    assets=source/"static/articles/mechanics-agent-benchmark"
    assets.mkdir(parents=True,exist_ok=True)
    staged=[]
    for pattern in ("benchmark_*.pdf","benchmark_*.tex","architecture.pdf","architecture.png",
                    "partition.pdf","partition.png","pilot.pdf","pilot.png"):
        for path in (OUT/"publication").glob(pattern):
            shutil.copy2(path,assets/path.name)
            staged.append(assets/path.name)
    for name in ("pilot_summary.json","pilot_summary.csv","evidence_manifest.json","privacy_audit.json"):
        shutil.copy2(OUT/name,assets/name)
        staged.append(assets/name)
    # Explicit evidence/source allowlist; no runtime, databases, vendor assets or server logs.
    bundle=assets/"mechanics-benchmark-v0.1-source-evidence.zip"
    entries={}
    for pattern in ("*.py","*.mjs","*.md","requirements.txt"):
        for path in (ROOT/"mechanics_benchmark").rglob(pattern):
            if "__pycache__" not in path.parts:
                entries["mechanics_benchmark/"+path.relative_to(ROOT/"mechanics_benchmark").as_posix()]=path
    for path in (OUT/"pilot").rglob("*"):
        if path.is_file() and path.suffix in (".json",".jsonl"):
            entries["evidence/"+path.relative_to(OUT).as_posix()]=path
    for path in (OUT/"documentation").glob("*.md"):
        entries["documentation/"+path.name]=path
    for name in ("pilot_summary.json","pilot_summary.csv","evidence_manifest.json","privacy_audit.json"):
        entries[name]=OUT/name
    for path in (OUT/"publication").glob("*.tex"):
        entries["publication/"+path.name]=path
    for path in (OUT/"publication").glob("*.pdf"):
        entries["publication/"+path.name]=path
    for path in (OUT/"figures").glob("*"):
        if path.is_file() and path.suffix in (".py",".json",".pdf"):
            entries["figures/"+path.name]=path
    for path in (OUT/"qa").glob("*tavotto*.json"):
        entries["figure_provenance/"+path.name]=path
    for name in ("package.json","package-lock.json"):
        path=OUT/"pi-runtime"/name
        if path.is_file():
            entries["pi-runtime/"+name]=path
    secrets=[r.secret.encode() for r in inventory() if len(r.secret)>=8]
    hashes={}
    with zipfile.ZipFile(bundle,"w",zipfile.ZIP_DEFLATED) as archive:
        for name,path in sorted(entries.items()):
            content=path.read_bytes()
            if any(secret in content for secret in secrets):
                raise ValueError("Release blocked: credential-value match")
            hashes[name]=hashlib.sha256(content).hexdigest()
            archive.writestr(name,content)
        archive.writestr("release_manifest.json",json.dumps(hashes,indent=2))
    staged.append(bundle)
    for lang in ("zh","en"):
        zh=lang=="zh"
        title="让力学决策经得起验证：Agent Benchmark 开发试跑" if zh else "Testing Mechanical Decisions: An Agent Benchmark Development Pilot"
        description="8道工程任务的评测设计、Kimi与DeepSeek/Pi真实试跑、完整query/output和Tavotto配图。v0.1仅2题可执行。" if zh else "Eight engineering task families, measured Kimi and DeepSeek/Pi pilot runs, observable traces and Tavotto figures. Two fixtures are executable in v0.1."
        body=["---", "title: "+json.dumps(title,ensure_ascii=False), "date: 2026-11-03",'slug: "mechanics-agent-benchmark"',
            'author: "AlexanderChan"',"description: "+json.dumps(description,ensure_ascii=False),
            'categories: ["Engineering"]','tags: ["Mechanics", "Agent", "Benchmark", "MCP", "LaTeX"]',
            'connector_article: true',"---",'<article class="cae-article">']
        body += ['<p class="article-downloads">'+
            f'<a href="{ASSET}benchmark_zh.pdf">中文 PDF</a> · <a href="{ASSET}benchmark_en.pdf">English PDF</a> · '+
            f'<a href="{ASSET}{bundle.name}">'+("代码、题库与完整轨迹" if zh else "Code, tasks and complete traces")+'</a></p>']
        body += ['<blockquote><p><strong>'+('开发试跑，不是排行榜。' if zh else 'Development pilot, not a leaderboard.')+'</strong> '+
            ('8道任务已定义，2道一维力学算例可执行。4次有效任务中3次通过、1次输出预算耗尽；另2次环境/适配器探测保留并排除。尚无参评三维工业求解结果。'
             if zh else 'Eight task families are specified and two 1D mechanics fixtures execute. Four valid attempts yielded three passes and one output-budget exhaustion; two invalid setup attempts remain in the evidence. No evaluated 3D industrial solve is claimed.')+'</p></blockquote>']
        body += ['<h2>'+('从工程经验到可验证任务' if zh else 'From engineering experience to verifiable tasks')+'</h2>',
            '<p>'+('把建模、子结构分区、公差施加、接触分析与边界搜索组织成可执行任务。模型不仅要给出建议，还要调用工具、生成产物，并接受独立数值核验。模型、执行框架和工具配置分别记录，不能把某个客户端的效果归因于模型本身。'
             if zh else 'Turn modeling, substructure partitioning, tolerance application, contact analysis and boundary search into executable tasks. Agents must operate tools and produce artifacts that survive independent numerical validation. Model, harness and tool configuration are recorded separately.')+'</p>']

        def figure(stem,caption):
            return f'<figure><a href="{ASSET}{stem}.pdf"><img src="{ASSET}{stem}.png" alt="{html.escape(caption)}" loading="lazy" style="width:100%;height:auto"></a><figcaption>{html.escape(caption)}</figcaption></figure>'

        body += [figure("architecture","模型、框架、工具与评分分层；当前试跑不包含商业求解器任务执行。" if zh else "Separate model, harness, tools and scoring; this pilot does not evaluate vendor solver tasks."),
            '<h2>'+('八道题' if zh else 'Eight task families')+'</h2>',
            '<div class="table-scroll"><table><thead><tr><th>ID</th><th>'+('任务' if zh else 'Task')+'</th><th>'+('状态' if zh else 'State')+'</th></tr></thead><tbody>']
        for key,task in TASKS.items():
            state=('算例可执行' if zh else 'Fixture executable') if task["status"]=="executable_fixture" else ('规范已定义' if zh else 'Specified only')
            body += ['<tr><td>'+key+'</td><td>'+html.escape(task["title_zh" if zh else "title"])+'</td><td>'+state+'</td></tr>']
        body += ['</tbody></table></div>',
            '<h2>'+('重要区域由力学证据决定' if zh else 'Importance must be justified mechanically')+'</h2>',
            '<p>'+('在已执行的自主分区算例中，保留活动双线性区域，将连续线性段凝聚，并保留接口自由度。不能只凭低应力决定某一区域不重要；最终要核验载荷包络下的目标响应。图中降阶一致性仅适用于该公开一维算例。'
             if zh else 'The executable partition fixture preserves active bilinear regions, condenses a contiguous linear segment and retains interface DOFs. Low stress alone does not establish irrelevance. Validate the target response over the load envelope; the figure demonstrates only this public 1D fixture.')+'</p>',
            figure("partition","分区和独立载荷包络检查，不是连接器实验曲线。" if zh else "Partition and load-envelope checks, not connector experimental curves."),
            '<h2>'+('真实试跑与不确定性' if zh else 'Measured pilot and uncertainty')+'</h2>',
            '<div class="table-scroll"><table><thead><tr><th>Task</th><th>Configuration</th><th>s</th><th>Outcome</th></tr></thead><tbody>']
        for row in summary["rows"]:
            if row["classification"].startswith("excluded_"):continue
            body += [f'<tr><td>{row["task"]}</td><td>{"Pi + DeepSeek" if row["harness"]=="pi" else "mini + Kimi"}</td><td>{row["elapsed_seconds"]:.2f}</td><td>{html.escape(row["classification"])}</td></tr>']
        body += ['</tbody></table></div>',figure("pilot","4次有效试跑，不能据此排名模型或框架。" if zh else "Four valid pilot attempts, not evidence for a model or harness ranking."),
            '<p>'+('Kimi原配置kimi-k2.5返回不可用/无权限，实际使用只读清单中的kimi-k2.6。DeepSeek请求标识为deepseek-v4-flash，Pi SDK固定为0.73.1。单次输出上限4096 token。模型和框架同时改变，耗时不能作为单一因素的因果比较。API实际账单未知，SDK的零成本字段不是免费。'
             if zh else 'The configured kimi-k2.5 route was unavailable; the pilot explicitly selected catalog-listed kimi-k2.6. DeepSeek used request ID deepseek-v4-flash through Pi SDK 0.73.1. Output was capped at 4096 tokens per request. Model and harness change together, preventing causal attribution. Actual API invoices are unknown; SDK zero-cost fields do not imply free usage.')+'</p>',
            '<h2>'+('完整证据与下一步' if zh else 'Evidence and next steps')+'</h2>',
            '<p>'+('下载包保留所有尝试的query、逐轮请求/输出、工具调用、数值产物、独立评分、中英文附录与哈希清单；不包含密钥、CCS数据库或私有工业模型。现有三个CAE MCP的54项工具完成只读连接预检，此准备工作不计入agent试跑成绩。下一阶段补齐其余6题的公开三维工程输入、软件执行与独立评分，再开展预注册重复评测。'
             if zh else 'The bundle retains all attempts, queries, observable requests/outputs, tool interactions, numerical artifacts, independent checks, bilingual appendices and hashes. It excludes keys, the CCS database and private industrial models. A separate read-only probe verified 54 tools across three CAE MCP services; setup work is not agent evaluation. Next come public 3D fixtures and validators for the remaining six families, followed by a preregistered repeated campaign.')+'</p>',
            f'<p><a href="{ASSET}pilot_summary.csv">Pilot CSV</a> · <a href="{ASSET}pilot_summary.json">Pilot JSON</a> · <a href="{ASSET}{bundle.name}">Source / evidence ZIP</a></p>', '</article>']
        post=source/"content/post"/("mechanics-agent-benchmark"+(".en" if not zh else "")+".md")
        post.write_text("\n".join(body),encoding="utf-8")
        staged.append(post)
    for path in staged:
        if any(secret in path.read_bytes() for secret in secrets):
            raise ValueError("Website credential audit failed")
    receipt=dict(stage="review-ready; not pushed",assets=len(staged),bundle_files=len(entries),
        bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),private_engineering_files=False)
    (OUT/"qa/release_audit.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
    shutil.copy2(bundle,OUT/bundle.name)
    served=website/"articles/mechanics-agent-benchmark"
    served.mkdir(parents=True,exist_ok=True)
    for path in assets.iterdir():
        if path.is_file():
            shutil.copy2(path,served/path.name)
            if hashlib.sha256(path.read_bytes()).digest()!=hashlib.sha256((served/path.name).read_bytes()).digest():
                raise ValueError("Generated site asset differs from source asset")
    print(json.dumps(receipt,indent=2))


if __name__ == "__main__":
    main()
