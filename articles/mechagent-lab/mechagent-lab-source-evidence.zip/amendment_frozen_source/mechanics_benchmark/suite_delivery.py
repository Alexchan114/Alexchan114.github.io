"""v0.2 audited local delivery; public archive is built from an explicit allowlist."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile
from .credentials import inventory
from .report import usage
from .security import scrub

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/mechanics_agent_benchmark_v02_20261104'
WEBSITE=OUT/'website'
ASSET='/articles/mechanics-benchmark-v02/'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def public_text(text):
    # API errors can contain account identifiers even when no full key is present.
    return re.sub(r'org-[A-Za-z0-9<>_-]+','[ACCOUNT REDACTED]',text)


def summarize():
    reg=read(OUT/'preregistration.json');rows=[];transcripts=[]
    amended=OUT/'amendment'
    entries=[(OUT,'initial',entry) for entry in reg['matrix']]
    entries += [(amended,'amended',entry) for entry in read(amended/'preregistration.json')['matrix']]
    for base,phase,entry in entries:
        folder=base/'pilot'/(entry['configuration']+'-'+entry['task']+'-a1')
        m=read(folder/'run.json')
        if m['status']=='running':raise ValueError('Pilot still running')
        events=[json.loads(l) for l in (folder/'trace.jsonl').read_text(encoding='utf-8').splitlines()]
        if m['status']=='execution_error':classification='environment_error'
        elif m.get('evaluation',{}).get('status')=='passed':classification='passed'
        else:classification='failed_or_budget'
        if phase=='initial' and m['task_id'] in ('S06','S08'):classification='excluded_task_ambiguity'
        if phase=='amended' and m['task_id']=='S08':classification='excluded_policy_ambiguity'
        if m['adapter']=='pi':
            ready=next((e for e in events if e['kind']=='pi_harness_ready'),{})
            if set(ready.get('active_tools',[]))!={'inspect_fixture','experiment','submit_solution'}:
                classification='adapter_invalid'
        rows.append(dict(task=m['task_id'],phase=phase,configuration=entry['configuration'],tier=m['tier'],
            status=m['status'],classification=classification,
            raw_score=m.get('evaluation',{}).get('score'),
            score=None if classification in ('environment_error','adapter_invalid','excluded_task_ambiguity','excluded_policy_ambiguity') else m.get('evaluation',{}).get('score',0),
            elapsed_seconds=m['elapsed_seconds'],tool_calls=m['tool_calls'],solver_tests=m['solver_tests'],**usage(events)))
        transcripts.append((folder,m,events))
    summary=dict(version='0.2.2',attempts=len(rows),initial_attempts=8,protocol_amendment_attempts=2,task_count=8,
        vendor_cae_tasks=1,reduced_physics_tasks=7,
        passed=sum(r['classification']=='passed' for r in rows),
        environment_errors=sum(r['classification']=='environment_error' for r in rows),
        excluded_task_ambiguities=sum(r['classification']=='excluded_task_ambiguity' for r in rows),
        excluded_policy_ambiguities=sum(r['classification']=='excluded_policy_ambiguity' for r in rows),
        valid_attempts=sum(r['classification'] not in ('environment_error','adapter_invalid','excluded_task_ambiguity','excluded_policy_ambiguity') for r in rows),
        rows=rows,actual_billed_usd=None,
        limitation='Single attempt per task, different tasks/model/harness together; no model ranking or confidence intervals.')
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
    with (OUT/'summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    docs=OUT/'documentation';docs.mkdir(exist_ok=True)
    for lang in ('zh','en'):
        title='逐轮输入输出与工具审计' if lang=='zh' else 'Observable queries, outputs and tool audit'
        lines=['# '+title,'','Every observable event is retained; private account identifiers are redacted in public copies. Hidden internal prompts or reasoning are not invented.','']
        for folder,m,events in transcripts:
            lines+=['## '+folder.relative_to(OUT).as_posix(),'','```json',public_text(json.dumps(m,ensure_ascii=False,indent=2)),'```',
                '### Original query','```json',json.dumps(read(folder/'query.json'),ensure_ascii=False,indent=2),'```']
            for e in events:
                lines+=['### Event {} / {}'.format(e['index'],e['kind']),'```json',public_text(json.dumps(e,ensure_ascii=False,indent=2)),'```','']
        (docs/('QUERY_OUTPUTS_'+lang.upper()+'.md')).write_text('\n'.join(lines),encoding='utf-8')
        cards=['# '+('八道题与判分依据' if lang=='zh' else 'Eight tasks and scoring basis'),'']
        from .suite_v2 import task_cards
        for key,c in task_cards().items():
            cards+=['## '+key+' '+c['title_zh' if lang=='zh' else 'title'],'',c['query'],'',
                'Tier: '+c['tier'],'','```json',json.dumps(dict(fixture=c['fixture'],output=c['output']),ensure_ascii=False,indent=2),'```','']
        (docs/('TASK_CARDS_'+lang.upper()+'.md')).write_text('\n'.join(cards),encoding='utf-8')
    return summary


def figure_data():
    from .suite_physics import sample
    reg=read(OUT/'preregistration.json')
    candidate=Path('D:/kimi/benchmark_public/v02_agent/deepseek-pi-S04-a1')
    data=dict(summary=read(OUT/'summary.json'),curves=read(candidate/'curves.json'),
        sampling={m:[r[0] for r in sample(reg['tasks']['S05']['fixture'],m,20261104)['amplitudes']]
            for m in ('MC','LHS','Sobol','Halton')},
        provenance=dict(curves='actual evaluated S04 candidate full/reduced ODB extraction',
            sampling='author illustration from frozen S05 sampling code, not model score or efficiency comparison'))
    (OUT/'figures/figure_data.json').write_text(json.dumps(data,indent=2))


def tavotto(port):
    import urllib.request
    session=Path.home()/'AppData/Local/Tavotto/session'/('port-'+str(port)+'.json')
    secret=read(session)['secret'];qa=OUT/'qa';qa.mkdir(exist_ok=True)
    def call(endpoint,payload=None):
        req=urllib.request.Request('http://127.0.0.1:'+str(port)+endpoint,
            data=None if payload is None else json.dumps(payload).encode(),
            headers={'X-Tavotto-Auth':secret,'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=180) as response:r=json.load(response)
        if r.get('error'):raise RuntimeError('Tavotto: '+str(r['error']))
        return r
    probe=call('/api/registry/probe',dict(script='benchmark_v02_figures.py',cost='medium'))
    (qa/'tavotto_probe.json').write_text(json.dumps(probe,indent=2))
    if not probe.get('registered'):raise ValueError('Tavotto figure source registration failed')
    for stem,height in [('workflow',114.3),('solid',114.3),('sampling',139.7),('outcomes',139.7)]:
        receipt=call('/api/export',dict(scope='canvas',filename=stem,formats=['pdf','png'],ppi=180,
            background='white',overwrite='replace',canvas=dict(page_w_mm=228.6,page_h_mm=height,
                objects=[dict(type='panel',id=stem+'.pdf',x_mm=0,y_mm=0,w_mm=228.6,h_mm=height)])))
        (qa/(stem+'_tavotto_receipt.json')).write_text(json.dumps(receipt,indent=2))
        (OUT/'publication').mkdir(exist_ok=True)
        for suffix in ('.pdf','.png'):
            source=OUT/'figures/tavottofile/export'/(stem+suffix)
            if not source.is_file():raise FileNotFoundError(source)
            shutil.copy2(source,OUT/'publication'/source.name)
        print('Verified Tavotto export',stem,flush=True)


def tex(value):
    escape={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}'}
    return ''.join(escape.get(c,c) for c in str(value))


def documents():
    s=read(OUT/'summary.json');reg=read(OUT/'preregistration.json')
    folder=OUT/'publication';folder.mkdir(exist_ok=True)
    preamble=r'''\documentclass[UTF8,a4paper,11pt,fontset=windows]{ctexart}
\usepackage[margin=23mm,headheight=15pt]{geometry}
\usepackage{amsmath,amssymb,booktabs,tabularx,longtable,graphicx,xcolor,fancyhdr,caption,placeins,enumitem}
\usepackage[hidelinks,unicode]{hyperref}
\setmainfont{TeX Gyre Pagella}
\setsansfont{TeX Gyre Heros}
\setmonofont{Consolas}[Scale=.82]
\definecolor{Ink}{HTML}{203746}\definecolor{Teal}{HTML}{197B77}
\ctexset{section={format=\Large\bfseries\color{Ink}},subsection={format=\large\bfseries\color{Teal}}}
\setlength{\parskip}{.35em}\setlength{\emergencystretch}{2em}
\setlist{nosep,leftmargin=1.5em}
\captionsetup{font=small,labelfont=bf}
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small Mechanics Agent Benchmark / v0.2}
\fancyhead[R]{\small AlexanderChan}\fancyfoot[C]{\thepage}
\newcommand{\code}[1]{\texttt{\detokenize{#1}}}
\newcommand{\fig}[2]{\begin{figure}[htbp]\centering\includegraphics[width=\linewidth]{#1.pdf}\caption{#2}\end{figure}}
\begin{document}
'''
    sections={
        'S01':('轴向有限元采用分段弹性杆。独立参考通过柔度串联得到端位移，再核验根部反力与应变能。单位从GPa转为MPa后参与计算，避免仅靠结果量级判断正确性。',
            'The axial FEM uses piecewise elastic bars. An independent series-compliance reference checks tip displacement, root reaction and strain energy. GPa is converted to MPa before assembly.'),
        'S02':('面积随坐标变化，线性单元使用中点面积，目标响应为端位移。模型需要在给定离散层级中选择满足误差要求的最少单元，而不是单纯选最细网格。评分将数值柔度与连续体积分比较。',
            'The area varies with position; linear elements use midpoint area. The agent must select the coarsest admissible mesh meeting the tip-displacement error bound, not simply over-refine. Scoring compares discrete compliance with the continuum integral.'),
        'S03':('六块小板分别控制相邻两对接触，预抬在名义值上独立变化。采用单边法向弹簧，分离时法向力为零；优化目标为幅值平方和最小。该题验证预抬分配及接触开启判据，不等价于三维摩擦接触。',
            'Six independently controlled plates affect adjacent contact pairs. A unilateral normal-spring law sets force to zero on separation; the objective minimizes squared amplitudes. This tests prelift allocation and contact activation, not 3D frictional contact.'),
        'S04':('这是本版本唯一真实商业求解器题。公开杆件含线弹性半段和J2弹塑性半段，模型在2、4、6、8mm候选截面间选择分区，并保留根部及接口平移自由度。子结构通过真实Abaqus/MCP生成，随后装配求解并读取ODB。非线性本构区不能为了减少自由度而凝聚为线性区域。',
            'This is the only commercial-solver task in this release. The public solid has linear-elastic and J2-plastic halves. The agent selects a cut at 2,4,6 or 8mm and retains root/interface translations. Actual Abaqus/MCP generation, reduced assembly and ODB extraction follow. Potentially plastic regions cannot be frozen linear merely to eliminate more DOFs.'),
        'S05':('72维变量包括42个Z向shape、6个独立预抬及12根公端子的X/Y平移。四种方法均先在单位超立方体采样，再通过截断正态逆分布变换映射到[-1,1]。这是条件分布，不是把超界值裁剪到端点。平移仅改变位置，不改变端子尺寸；子结构本身不平移。',
            'The 72 variables comprise 42 Z shapes, six independent prelifts and X/Y translations of 12 CORE terminals. Four samplers operate in the unit cube, followed by an inverse truncated-normal CDF on [-1,1]. This is conditioning, not clipping. Translation preserves terminal dimensions and leaves SUB unchanged.'),
        'S06':('复用先核对拓扑、材料及保留节点坐标。只有身份兼容的库才进入装配；局部CORE偏移通过不调整节点位置的Tie覆盖判定。Tie容差只解决几何搜索范围，不能掩盖错误的材料、网格或保留自由度。当前覆盖检查是平面解析几何，不是实际Tie求解。',
            'Reuse first checks topology, material and retained-node coordinates. Only compatible libraries can be assembled. Local CORE offsets are assessed by unadjusted Tie coverage. Position tolerance cannot repair an incompatible material, mesh or retained topology. Coverage here is analytical planar geometry, not a native Tie solve.'),
        'S07':('沿指定的偏位偏角耦合路径搜索首次失效，而不是在二维空间中随意寻找一个低接触力点。每次试验返回12对法向力，最终需要安全端与失效端的两个实测产物，且区间宽度不超过0.002。该题是刚体杠杆加接触弹簧模型，边界数值不用于预测工业连接器。',
            'Search targets the first loss along a prescribed coupled offset/angle path, not an arbitrary weak point in 2D. Each experiment returns 12 normal forces. The final safe/failing endpoints require two measured artifacts and a bracket width at most0.002. Rigid-lever spring results are not industrial connector predictions.'),
        'S08':('每个case先验证求解完成、目标位移到达和12对通道完整，再取绝对法向力的最小值排序。数值中止不是接触失效。恢复操作区分重新求解、仅重提取、等待活动任务和修复负体积网格，避免重复提交尚在运行的任务。',
            'Each case must have solver completion, the target displacement and all12 channels before ranking by minimum absolute normal force. A numerical abort is not contact failure. Recovery distinguishes re-solving, re-extraction, waiting for active jobs and repairing negative-volume mesh faults.')}
    for lang in ('zh','en'):
        zh=lang=='zh';ix=0 if zh else 1
        b=[preamble,r'\thispagestyle{empty}',r'{\sffamily\color{Teal}PUBLIC ENGINEERING EVALUATION / 2026.11.04}\par\vspace{1em}',
            r'{\Huge\bfseries\color{Ink}'+(r'力学工程 Agent\\八题可执行基准' if zh else r'Mechanics Agent\\Executable Benchmark')+r'}\par\vspace{1em}',
            r'{\large '+('真实子结构决策、受控工具与可审计证据' if zh else 'Actual substructure decisions, bounded tools and auditable evidence')+r'}\par\vspace{1em}',
            r'AlexanderChan / v0.2.2\par',
            r'\section*{'+('交付范围' if zh else 'Release scope')+'}',
            ('八道题均有可执行工具与独立判分器。其中一道调用真实Abaqus，其余七道为明确标注的简化力学或工程证据算例。本次是单次开发试跑，不是模型排行榜，也不是八道商业软件任务全部完成。'
             if zh else 'All eight exercises have executable tools and independent validators. One uses actual Abaqus; seven are explicitly reduced-physics or engineering-evidence fixtures. This is a single-attempt development pilot, not a leaderboard or eight completed vendor-software tasks.'),
            r'\tableofcontents\newpage',r'\section{'+('评测动机与工程范围' if zh else 'Motivation and engineering scope')+'}',
            ('基准围绕连接器仿真工作流中的自主决策组织：明确载荷和量纲、选择网格精度、配置独立预抬、决定线性子结构区域、生成有界制造公差、验证库复用、搜索偏位偏角边界，以及从失败任务中恢复。重点不在于解释看起来合理，而在于能否交付可检查的产物。'
             if zh else 'The benchmark follows autonomous decisions in connector simulation: loading and units, mesh accuracy, independent prelift, linear substructure selection, bounded manufacturing variables, library reuse, coupled pose boundaries and failure recovery. Plausible prose is insufficient; inspectable artifacts are required.'),
            ('CORE指保留显式有限元描述的区域，SUB指生成子结构的区域；case指一组输入及其输出，不代表特定客户或型号。FEM为Finite Element Method（有限元法），DOF为Degree of Freedom（自由度），MCP为Model Context Protocol（模型上下文协议）；Pi是agent执行框架而非模型。'
             if zh else 'CORE denotes explicitly modeled finite elements; SUB denotes the generated substructure region. A case is one input/output instance, not a customer/model identity. FEM means Finite Element Method; DOF means Degree of Freedom; MCP means Model Context Protocol. Pi is an agent harness, not a model.'),
            r'\fig{workflow}{'+('模型、框架、工具、证据与判分分层。只有S04运行商业求解器。' if zh else 'Separate model, harness, tools, evidence and scoring. Only S04 executes a vendor solver.')+'}',
            r'\section{'+('八道题的物理与判分' if zh else 'Physics and checks in eight tasks')+'}']
        equations={
            'S01':r'u=F\sum_i\frac{L_i}{E_i A_i},\qquad R=-F,\qquad W=\frac12 Fu',
            'S02':r'u_{\mathrm{exact}}=\frac{F}{E}\int_0^1\frac{dx}{1+x}=\frac{F}{E}\ln2',
            'S03':r'N_j=k_j\max\{0,d+h_0+0.15a_{\lceil j/2\rceil}-g_j\}',
            'S04':r'K_c=K_{bb}-K_{bi}K_{ii}^{-1}K_{ib},\qquad n_{\mathrm{elim}}=27(c-1)',
            'S05':r'a=\Phi^{-1}\!\left[\Phi(-1)+u\{\Phi(1)-\Phi(-1)\}\right],\quad u\in(0,1)',
            'S06':r't_{\min}=|n_x|\Delta x_{\max}+|n_y|\Delta y_{\max}+10^{-6}\ \mathrm{mm}',
            'S07':r'\begin{aligned}g(\lambda)&=\min_j N_j(\lambda)-0.4,\\N_j(\lambda)&=k_j\max\{0,\delta_j-0.1n_{x,j}\lambda-\ell_j\sin(2\lambda\pi/180)\}\end{aligned}',
            'S08':r'N_{\min,c}=\min_{j=1,\ldots,12}|N_{c,j}(U_{3,\mathrm{final}})|'}
        for key,c in reg['tasks'].items():
            b += [r'\subsection{'+key+' '+tex(c['title_zh' if zh else 'title'])+'}',sections[key][ix],r'\['+equations[key]+r'\]']
        b += [r'\fig{sampling}{'+('四种抽样方法的单个代表变量，16个样本；目标曲线为[-1,1]截断正态。仅展示抽样规则，不能据此比较统计效率。' if zh else 'One representative variable,16 samples per sampler, against the truncated-normal density. Illustrates rules, not statistical efficiency.')+'}',
            r'\section{'+('真实三维求解与独立校准' if zh else 'Actual 3D execution and independent calibration')+'}',
            ('原创建模尺寸为12×2×2mm，117节点、48个C3D8单元。完整三维模型先独立求解；agent不能直接读取参考结果。分区题只向模型提供材料、网格规则和候选截面，实际工具完成子结构生成、降阶装配、求解及ODB场提取。'
             if zh else 'The original public solid is12 by2 by2mm with117nodes and48C3D8elements. An independent full model is solved first; agents cannot read its result directly. The task exposes material/mesh rules and candidate cuts; the controlled tool performs generation, reduced assembly, solve and ODB extraction.'),
            ('校验覆盖弹性段解析解、端点位移、力平衡、塑性激活以及完整反力曲线等价性。校准反力为7.40683N，完整与降阶的存储帧反力一致，最优安全分区消去135个内部平移自由度。三维塑性状态不以一维塑性近似作为精确参考；该近似早期偏差已保留于诊断记录。微型算例不用于宣称工业加速比。'
             if zh else 'Checks cover elastic analytical response, endpoint displacement, force balance, plastic activation and full reaction-curve equivalence. Calibration endpoint reaction is7.40683N; stored full/reduced frames agree. The maximal safe partition removes135 interior translations. A1D plastic approximation is not treated as an exact3D reference; its earlier discrepancy is retained. This tiny model establishes no industrial speedup.'),
            r'\fig{solid}{'+('真实Abaqus完整与降阶反力曲线；侧图为公开网格及材料分区，不是工业模型。' if zh else 'Actual Abaqus full/reduced reaction curves and public mesh/material partition, not an industrial model.')+'}',
            r'\section{'+('冻结试跑结果' if zh else 'Frozen pilot outcomes')+'}',
            ('源代码、题目和评分规则先冻结再调用API。首轮八次及另外冻结的两次题面复核全部保留；S06布尔类型、S08排序方向以及复核中的恢复策略约定存在题面不足，共三次原始分数不用于能力评估。没有重试预算失败。合计10次记录，通过'+str(s['passed'])+'次，服务或环境错误'+str(s['environment_errors'])+'次，协议歧义排除3次，有效尝试'+str(s['valid_attempts'])+'次。'
             if zh else f"Sources, tasks and rules were frozen before inference. All eight initial and two separately frozen protocol checks remain. S06 boolean typing,S08 ranking direction,and the amended recovery-policy contract were underspecified; three raw scores are excluded from capability evaluation. Budget failures were not retried. The10 records contain {s['passed']} passes,{s['environment_errors']} environment errors,three protocol exclusions and {s['valid_attempts']} valid attempts."),
            r'\noindent\begin{tabularx}{\linewidth}{lllrX}\toprule Task & Configuration & Tier & s & Outcome\\\midrule']
        for r in s['rows']:
            label={'passed':'Passed','failed_or_budget':'Failed / budget','environment_error':'Environment error',
                'excluded_task_ambiguity':'Task ambiguity (excluded)','excluded_policy_ambiguity':'Policy ambiguity (excluded)',
                'adapter_invalid':'Adapter invalid'}[r['classification']]
            b += [f"{r['task']}{'*' if r['phase']=='amended' else ''} & {tex(r['configuration'])} & {'CAE' if r['task']=='S04' else 'Reduced'} & {r['elapsed_seconds']:.1f} & {label} "+r'\\']
        b += [r'\bottomrule\end{tabularx}',r'\fig{outcomes}{'+('按任务展示的单次耗时和状态；任务、模型、框架同时变化，不能据此排名。' if zh else 'Per-task single-attempt elapsed times and outcomes; task, model and harness change together, so no ranking follows.')+'}',
            ('Kimi请求标识为kimi-k2.6，使用受控mini框架；DeepSeek请求标识为deepseek-v4-flash，使用Pi SDK0.73.1。CCS只读解析凭据，不改变当前线路。服务端实际模型别名不总是可观测，因此保留请求标识与响应标识，不从模型自述推断身份。'
             if zh else 'Kimi request ID is kimi-k2.6 through the controlled mini harness; DeepSeek request ID is deepseek-v4-flash through Pi SDK0.73.1. CCS credentials are read without switching active routes. Alias resolution is not always observable, so requested/reported identities are recorded without inferring identity from self-description.'),
            ('每题最多6次模型调用，每次6144输出token，24次工具调用，三维题最多一次候选求解。Pi推理设置为off；不同服务端的内部推理行为不能假定一致。token按API报告分项统计；SDK零成本字段不是免费，实际账单未知。Kimi遇到组织RPM限制的原始响应保留，公开版本仅隐去账号标识。'
             if zh else 'Budgets are6 model calls,6144 output tokens per call,24 tools and one native candidate. Pi thinking is set off; provider internal behavior is not assumed equivalent. Usage is provider-reported; SDK zero-cost fields are not invoices. Actual billed cost is unknown. Kimi organization-RPM errors are retained, with account identifiers redacted publicly.'),
            ('表中星号标记题面复核。S06复核通过；S08复核正确识别并排序了低接触力case，但建议重新求解已完成的物理失效case，与判分器的最小恢复策略不一致。该策略此前没有完整写入题面，因此其原始零分也排除，不解释成模型力学错误。交付题库v0.2.2已补全约定，未继续调用API验证这一修订。原始判分器和新旧记录均保留。'
             if zh else 'An asterisk marks a protocol check. S06 passed. S08 correctly ranked/contact-classified the cases but proposed re-solving completed physical failures, contrary to the minimal-recovery scorer. That policy was not fully stated, so this raw zero is also excluded rather than called a mechanics error. Delivered v0.2.2 makes the policy explicit; no further inference tested this last clarification. Original evaluator and all records remain.'),
            ('首次冻结记录了Python源码哈希；后续题面修改后，通过原哈希逐文件精确匹配恢复旧源码快照，恢复过程与校验回执公开。Pi桥接脚本及依赖文件初次未预先哈希，仅有执行后的版本证据，这一限制保留说明；新冻结命令已同时快照并哈希这些文件。'
             if zh else 'The first registries pinned Python sources. After the text amendment, changed old sources were recovered byte-for-byte against those original hashes; recovery/verification receipts are public. The Pi bridge and requirements were not initially prehashed, only evidenced after execution. This limitation remains explicit; new freeze commands hash and snapshot them too.'),
            r'\section{'+('复现与扩展操作' if zh else 'Reproduction and extension')+'}',
            ('解压源码包后，在项目根目录安装requirements.txt中的依赖。离线测试不需要API或商业软件。标准库SQLite只读访问本机CCS，不要上传数据库或把密钥写入配置文件。Pi运行时需单独安装，商业软件和MCP部署不随包提供。'
             if zh else 'Extract the source bundle and install requirements.txt dependencies. Offline tests need no API or commercial software. SQLite reads local CCS only; never upload its database or write keys into configs. Install the Pi runtime separately. Commercial software and MCP deployment are not bundled.'),
            r'\begin{quote}\small\code{python -m unittest discover -s mechanics_benchmark/tests -q}\\'+
            r'\code{python -m mechanics_benchmark.run_suite freeze --output NEW_OUTPUT}\\'+
            r'\code{python -m mechanics_benchmark.run_suite run --output NEW_OUTPUT}\\'+
            r'\code{--task S04 --configuration deepseek-pi --reference REFERENCE_DIR}\end{quote}',
            ('冻结命令记录环境版本与源码哈希；修改评分代码或输入后应使用新目录，不覆盖旧成绩。真实三维任务还需要MCP环境Python、独立参考目录及可写求解目录；默认路径集中在run_suite.py和suite_tools.py，可在部署时修改后重新冻结。每个任务目录包含run.json、query.json、trace.jsonl、submission.json（若提交）、artifacts和evaluation.json。'
             if zh else 'Freeze records dependency versions and source hashes. Changed rules/inputs require a new directory, not overwritten scores. The3D task additionally needs MCP Python, an independent reference and writable solver workspace. Defaults are centralized in run_suite.py and suite_tools.py; adjust before freezing on a new deployment. Each attempt contains run.json,query.json,trace.jsonl,submission.json if submitted,artifacts and evaluation.json.'),
            ('新增模型时添加只读路由解析与明确模型标识；新增框架时实现相同能力工具接口、逐轮事件和预算控制，先验证无shell、任意文件与网络工具泄漏，再进行实际推理。当前验证过的只有mini与Pi，不能宣称所有本机agent已兼容。'
             if zh else 'A new model needs an explicit route/model identity. A new harness must implement the same capabilities, observable events and budgets, with pre-inference checks excluding shell/arbitrary-file/network access. Only mini and Pi are validated; other installed agents are not claimed compatible.'),
            r'\section{'+('证据、安全与解释边界' if zh else 'Evidence, safety and interpretation limits')+'}',
            ('中英文附录逐条保留可观测query、request、output、工具参数、工具返回及原生MCP调用的父调用编号。原始JSONL是审计依据，不补写未公开的系统提示或内部思维。SHA256清单覆盖发布文件。公开包排除私有工程几何、合同、完整工业样本、凭据、商业软件及ODB/SIM大文件，仅包含原创公开算例与必要求解回执。'
             if zh else 'Bilingual appendices retain observable queries,requests,outputs,tool arguments/results and parent IDs for native MCP calls. JSONL is authoritative; unexposed prompts/internal reasoning are not invented. SHA256 manifests cover release files. The public bundle excludes private geometry,contracts,industrial samples,credentials,commercial software and large ODB/SIM files; original public decks and solver receipts remain.'),
            ('这是具备八题执行闭环的开发基准，不是已完成的全面工业验证。真实HyperMesh自适应网格、三维摩擦接触、公差形变质量及所有原生agent客户端隔离仍属于扩展阶段。后续正式比较需使用相同任务的交叉模型/框架矩阵、多次重复、预先冻结的统计分析和费用上限。'
             if zh else 'This release closes execution for eight public exercises, not comprehensive industrial validation. Native HyperMesh adaptation,3D frictional contact,morph quality and unrestricted-agent OS isolation remain extensions. Formal comparison needs crossed model/harness configurations on the same tasks,repeats,preregistered statistics and spending limits.'),
            r'\section*{'+('参考资料' if zh else 'References')+'}',
            r'\begin{enumerate}\item Abaqus 2025, \href{https://docs.software.vt.edu/abaqusv2025/English/SIMACAEKEYRefMap/simakey-r-retainednodaldofs.htm}{Retained nodal DOFs}.',
            r'\item Abaqus 2025, \href{https://docs.software.vt.edu/abaqusv2025/English/SIMACAETHERefMap/simathe-c-superelements.htm}{Substructuring theory}.',
            r'\item SciPy, \href{https://docs.scipy.org/doc/scipy/reference/stats.qmc.html}{Quasi-Monte Carlo documentation}; installed version recorded in preregistration.\end{enumerate}',r'\end{document}']
        for i,line in enumerate(b):
            if 'Defaults are centralized' in line or '默认路径集中' in line:
                b[i]=line.replace('run_suite.py',r'\code{run_suite.py}').replace('suite_tools.py',r'\code{suite_tools.py}')
        if not zh:
            b[0]+=r'\renewcommand{\figurename}{Figure}\renewcommand{\tablename}{Table}\renewcommand{\contentsname}{Contents}'
            for i,line in enumerate(b):
                if not line.startswith('\\'):
                    line=re.sub(r'\b(the|The|all|All|of|are|by|with|comprise|SDK|A)(?=\d)',r'\1 ',line)
                    line=re.sub(r'(?<=\d)(?=(?:nodes|elements|frames|mm|MPa|DOFs|N)\b)',' ',line)
                    b[i]=re.sub(r',(?=\w)',', ',line)
        (folder/('benchmark_v02_'+lang+'.tex')).write_text('\n\n'.join(b),encoding='utf-8')


def bundle():
    s=read(OUT/'summary.json');entries={}
    for path in (ROOT/'mechanics_benchmark').rglob('*'):
        if path.is_file() and path.suffix in ('.py','.mjs','.md','.txt') and '__pycache__' not in path.parts:
            entries['mechanics_benchmark/'+path.relative_to(ROOT/'mechanics_benchmark').as_posix()]=path
    for dirname,suffixes in [('pilot',{'.json','.jsonl'}),('amendment',{'.json','.jsonl','.py','.mjs','.txt'}),
        ('frozen_source',{'.json','.py','.mjs','.txt'}),('documentation',{'.md'}),('publication',{'.tex','.pdf'}),
        ('figures',{'.py','.json','.pdf','.png'}),('qa',{'.json'})]:
        for path in (OUT/dirname).rglob('*'):
            if path.is_file() and path.suffix in suffixes and path.name!='release_audit.json':
                entries[path.relative_to(OUT).as_posix()]=path
    for name in ('preregistration.json','summary.json','summary.csv','README_ZH.md','README_EN.md','PROTOCOL_REVIEW.md'):
        entries[name]=OUT/name
    # Original synthetic solver data only. No recursive copy of global MCP runs.
    native=Path('D:/kimi/benchmark_public/v02_agent/deepseek-pi-S04-a1')
    reference=Path('D:/kimi/benchmark_public/solid_20261104_03')
    for tag,folder in [('native_candidate',native),('host_reference',reference)]:
        for name in ('full.inp','generation.inp','reduced.inp','curves.json','progress.json','validation.json','mcp_trace.jsonl','candidate_result.json','validation_history.jsonl'):
            path=folder/name
            if path.is_file():entries[tag+'/'+name]=path
    secrets=[r.secret.encode() for r in inventory() if len(r.secret)>=8]
    manifest={};archive=OUT/'mechanics-benchmark-v0.2-source-evidence.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for name,path in sorted(entries.items()):
            data=path.read_bytes()
            if path.suffix not in ('.pdf','.png'):data=public_text(data.decode('utf-8-sig')).encode('utf-8')
            if any(secret in data for secret in secrets):raise ValueError('Credential scan failed; publication blocked')
            manifest[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
        z.writestr('release_manifest.json',json.dumps(manifest,indent=2))
    audit=dict(passed=True,files=len(entries),zip_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
        credentials_scanned='actual CCS credential values, never included',private_engineering_files=False,
        account_redaction='API org identifiers redacted in public text copies; local original traces remain unchanged')
    (OUT/'qa/release_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))
    return archive


def stage_website():
    import html
    s=read(OUT/'summary.json');reg=read(OUT/'preregistration.json')
    source=WEBSITE/'site-src';assets=source/'static/articles/mechanics-benchmark-v02'
    assets.mkdir(parents=True,exist_ok=True)
    for name in ('benchmark_v02_zh.pdf','benchmark_v02_en.pdf','benchmark_v02_zh.tex','benchmark_v02_en.tex',
        'workflow.pdf','workflow.png','solid.pdf','solid.png','sampling.pdf','sampling.png','outcomes.pdf','outcomes.png'):
        shutil.copy2(OUT/'publication'/name,assets/name)
    for name in ('summary.json','summary.csv','preregistration.json','mechanics-benchmark-v0.2-source-evidence.zip','PROTOCOL_REVIEW.md'):
        shutil.copy2(OUT/name,assets/name)
    shutil.copy2(OUT/'amendment/preregistration.json',assets/'preregistration_amended.json')
    for lang in ('zh','en'):
        zh=lang=='zh'
        title='力学工程Agent基准：八题执行闭环与真实三维子结构决策' if zh else 'Mechanics Agent Benchmark: Eight Exercises and Actual 3D Partition Decisions'
        description='八道可执行公开题、真实Abaqus/MCP子结构、独立判分、中英文LaTeX正文与完整输入输出。' if zh else 'Eight executable public exercises, actual Abaqus/MCP substructures, independent checks, bilingual LaTeX reports and complete traces.'
        b=['---','title: '+json.dumps(title,ensure_ascii=False),'date: 2026-11-04','slug: "mechanics-benchmark-v02"',
            'author: "AlexanderChan"','description: '+json.dumps(description,ensure_ascii=False),
            'categories: ["Engineering"]','tags: ["Mechanics", "Agent", "Benchmark", "MCP", "LaTeX"]',
            'connector_article: true','---','<article class="cae-article">',
            '<p class="article-downloads">'+f'<a href="{ASSET}benchmark_v02_zh.pdf">中文 PDF</a> · '+
            f'<a href="{ASSET}benchmark_v02_en.pdf">English PDF</a> · '+
            f'<a href="{ASSET}mechanics-benchmark-v0.2-source-evidence.zip">'+('源码、题库与完整证据' if zh else 'Source, tasks and complete evidence')+'</a></p>',
            '<blockquote><p><strong>'+('八题可执行，不等于八道商业求解器任务。' if zh else 'Eight executable exercises, not eight vendor-solver tasks.')+'</strong> '+
            ('S04运行真实Abaqus/MCP，其余七题为明确标注的简化力学或工程证据题。本次为单次开发试跑，不是模型或框架排行榜。' if zh else 'S04 executes actual Abaqus/MCP; seven tasks use explicitly reduced physics or engineering evidence. This single-attempt development pilot is not a model or harness ranking.')+'</p></blockquote>',
            '<h2>'+('从建模经验到自主决策题' if zh else 'From modeling practice to autonomous decisions')+'</h2>',
            '<p>'+('基准覆盖量纲和平衡、网格分配、独立预抬、子结构区域选择、有界公差、库复用、偏位偏角边界，以及故障恢复。每道题都要求受控工具执行与真实产物；文字解释本身不能获得通过。模型看不到参考答案、任意文件、shell或网络工具。' if zh else 'Tasks cover units/equilibrium, mesh allocation, independent prelift, substructure regions, bounded tolerances, library reuse, coupled pose boundaries and recovery. Every exercise requires controlled execution and artifacts; prose alone cannot pass. Agents have no reference-answer, arbitrary-file, shell or network access.')+'</p>']
        def fig(stem,caption):return f'<figure><a href="{ASSET}{stem}.pdf"><img src="{ASSET}{stem}.png" alt="{html.escape(caption)}" loading="lazy" style="width:100%;height:auto"></a><figcaption>{html.escape(caption)}</figcaption></figure>'
        b += [fig('workflow','模型、框架、受控工具、证据与独立判分分层。' if zh else 'Separate model, harness, controlled tools, evidence and independent checks.'),
            '<h2>'+('八道题与执行层级' if zh else 'Eight exercises and execution tiers')+'</h2>',
            '<div class="table-scroll"><table><thead><tr><th>ID</th><th>'+('任务' if zh else 'Task')+'</th><th>'+('执行层级' if zh else 'Tier')+'</th></tr></thead><tbody>']
        for key,c in reg['tasks'].items():
            b += ['<tr><td>'+key+'</td><td>'+html.escape(c['title_zh' if zh else 'title'])+'</td><td>'+('实际Abaqus/MCP' if zh else 'Actual Abaqus/MCP' )+'</td></tr>' if key=='S04' else
                '<tr><td>'+key+'</td><td>'+html.escape(c['title_zh' if zh else 'title'])+'</td><td>'+('简化力学/证据' if zh else 'Reduced physics/evidence')+'</td></tr>']
        b += ['</tbody></table></div>','<h2>'+('模型自主决定三维子结构区域' if zh else 'An agent selects a 3D substructure region')+'</h2>',
            '<p>'+('DeepSeek/Pi选择6mm截面，保留根部和接口共18个节点的三向平移，消去135个内部平移自由度。真实工具随后生成SIM库、装配并求解三维降阶模型，提取21个ODB帧；完整与降阶反力曲线在存储精度下一致，终点反力为7.40683N。实际求解回执与独立核验包含在下载包中。该结果证明这个公开算例的执行与等价性，不证明工业加速比。' if zh else 'DeepSeek/Pi selected the6mm cut, retaining three translations at18 root/interface nodes and eliminating135 interior translations. Actual tools generated a SIM library, assembled/solved the reduced3D model and extracted21ODB frames. Full/reduced reactions agree at stored precision, with endpoint7.40683N. Solver receipts and independent checks are bundled. This validates the public fixture, not an industrial speedup.')+'</p>',
            fig('solid','公开三维网格材料分区，以及真实Abaqus完整/降阶曲线。' if zh else 'Public3D mesh/material partition and actual full/reduced Abaqus curves.'),
            '<h2>'+('公差抽样与物理映射' if zh else 'Tolerance sampling and physical mapping')+'</h2>',
            '<p>'+('72维变量由42个Z向shape、6个小板独立预抬和24个公端子X/Y局部平移组成。四种抽样均使用[-1,1]截断标准正态逆分布映射，而不是裁剪。尺寸比例分别为0.15mm、名义0.3348mm加0.15mm幅值、以及0.1mm。下图仅用16个样本解释规则，不用直方图证明方法优劣。' if zh else 'The72 variables comprise42Z shapes,6 independent prelifts and24 CORE-terminal X/Y offsets. Four samplers use an inverse standard-normal distribution conditioned on[-1,1], not clipping. Physical scales are0.15mm,nominal0.3348mm plus0.15mm amplitude,and0.1mm. The16-sample illustration explains rules, not comparative efficiency.')+'</p>',
            fig('sampling','作者根据冻结输入生成的抽样示意，不计为agent成绩。' if zh else 'Author-generated illustration from frozen inputs; not an agent score.'),
            '<h2>'+('试跑结果与失败证据' if zh else 'Pilot outcomes and failure evidence')+'</h2>',
            '<p>'+(f"{s['attempts']}次尝试中{s['passed']}次通过，{s['environment_errors']}次服务或环境错误，{s['valid_attempts']}次有效尝试。" if zh else f"{s['attempts']} attempts yielded {s['passed']} passes, {s['environment_errors']} environment errors and {s['valid_attempts']} valid attempts.")+
                ('共三次原始分数因输出类型、排序方向或恢复策略没有充分说明而排除，详情见审查记录。S08复核的恢复建议不符合最小恢复策略，但该策略未完整写入原题，不能归咎模型。交付v0.2.2已澄清，未追加推理。预算失败不重试；不同任务、模型和框架的成绩不能用于排名。' if zh else 'Three raw scores are excluded for underspecified typing,ranking or recovery policy. S08 recovery proposals conflicted with a minimal-recovery policy not fully stated in the prompt; this cannot be blamed on the model. Delivered v0.2.2 clarifies it without further inference. Budget failures were not retried; different tasks,models and harnesses prevent ranking.')+'</p>',
            fig('outcomes','单次任务耗时与状态，包括未通过和服务限流，不隐去失败。' if zh else 'Single-attempt elapsed times and states, retaining budget failures and service limits.'),
            '<div class="table-scroll"><table><thead><tr><th>Task</th><th>Configuration</th><th>Outcome</th><th>s</th></tr></thead><tbody>']
        for r in s['rows']:
            b += [f"<tr><td>{r['task']} / {r['phase']}</td><td>{r['configuration']}</td><td>{r['classification']}</td><td>{r['elapsed_seconds']:.1f}</td></tr>"]
        b += ['</tbody></table></div>','<h2>'+('复现、费用与扩展' if zh else 'Reproduction, cost and extension')+'</h2>',
            '<p>'+('下载包提供中英文逐轮query/output附录、原始脱敏JSONL、独立评分、哈希、原创建模输入及Tavotto脚本/回执。所有正文使用LaTeX编译为PDF。API由本机CCS只读接入，无购买额度；真实账单未知，Pi的零成本字段不能解释为免费。现有APP、工业模型和旧批次未改动。' if zh else 'The bundle provides bilingual query/output appendices,redacted JSONL,independent checks,hashes,original public decks and Tavotto sources/receipts. Main reports are LaTeX PDFs. CCS routes are read-only,no credits were purchased,and billing is unknown; Pi zero-cost fields do not imply free usage. Production APP,industrial models and old batches were not changed.')+'</p>',
            '<p>'+('当前验证mini和Pi两种框架，新增客户端必须实现相同工具与日志协议后才能标记为兼容。正式跨模型研究还需要相同任务的交叉配置、多次重复和预注册费用上限。三维摩擦接触、真实HyperMesh自适应与不受控原生agent隔离属于后续扩展。' if zh else 'Only mini and Pi are validated. A new client must implement the same tools/logging before claiming compatibility. Formal comparisons need crossed configurations on identical tasks,repeats and preregistered spending. Native3D frictional contact,HyperMesh adaptation and unrestricted-agent isolation remain extensions.')+'</p>',
            f'<p><a href="{ASSET}summary.csv">CSV</a> · <a href="{ASSET}summary.json">JSON</a> · <a href="{ASSET}preregistration.json">'+('冻结规则' if zh else 'Frozen registry')+'</a></p>','</article>']
        post=source/'content/post'/('mechanics-benchmark-v02'+('.en' if not zh else '')+'.md')
        if not zh:
            b=[re.sub(r'(?<=\d)(?=(?:nodes|elements|frames|mm|MPa|DOFs|N)\b)',' ',
                re.sub(r'\b(the|The|all|All|of|are|by|with|comprise|SDK|A)(?=\d)',r'\1 ',line)) for line in b]
        post.write_text('\n'.join(b),encoding='utf-8')
    served=WEBSITE/'articles/mechanics-benchmark-v02';served.mkdir(parents=True,exist_ok=True)
    for path in assets.iterdir():shutil.copy2(path,served/path.name)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['summary','figure-data','tavotto','documents','bundle','website'])
    p.add_argument('--port',type=int,default=26904);a=p.parse_args()
    if a.command=='summary':print(json.dumps(summarize(),indent=2))
    elif a.command=='figure-data':figure_data()
    elif a.command=='tavotto':tavotto(a.port)
    elif a.command=='documents':documents()
    elif a.command=='bundle':bundle()
    else:stage_website()
