"""Public finite-capability mechanics experiments; not a vendor CAE surrogate claim."""
import math
import numpy as np
from scipy.special import ndtr,ndtri
from scipy.stats import qmc


def axial(f):
    stiffness=np.zeros((4,4));force=np.zeros(4);force[-1]=f['tip_force_N']
    for i,(l,a,e) in enumerate(zip(f['length_mm'],f['area_mm2'],f['E_GPa'])):
        stiffness[i:i+2,i:i+2]+=e*1000*a/l*np.array([[1,-1],[-1,1]])
    u=np.zeros(4);u[1:]=np.linalg.solve(stiffness[1:,1:],force[1:])
    return dict(engine='NumPy direct stiffness, 1D axial FEM',U_mm=float(u[-1]),
        reaction_N=float((stiffness@u-force)[0]),energy_Nmm=float(u@stiffness@u/2))


def mesh(f,n):
    if type(n) is not int or n not in f['allowed_n']:raise ValueError('Unsupported mesh')
    dx=f['L_mm']/n
    u=f['F_N']/f['E_MPa']*sum(dx/(1+(i+.5)*dx) for i in range(n))
    return dict(engine='1D axial linear elements, midpoint area',n=n,U_mm=u)


def contact(f,amplitudes):
    a=np.asarray(amplitudes,dtype=float)
    if a.shape!=(6,) or not np.isfinite(a).all() or np.any((a<0)|(a>1)):
        raise ValueError('Six finite amplitudes in [0,1] required')
    lift=f['base_lift_mm']+f['scale_mm']*np.repeat(a,2)
    overlap=f['insertion_mm']+lift-np.array(f['gaps_mm'])
    forces=np.maximum(overlap,0)*f['stiffness_N_per_mm']
    return dict(engine='12 unilateral normal springs; no friction',amplitudes=a.tolist(),
        forces_N=forces.tolist(),objective=float(a@a),lifts_mm=lift[::2].tolist())


def sample(f,method,seed):
    n,d=f['n'],f['dimensions']
    if type(seed) is not int or seed!=f['seed']:raise ValueError('Use the frozen seed')
    if method=='MC':u=np.random.default_rng(seed).random((n,d))
    elif method=='LHS':u=qmc.LatinHypercube(d,seed=seed).random(n)
    elif method=='Sobol':u=qmc.Sobol(d,scramble=True,seed=seed).random_base2(int(math.log2(n)))
    elif method=='Halton':u=qmc.Halton(d,scramble=True,seed=seed).random(n)
    else:raise ValueError('Unknown method')
    a=ndtri(ndtr(-1)+u*(ndtr(1)-ndtr(-1)))
    physical=a[0].copy();physical[:42]*=.15
    physical[42:48]=.3348+.15*physical[42:48];physical[48:]*=.1
    return dict(engine='SciPy QMC plus inverse truncated-normal CDF; not clipping',method=method,
        seed=seed,uniform=u.tolist(),amplitudes=a.tolist(),first_physical_mm=physical.tolist())


def interface(f,library_id,tie_tolerance_mm,adjust):
    if library_id not in f['libraries']:raise ValueError('Unknown library')
    tol=float(tie_tolerance_mm)
    if not math.isfinite(tol) or tol<0 or type(adjust) is not bool:raise ValueError('Invalid Tie settings')
    distance=sum(abs(n)*a for n,a in zip(f['master_normal'],f['offset_limits_mm']))
    return dict(engine='metadata identity plus planar geometric coverage, not Abaqus Tie execution',
        library_id=library_id,compatible=f['libraries'][library_id]==f['target'],
        max_distance_mm=distance,tie_tolerance_mm=tol,coverage=tol>=distance,adjust=adjust)


def pose(f,value):
    value=float(value)
    if not math.isfinite(value) or not 0<=value<=2:raise ValueError('lambda outside envelope')
    dx=f['path']['offset_X_mm_per_lambda']*value
    angle=f['path']['angle_deg_per_lambda']*value
    overlap=np.array(f['initial_overlap_mm'])-dx*np.array(f['normal_x'])-math.sin(math.radians(angle))*np.array(f['lever_mm'])
    forces=np.maximum(overlap,0)*np.array(f['k_N_per_mm'])
    return dict(engine='rigid lever kinematics plus unilateral springs; not full connector CAE',
        **{'lambda':value},offset_X_mm=dx,angle_deg=angle,forces_N=forces.tolist(),
        min_force_N=float(forces.min()),failed=bool(forces.min()<f['threshold_N']))
