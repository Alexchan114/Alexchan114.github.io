"""Read CCS routes without changing them or persisting credential values."""
from dataclasses import dataclass, field
from contextlib import closing
import json
from pathlib import Path
import re
import sqlite3
from urllib.parse import urlsplit


DEFAULT_DB = Path.home() / ".cc-switch/cc-switch.db"
SECRET_KEY = re.compile(r"key|token|secret|password|authorization", re.I)


@dataclass
class Route:
    provider_id: str
    name: str
    app: str
    base_url: str
    models: list
    protocol: str
    secret: str = field(repr=False, default="")

    def public(self):
        return dict(provider_id=self.provider_id, name=self.name, app=self.app,
                    host=urlsplit(self.base_url).hostname, models=self.models,
                    protocol=self.protocol, credential_configured=bool(self.secret))


def leaves(value, prefix=""):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from leaves(item, prefix + "." + key)
    elif isinstance(value, str):
        yield prefix, value


def inventory(db=DEFAULT_DB):
    path = Path(db).resolve()
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as connection:
        rows = connection.execute("SELECT id, app_type, name, settings_config FROM providers").fetchall()
    routes = []
    for identity, app, name, text in rows:
        config = json.loads(text)
        items = list(leaves(config))
        urls = [v for k, v in items if v.startswith(("https://", "http://"))
                and re.search(r"base.?url|endpoint|api.?url", k, re.I)]
        secrets = [v for k, v in items if SECRET_KEY.search(k.rsplit(".", 1)[-1]) and v]
        models = list(dict.fromkeys(v for k, v in items
                      if re.search(r"model", k, re.I) and not SECRET_KEY.search(k)))
        # Codex routes may embed TOML instead of structured endpoint fields.
        for k, value in items:
            if k.endswith(".config"):
                import tomllib
                try:
                    embedded = list(leaves(tomllib.loads(value)))
                except tomllib.TOMLDecodeError:
                    continue
                urls += [v for key, v in embedded if key.endswith(".base_url")]
                models += [v for key, v in embedded if key == ".model"]
        protocol = "anthropic" if app == "claude" else "openai"
        routes.append(Route(str(identity), name, app, urls[0] if urls else "",
                            list(dict.fromkeys(models)), protocol, secrets[0] if secrets else ""))
    return routes


def select(provider_id, db=DEFAULT_DB, app="claude"):
    routes = [r for r in inventory(db) if r.provider_id == provider_id and r.app == app]
    if len(routes) != 1:
        raise ValueError("Select one exact CCS provider ID; names alone may be ambiguous")
    route = routes[0]
    if not route.base_url or not route.secret:
        raise ValueError("CCS route has no usable explicit endpoint and credential")
    parsed = urlsplit(route.base_url)
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Credentials or query parameters in endpoint URLs are not supported")
    if parsed.scheme != "https" and parsed.hostname not in ("localhost", "127.0.0.1", "::1"):
        raise ValueError("Remote plaintext credential transport is not allowed")
    return route


if __name__ == "__main__":
    print(json.dumps([r.public() for r in inventory()], ensure_ascii=True, indent=2))
