"""Registration, artifact, archive and PDF-preview verification for the release."""
import hashlib
import json
from pathlib import Path
import zipfile
from PIL import Image,ImageDraw
from .security import digest

ROOT=Path(__file__).resolve().parents[1]/'outputs/mechanics_agent_benchmark_v02_20261104'


def verify():
    checked=0
    for base in (ROOT,ROOT/'amendment'):
        reg=json.loads((base/'preregistration.json').read_text(encoding='utf-8'))
        for name,expected in reg['source_hashes'].items():
            p=base/'frozen_source/mechanics_benchmark'/name
            if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise ValueError('Registered source mismatch')
        for entry in reg['matrix']:
            run=base/'pilot'/(entry['configuration']+'-'+entry['task']+'-a1')
            meta=json.loads((run/'run.json').read_text(encoding='utf-8'))
            if meta['status']=='running' or meta['preregistration_hash']!=digest(reg):raise ValueError('Unresolved/altered registration')
            if digest(json.loads((run/'task.json').read_text(encoding='utf-8')))!=meta['task_hash']:raise ValueError('Task differs')
            for p in (run/'artifacts').glob('*.json'):
                a=json.loads(p.read_text(encoding='utf-8'))
                if p.stem!='artifact_'+digest(a)[:20]:raise ValueError('Artifact identity mismatch')
                checked+=1
    for lang in ('zh','en'):
        log=(ROOT/'publication'/('benchmark_v02_'+lang+'.log')).read_text(encoding='utf-8',errors='replace')
        if any(w in log for w in ('Overfull','Missing character','Undefined control','! LaTeX Error')):raise ValueError('PDF layout/compile warning '+lang)
    archive=ROOT/'mechanics-benchmark-v0.2-source-evidence.zip'
    if archive.exists():
        with zipfile.ZipFile(archive) as z:
            for name,expected in json.loads(z.read('release_manifest.json')).items():
                if hashlib.sha256(z.read(name)).hexdigest()!=expected:raise ValueError('Archive hash mismatch')
            for prefix in ('','amendment/'):
                reg=json.loads(z.read(prefix+'preregistration.json'))
                for name,expected in reg['source_hashes'].items():
                    if hashlib.sha256(z.read(prefix+'frozen_source/mechanics_benchmark/'+name)).hexdigest()!=expected:
                        raise ValueError('Archived frozen source mismatch')
    result=dict(passed=True,registered_attempts=10,artifact_hashes_verified=checked,
        frozen_sources_verified=True,pdf_overflow_or_missing_glyphs=False)
    (ROOT/'qa/verification.json').write_text(json.dumps(result,indent=2));print(result)


def sheets():
    for lang in ('zh','en'):
        pages=sorted((ROOT/'qa').glob('page_'+lang+'-*.png'))
        if not pages:raise ValueError('Render PDF pages first')
        w,h=420,620;canvas=Image.new('RGB',(w*3,h*((len(pages)+2)//3)),'#dbe0e1');draw=ImageDraw.Draw(canvas)
        for i,p in enumerate(pages):
            im=Image.open(p).convert('RGB');im.thumbnail((w-20,h-32));x,y=i%3*w,i//3*h
            canvas.paste(im,(x+(w-im.width)//2,y+24));draw.text((x+10,y+5),p.name,fill='black')
        canvas.save(ROOT/'qa'/('contact_sheet_'+lang+'.png'))


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('command',choices=['verify','sheets']);a=p.parse_args()
    (verify if a.command=='verify' else sheets)()
