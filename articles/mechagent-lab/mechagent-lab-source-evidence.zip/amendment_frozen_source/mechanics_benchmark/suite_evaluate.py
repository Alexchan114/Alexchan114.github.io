"""Host-only numerical and evidence checks, frozen before the v0.2 pilot."""
import math
import numpy as np
from scipy.special import ndtr


def evaluate(card,solution,artifacts):
    checks={}
    f=card['fixture'];key=card['id']

    def near(a,b,tol=1e-7):
        a,b=np.asarray(a,dtype=float),np.asarray(b,dtype=float)
        return a.shape==b.shape and np.isfinite(a).all() and bool(np.max(np.abs(a-b),initial=0)<=tol)

    def artifact(identity,parameters=None):
        a=artifacts[identity]
        if parameters is not None and a['parameters']!=parameters:raise ValueError('Artifact parameters differ')
        return a['result']

    try:
        if key=='S01':
            r=artifact(solution['artifact_id'],{})
            u=f['tip_force_N']*sum(l/(1000*e*a) for l,e,a in zip(f['length_mm'],f['E_GPa'],f['area_mm2']))
            checks.update(displacement=near(solution['U_mm'],u),equilibrium=near(solution['reaction_N'],-f['tip_force_N']),
                energy=near(solution['energy_Nmm'],.5*f['tip_force_N']*u),executed=near(r['U_mm'],u))
        elif key=='S02':
            n=solution['n'];r=artifact(solution['artifact_id'],dict(n=n))
            exact=f['F_N']/f['E_MPa']*math.log(2)
            error=abs(r['U_mm']/exact-1)
            def err(m):return abs(sum(1/m/(1+(i+.5)/m) for i in range(m))/math.log(2)-1)
            best=next(m for m in f['allowed_n'] if err(m)<=f['relative_tolerance'])
            checks.update(minimal_mesh=n==best,accuracy=error<=f['relative_tolerance'],
                reported=near(solution['U_mm'],r['U_mm']) and near(solution['relative_error'],error))
        elif key=='S03':
            a=np.asarray(solution['amplitudes'],dtype=float)
            r=artifact(solution['artifact_id'],dict(amplitudes=solution['amplitudes']))
            lower=[max(0.,max((f['threshold_N']/f['stiffness_N_per_mm'][j]+f['gaps_mm'][j]-
                f['insertion_mm']-f['base_lift_mm'])/f['scale_mm'] for j in (2*i,2*i+1))) for i in range(6)]
            checks.update(optimal_prelift=near(a,lower,1e-6),coverage=min(r['forces_N'])>=.4-1e-7,
                reported=near(solution['forces_N'],r['forces_N']))
        elif key=='S04':
            cut=solution['cut_mm'];r=artifact(solution['artifact_id'],dict(cut_mm=cut))
            retained=list(range(1,10))+list(range(1+9*cut,10+9*cut))
            checks.update(maximal_safe_partition=cut==6,interface=solution['retained_nodes']==retained,
                translations=solution['retained_dofs']==[1,2,3],reduction=solution['eliminated_dofs']==27*(cut-1),
                actual_solver=r.get('engine','').startswith('actual Abaqus') and
                    all(r['checks'].values()) and len(set(r['jobs'].values()))==4,
                curve_error=r['max_curve_difference_N']<1e-4)
        elif key=='S05':
            ids=solution['artifact_ids'];checks['four_methods']=len(ids)==4 and len(set(ids))==4
            first=None
            for identity,method in zip(ids,('MC','LHS','Sobol','Halton')):
                r=artifact(identity,dict(method=method,seed=f['seed']))
                a=np.array(r['amplitudes']);u=np.array(r['uniform'])
                inverse=(ndtr(a)-ndtr(-1))/(ndtr(1)-ndtr(-1))
                checks[method+'_marginal']=a.shape==(16,72) and np.isfinite(a).all() and bool(np.all(abs(a)<=1)) and near(inverse,u,1e-10)
                if method=='LHS':
                    checks['stratification']=all(len(set(np.floor(16*u[:,j]).astype(int)))==16 for j in range(72))
                if method=='MC':first=a[0]
            if first is not None:
                physical=np.r_[.15*first[:42],.3348+.15*first[42:48],.1*first[48:]]
                checks['physical_units']=near(solution['first_MC_physical_mm'],physical)
        elif key=='S06':
            p={k:solution[k] for k in ('library_id','tie_tolerance_mm','adjust')}
            r=artifact(solution['artifact_id'],p)
            needed=sum(abs(n)*a for n,a in zip(f['master_normal'],f['offset_limits_mm']))+f['margin_mm']
            checks.update(library_identity=r['compatible'],coverage=r['coverage'],no_adjustment=solution['adjust'] is False,
                minimal_tolerance=near(solution['tie_tolerance_mm'],needed,1e-8))
        elif key=='S07':
            lo,hi=solution['lambda_safe'],solution['lambda_failed'];ids=solution['artifact_ids']
            a=artifact(ids[0],{'lambda':lo});b=artifact(ids[1],{'lambda':hi})
            checks.update(bracket=0<=lo<hi<=2 and hi-lo<=.002,
                safe=not a['failed'],failed=b['failed'],different_evidence=ids[0]!=ids[1])
        else:
            artifact(solution['artifact_id'],{})
            trusted={n:c for n,c in f['cases'].items() if c['solver']=='completed' and
                abs(abs(c['U3'])-f['final_abs_U3_mm'])<=1e-6 and len(c['forces'])==f['expected_pairs']}
            ranking=sorted(trusted,key=lambda n:(min(map(abs,trusted[n]['forces'])),n))
            failures=[n for n in ranking if min(map(abs,trusted[n]['forces']))<f['threshold_N']]
            actions={n:('done' if n in trusted else 'wait' if c.get('active') else
                'retry_solve' if c['solver']=='interrupted' else 'reextract' if c['solver']=='completed' else 'repair_mesh')
                for n,c in f['cases'].items()}
            checks.update(trusted_ranking=solution['ranking']==ranking,contact_failure=solution['contact_failures']==failures,
                recovery=solution['actions']==actions)
    except (KeyError,TypeError,ValueError,IndexError,OverflowError) as error:
        checks['schema_and_artifacts']=False
        return dict(status='failed',score=0,checks=checks,error=str(error))
    passed=bool(checks) and all(checks.values())
    return dict(status='passed' if passed else 'failed',score=100 if passed else 0,checks=checks)
