"""Host-only independent checks. This module is never exposed as an agent tool."""
import math
from .mechanics import condensation_test, finite


def evaluate(task, solution, artifacts):
    checks = {}
    fixture = task["fixture"]
    if task["status"] != "executable_fixture":
        return dict(status="not_implemented", score=None, tier=task["tier"])
    if "nodes_mm" in fixture:
        # Independent analytical series-bar reference, not the exposed FEM implementation.
        force = fixture["applied_tip_force_N"]
        compliance = math.fsum((b-a)/(s["E_MPa"]*s["area_mm2"])
            for a, b, s in zip(fixture["nodes_mm"], fixture["nodes_mm"][1:], fixture["segments"]))
        targets = dict(tip_U_mm=force*compliance, support_RF_N=-force,
                       strain_energy_Nmm=force*force*compliance/2)
        for key, target in targets.items():
            value = solution.get(key)
            checks[key] = finite(value) and math.isclose(value, target, rel_tol=1e-7, abs_tol=1e-10)
        stress = solution.get("stress_MPa", [])
        checks["stress_MPa"] = isinstance(stress, list) and len(stress) == len(fixture["segments"]) and all(
            finite(v) and math.isclose(v, force/s["area_mm2"], rel_tol=1e-7, abs_tol=1e-10)
            for v, s in zip(stress, fixture["segments"]))
        artifact = artifacts.get(solution.get("solver_artifact"), {})
        checks["executed_artifact"] = artifact.get("tool") == "axial_solve"
        weights = dict(tip_U_mm=25, support_RF_N=25, strain_energy_Nmm=15, stress_MPa=15, executed_artifact=20)
    else:
        try:
            # Independently reconstruct mechanics and interfaces; do not trust reported error.
            core, sub, retained = (solution[k] for k in ("core_regions", "sub_regions", "retained_dofs"))
            if any(not isinstance(v, list) for v in (core, sub, retained)):
                raise ValueError("Expected lists")
            expected = {r["id"] for r in fixture["regions"]}
            checks["partition"] = (not set(core)&set(sub) and set(core)|set(sub) == expected
                                   and len(core)+len(sub) == len(expected))
            nonlinear = {r["id"] for r in fixture["regions"] if r["law"] != "linear"}
            checks["nonlinear_preserved"] = nonlinear <= set(core)
            required = {fixture["fixed_dof"], fixture["loaded_dof"]}
            for region in fixture["regions"]:
                if region["id"] in core:
                    required.update(region["dofs"])
            edges = sorted([r for r in fixture["regions"] if r["id"] in sub], key=lambda r:r["dofs"][0])
            selected_edges = {tuple(r["dofs"]) for r in edges}
            for region in edges:
                a, b = region["dofs"]
                if (a-1, a) not in selected_edges:
                    required.add(a)
                if (b, b+1) not in selected_edges:
                    required.add(b)
            checks["interfaces"] = required <= set(retained) and len(set(retained)) == len(retained) and all(
                type(d) is int and 0 <= d <= 6 for d in retained)
            errors = []
            for force in fixture["load_envelope_N"]:
                truth, candidate = 0., 0.
                for region in fixture["regions"]:
                    linear = force/region["stiffness_N_mm"]
                    value = linear
                    transition = region.get("transition_force_N", math.inf)
                    if force > transition:
                        value = transition/region["stiffness_N_mm"] + (force-transition)/region["post_stiffness_N_mm"]
                    truth += value
                    candidate += linear if region["id"] in sub else value
                errors.append(abs(candidate-truth)/truth)
            checks["response_accuracy"] = max(errors) <= fixture["max_relative_tip_error"]
            reported = solution.get("relative_tip_error")
            checks["reported_error"] = finite(reported) and math.isclose(reported, max(errors), abs_tol=1e-9)
            all_sub_dofs = {d for r in edges for d in r["dofs"]}
            eliminated = all_sub_dofs-set(retained)
            checks["genuine_reduction"] = len(eliminated) >= 1 and not eliminated & required
            artifact = artifacts.get(solution.get("artifact_id"), {})
            checks["executed_artifact"] = artifact.get("tool") == "condensation_test" and artifact.get("arguments") == dict(
                core_regions=core, sub_regions=sub, retained_dofs=retained)
        except (KeyError, ValueError, TypeError, ZeroDivisionError):
            checks = dict(invalid_submission=False)
        weights = dict(partition=15, nonlinear_preserved=20, interfaces=20, response_accuracy=15,
                       reported_error=5, genuine_reduction=15, executed_artifact=10)
    score = sum(weights.get(k, 0) for k, passed in checks.items() if passed)
    return dict(status="passed" if checks and all(checks.values()) else "failed", score=score,
                tier=task["tier"], checks=checks,
                scope="fixture decision and numerical checks; not full CAE execution or prose-quality grading")
