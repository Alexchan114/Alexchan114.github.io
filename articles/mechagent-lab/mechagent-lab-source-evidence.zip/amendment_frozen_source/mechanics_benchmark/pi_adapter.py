"""Real Pi SDK subprocess, with host-owned numerical tools and redacted evidence."""
import json
import os
from pathlib import Path
import queue
import subprocess
import threading
import time

from .api import SYSTEM


def run_pi(route, args, query, definitions, broker, trace):
    module = Path(args.pi_module).resolve()
    if not module.is_file():
        raise FileNotFoundError("Pi SDK module missing; see isolated runtime setup in README")
    command = [args.node, str(Path(__file__).with_name("pi_bridge.mjs"))]
    # No inherited provider secrets, user auth files or proxy configuration are required.
    env = {k: v for k, v in os.environ.items() if k.upper() in
           ("SYSTEMROOT", "WINDIR", "PATH", "TEMP", "TMP", "USERPROFILE", "APPDATA", "LOCALAPPDATA")}
    proc = subprocess.Popen(command, cwd=trace.root, env=env, stdin=subprocess.PIPE,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8",
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
    incoming = queue.Queue()
    errors = []

    def reader():
        for line in proc.stdout:
            incoming.put(line)
        incoming.put(None)

    def stderr_reader():
        for line in proc.stderr:
            errors.append(line)

    threading.Thread(target=reader, daemon=True).start()
    threading.Thread(target=stderr_reader, daemon=True).start()

    def send(message):
        proc.stdin.write(json.dumps(message, ensure_ascii=False) + "\n")
        proc.stdin.flush()

    send(dict(type="init", module=str(module), cwd=str(trace.root), secret=route.secret,
              model=args.model, protocol=route.protocol, base_url=route.base_url,
              query=query, system=SYSTEM, tools=definitions, max_turns=args.max_turns,
              max_output_tokens=args.max_output_tokens, timeout_ms=args.timeout*1000))
    deadline = time.monotonic()+args.timeout*args.max_turns+60
    usages, outcome = [], dict(status="bridge_exited")
    try:
        while time.monotonic() < deadline:
            try:
                line = incoming.get(timeout=min(2, max(.1, deadline-time.monotonic())))
            except queue.Empty:
                continue
            if line is None:
                break
            message = json.loads(line)
            kind = message.pop("type")
            if kind == "tool_request":
                result = broker.call(message["name"], message["arguments"], message["id"])
                send(dict(type="tool_result", id=message["id"], result=result))
            else:
                trace.write("pi_"+kind, **message)
                if kind == "pi_event":
                    event = message["event"]
                    if event.get("type") == "message_end" and event.get("message", {}).get("role") == "assistant":
                        usages.append(event["message"].get("usage"))
                elif kind == "done":
                    trace.save("pi_messages.json", message)
                    outcome = dict(status="submitted" if broker.submission else "no_submission",
                                   turns=message["turns"], usages=usages,
                                   model_identity_note="requested ID; actual provider alias resolution may be unobservable")
                    break
                elif kind == "bridge_error":
                    outcome = dict(status="submitted" if broker.submission else "execution_error", error=message["error"], usages=usages)
                    break
        else:
            raise TimeoutError("Pi task wall-time budget exhausted")
    finally:
        if proc.poll() is None:
            proc.terminate()
        proc.wait(timeout=15)
        for stream in (proc.stdin, proc.stdout, proc.stderr):
            stream.close()
        trace.save("pi_stderr.json", dict(stderr="".join(errors)[-8000:]))
    return outcome
