"""No paths/code/network in agent capabilities; native CAE is host-dispatched."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from .security import digest
from . import suite_physics as physics


class Broker:
    def __init__(self,card,trace,solver_root=None,reference=None):
        self.card,self.trace=deepcopy(card),trace
        self.calls=0;self.artifacts={};self.submission=None;self.solver_calls=0
        self.solver_root=Path(solver_root) if solver_root else None
        self.reference=Path(reference) if reference else None

    def native(self,cut,call_id):
        if type(cut) is not int or cut not in (2,4,6):raise ValueError('Cut intersects nonlinear material or is unsupported')
        if self.solver_root is None or self.reference is None:raise ValueError('Host native solver not configured')
        if self.solver_calls>=1:raise ValueError('One native candidate allowed per attempt')
        self.solver_calls+=1
        output=self.solver_root/self.trace.root.name
        if output.exists():raise ValueError('Native workspace already exists; do not overwrite')
        output.parent.mkdir(parents=True,exist_ok=True)
        cmd=['D:/kimi/cae-mcp/.venv/Scripts/python.exe','-m','mechanics_benchmark.solid_candidate',
            '--output',str(output),'--reference',str(self.reference),'--cut',str(cut)]
        self.trace.write('native_dispatch',parent_call_id=call_id,cut_mm=cut,resources=dict(cpus=1,memory_percent=10))
        proc=subprocess.run(cmd,cwd=Path(__file__).resolve().parents[1],capture_output=True,text=True,
            encoding='utf-8',errors='replace',timeout=1500,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0)
        self.trace.save('native_console.json',dict(returncode=proc.returncode,stdout=proc.stdout,stderr=proc.stderr))
        mcp_trace=output/'mcp_trace.jsonl'
        if mcp_trace.is_file():
            for line in mcp_trace.read_text().splitlines():
                self.trace.write('native_mcp',parent_call_id=call_id,event=json.loads(line))
        if proc.returncode:raise RuntimeError('Native solver candidate failed; inspect host trace, not a physical failure')
        result=json.loads((output/'candidate_result.json').read_text())
        self.trace.save('native_result.json',result)
        return result

    def experiment(self,p,call_id):
        key=self.card['id'];f=self.card['fixture']
        fields={'S01':set(),'S02':{'n'},'S03':{'amplitudes'},'S04':{'cut_mm'},'S05':{'method','seed'},
            'S06':{'library_id','tie_tolerance_mm','adjust'},'S07':{'lambda'},'S08':set()}
        if set(p)!=fields[key]:raise ValueError('Unexpected experiment parameter fields')
        if key=='S01':return physics.axial(f)
        if key=='S02':return physics.mesh(f,**p)
        if key=='S03':return physics.contact(f,**p)
        if key=='S04':return self.native(p['cut_mm'],call_id)
        if key=='S05':return physics.sample(f,**p)
        if key=='S06':return physics.interface(f,**p)
        if key=='S07':return physics.pose(f,p['lambda'])
        return dict(engine='read-only synthetic job evidence; no real jobs submitted',cases=f['cases'])

    def call(self,name,arguments,call_id=None):
        self.calls+=1
        try:
            json.dumps(arguments,allow_nan=False)
        except (ValueError,TypeError):
            result=dict(error='Arguments must be finite JSON')
            self.trace.write('invalid_tool_request',name=name,call_id=call_id,error=result['error'])
            self.trace.write('tool_response',name=name,result=result,call_id=call_id)
            return result
        self.trace.write('tool_request',name=name,arguments=arguments,call_id=call_id)
        try:
            if self.calls>self.card['budget']['max_tool_calls']:raise ValueError('Tool budget exhausted')
            if self.submission is not None:raise ValueError('Already submitted')
            if not isinstance(arguments,dict) or len(json.dumps(arguments,allow_nan=False))>40000:raise ValueError('Invalid arguments')
            if name=='inspect_fixture' and not arguments:result=dict(fixture=self.card['fixture'],output=self.card['output'])
            elif name=='experiment' and set(arguments)=={'parameters'} and isinstance(arguments['parameters'],dict):
                p=arguments['parameters'];raw=self.experiment(p,call_id)
                record=dict(task=self.card['id'],parameters=deepcopy(p),result=raw)
                identity='artifact_'+digest(record)[:20];self.artifacts[identity]=record
                self.trace.save('artifacts/'+identity+'.json',record)
                visible={k:v for k,v in raw.items() if k not in ('uniform','amplitudes') or self.card['id']!='S05'}
                if self.card['id']=='S05':visible.update(shape=[16,72],bounds=[-1,1],matrices='saved as host artifact, not expanded into model context')
                result=dict(artifact_id=identity,**visible)
            elif name=='submit_solution' and set(arguments)=={'solution','explanation'}:
                if not isinstance(arguments['solution'],dict) or not isinstance(arguments['explanation'],str):raise ValueError('Invalid submission')
                self.submission=deepcopy(arguments);self.trace.save('submission.json',self.submission);result=dict(submitted=True)
            else:raise ValueError('Tool unavailable or schema mismatch')
        except (TypeError,ValueError,KeyError) as error:result=dict(error=str(error))
        self.trace.write('tool_response',name=name,result=result,call_id=call_id)
        return result
