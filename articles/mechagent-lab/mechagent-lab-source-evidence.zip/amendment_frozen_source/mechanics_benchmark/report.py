"""Build auditable pilot tables and complete observable query/output appendices."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

from .credentials import inventory
from .security import scrub
from .tasks import TASKS


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def classify(meta, events):
    if meta["adapter"] == "pi":
        ready = next((e for e in events if e["kind"] == "pi_harness_ready"), {})
        if set(ready.get("active_tools", [])) != {"inspect_fixture", "condensation_test" if meta["task_id"] == "M04" else "axial_solve", "submit_solution"}:
            return "excluded_adapter_invalid"
    if meta["status"] == "execution_error":
        return "excluded_environment_error"
    if meta.get("evaluation", {}).get("status") == "passed":
        return "passed"
    if any(e["kind"] == "model_response" and e.get("response", {}).get("stop_reason") == "max_tokens" for e in events):
        return "output_budget_exhausted"
    return "failed_or_not_submitted"


def usage(events):
    ordinary, cache, cache_write, output, calls = 0, 0, 0, 0, 0
    for event in events:
        if event["kind"] == "model_response":
            value = event["response"].get("usage", {})
            if "input_tokens" not in value or "output_tokens" not in value:
                return dict(ordinary_input=None, cache_read=None, cache_write=None, output=None, api_responses=None)
            ordinary += value["input_tokens"]
            cache += value.get("cache_read_input_tokens", 0)
            cache_write += value.get("cache_creation_input_tokens", 0)
            output += value["output_tokens"]
            calls += 1
        elif event["kind"] == "pi_pi_event":
            msg = event.get("event", {}).get("message", {})
            if msg.get("role") == "assistant" and msg.get("responseId"):
                value = msg.get("usage", {})
                if "input" not in value or "output" not in value:
                    return dict(ordinary_input=None, cache_read=None, cache_write=None, output=None, api_responses=None)
                ordinary += value["input"]
                cache += value.get("cacheRead", 0)
                cache_write += value.get("cacheWrite", 0)
                output += value["output"]
                calls += 1
    if calls == 0:
        return dict(ordinary_input=None, cache_read=None, cache_write=None, output=None, api_responses=0)
    return dict(ordinary_input=ordinary, cache_read=cache, cache_write=cache_write, output=output, api_responses=calls)


def build(root):
    root = Path(root).resolve()
    rows, manifest, transcripts = [], {}, []
    docs = root/"documentation"
    docs.mkdir(exist_ok=True)
    for folder in sorted((root/"pilot").iterdir()):
        if not (folder/"run.json").exists():
            continue
        meta = read(folder/"run.json")
        if meta["status"] == "running":
            raise ValueError("Do not publish while a pilot is running")
        events = [json.loads(line) for line in (folder/"trace.jsonl").read_text(encoding="utf-8").splitlines()]
        classification = classify(meta, events)
        row = dict(run=folder.name, task=meta["task_id"], model=meta["requested_model"], harness=meta["adapter"],
                   tier=meta["tier"], classification=classification,
                   score=meta.get("evaluation", {}).get("score") if not classification.startswith("excluded_") else None,
                   elapsed_seconds=meta["elapsed_seconds"], tool_calls=meta["tool_calls"], **usage(events))
        rows.append(row)
        transcripts.append((folder.name, meta, events))
        for path in sorted(folder.rglob("*")):
            if path.is_file():
                manifest[str(path.relative_to(root)).replace("\\", "/")] = hashlib.sha256(path.read_bytes()).hexdigest()
    summary = dict(status="development-pilot-not-full-benchmark", task_families=8,
                   executable_fixture_tasks=2, live_cae_evaluated_tasks=0,
                   valid_runs=sum(not r["classification"].startswith("excluded_") for r in rows),
                   passed_runs=sum(r["classification"] == "passed" for r in rows), rows=rows,
                   actual_billed_usd=None,
                   limits="One pilot per configuration/task. Different models and harnesses change together; no causal ranking. No vendor solver execution in these task runs.")
    (root/"pilot_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (root/"evidence_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    with (root/"pilot_summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for lang in ("zh", "en"):
        title = "逐轮 Query 与 Output 审计附录" if lang == "zh" else "Observable Query and Output Audit Appendix"
        text = ["# " + title, "", "Scope: all pilot attempts, including invalid probes. Original JSONL remains authoritative. No hidden or unexposed prompts were reconstructed.", ""]
        for name, meta, events in transcripts:
            text += ["## " + name, "", "```json", json.dumps(scrub(meta), indent=2, ensure_ascii=False), "```", ""]
            for event in events:
                text += ["### Event {}: {}".format(event["index"], event["kind"]), "", "```json", json.dumps(event, indent=2, ensure_ascii=False), "```", ""]
        (docs/("QUERY_OUTPUTS_"+lang.upper()+".md")).write_text("\n".join(text), encoding="utf-8")
        cards = ["# " + ("题库与执行状态" if lang == "zh" else "Task Cards and Implementation Status"), ""]
        for key, task in TASKS.items():
            cards += ["## " + key + " - " + task["title_zh" if lang == "zh" else "title"],
                      "", "Status: " + task["status"] + "; tier: " + task["tier"], "", task["query_"+lang], "",
                      "```json", json.dumps(task["fixture"], ensure_ascii=False, indent=2), "```", ""]
        (docs/("TASK_CARDS_"+lang.upper()+".md")).write_text("\n".join(cards), encoding="utf-8")
    # A real credential-value scan, not merely a search for key-shaped words.
    secrets = [r.secret for r in inventory() if len(r.secret) >= 8]
    scanned = list((root/"pilot").rglob("*.json")) + list((root/"pilot").rglob("*.jsonl")) + list(docs.glob("*.md"))
    for path in scanned:
        data = path.read_text(encoding="utf-8")
        if any(secret in data for secret in secrets):
            raise ValueError("Credential-value audit failed; nothing may be published")
    (root/"privacy_audit.json").write_text(json.dumps(dict(passed=True, scanned_files=len(scanned),
            secret_sources="CCS credential values checked locally, values not retained", industrial_data_included=False)), encoding="utf-8")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    print(json.dumps(build(args.root), indent=2))
