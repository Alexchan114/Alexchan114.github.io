"""Run from the project root: python -m mechanics_benchmark --help."""
import argparse
import hashlib
from importlib.metadata import version as package_version
from datetime import datetime, timezone
import json
from pathlib import Path
import platform
import sys
import time

from . import __version__
from .api import Client, SYSTEM, run_loop
from .credentials import inventory, select, DEFAULT_DB
from .evaluate import evaluate
from .security import Trace, digest
from .tasks import TASKS, get_task, prompt
from .tools import Broker, definitions


def run(args):
    task = get_task(args.task)
    if task["status"] != "executable_fixture":
        raise ValueError("Task is specified but its independent live-CAE fixture is not implemented yet")
    route = select(args.provider, args.ccs_db, args.app)
    if not args.model or "[" in args.model or "]" in args.model:
        raise ValueError("Use an exact API model ID, not a decorated CCS context-window alias")
    root = Path(args.output).resolve()
    root.mkdir(parents=True, exist_ok=False)
    trace = Trace(root, [route.secret])
    query = prompt(args.task, args.language)
    specs = definitions(args.task)
    metadata = dict(version=__version__, task_id=args.task, tier=task["tier"], adapter=args.adapter,
        provider=route.public(), requested_model=args.model,
        fixture_hash=digest(task["fixture"]), query_hash=digest(query), tools_hash=digest(specs),
        task_hash=digest(task), started_utc=datetime.now(timezone.utc).isoformat(),
        budgets=dict(max_turns=args.max_turns, max_output_tokens=args.max_output_tokens,
                     timeout_per_call_s=args.timeout, max_tool_calls=18),
        isolation="model receives only fixed capability tools; no shell or filesystem tools",
        hardware=dict(python=sys.version.split()[0], platform=platform.platform()),
        source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in Path(__file__).parent.iterdir() if p.suffix in (".py", ".mjs")},
        dependencies={name:package_version(name) for name in ("numpy", "httpx")},
        cost=dict(actual_billed_usd=None, estimated_usd=None, note="Usage is not an invoice"),
        status="running")
    trace.save("run.json", metadata)
    trace.save("task.json", task)
    trace.save("query.json", dict(system=SYSTEM, user=query, tools=specs))
    broker = Broker(args.task, task, trace)
    started = time.monotonic()
    try:
        if args.adapter == "mini":
            result = run_loop(Client(route, args.model, trace, args.max_output_tokens, args.timeout),
                              query, specs, broker, args.max_turns)
        else:
            from .pi_adapter import run_pi
            result = run_pi(route, args, query, specs, broker, trace)
        if broker.submission is not None:
            scoring = evaluate(task, broker.submission["solution"], broker.artifacts)
        else:
            scoring = dict(status="not_submitted", score=0, tier=task["tier"])
        trace.save("evaluation.json", scoring)
        metadata.update(status=result["status"], result=result, evaluation=scoring)
    except Exception as error:
        trace.write("execution_error", error=str(error), error_type=type(error).__name__)
        metadata.update(status="execution_error", error_type=type(error).__name__, error=str(error))
    finally:
        metadata.update(elapsed_seconds=time.monotonic()-started,
                        finished_utc=datetime.now(timezone.utc).isoformat(), tool_calls=broker.calls)
        trace.save("run.json", metadata)
    print(json.dumps(dict(output=str(root), status=metadata["status"],
                          evaluation=metadata.get("evaluation")), ensure_ascii=False, indent=2))
    return 0 if metadata["status"] == "submitted" else 2


def main():
    parser = argparse.ArgumentParser(description="Auditable mechanics benchmark; never changes production APP")
    commands = parser.add_subparsers(dest="command", required=True)
    p = commands.add_parser("inventory", help="Read CCS metadata only; credentials are never printed")
    p.add_argument("--ccs-db", type=Path, default=DEFAULT_DB)
    commands.add_parser("tasks")
    p = commands.add_parser("run")
    p.add_argument("--task", choices=TASKS, required=True)
    p.add_argument("--adapter", choices=["mini", "pi"], default="mini")
    p.add_argument("--provider", required=True, help="Exact CCS provider ID")
    p.add_argument("--app", default="claude", help="CCS namespace; does not select the agent harness")
    p.add_argument("--model", required=True)
    p.add_argument("--ccs-db", type=Path, default=DEFAULT_DB)
    p.add_argument("--output", required=True)
    p.add_argument("--language", choices=["zh", "en"], default="en")
    p.add_argument("--max-turns", type=int, choices=range(1, 13), default=6)
    p.add_argument("--max-output-tokens", type=int, choices=range(256, 8193), default=4096)
    p.add_argument("--timeout", type=int, choices=range(10, 601), default=180)
    p.add_argument("--pi-module", default="outputs/mechanics_agent_benchmark_20261103/pi-runtime/node_modules/@mariozechner/pi-coding-agent/dist/index.js")
    p.add_argument("--node", default="D:/NodeJs/node.exe")
    args = parser.parse_args()
    if args.command == "inventory":
        print(json.dumps([r.public() for r in inventory(args.ccs_db)], ensure_ascii=False, indent=2))
    elif args.command == "tasks":
        print(json.dumps([dict(id=k, title=v["title"], title_zh=v["title_zh"], status=v["status"], tier=v["tier"])
                          for k, v in TASKS.items()], ensure_ascii=False, indent=2))
    else:
        return run(args)
    return 0
