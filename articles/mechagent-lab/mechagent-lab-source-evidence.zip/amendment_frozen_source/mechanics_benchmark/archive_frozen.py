"""Recover exact registered source bytes after a reviewed task-text amendment.

Every recovered file must match its pre-inference SHA256; no approximate source
is accepted. Newer releases snapshot at freeze time instead of using recovery.
"""
import hashlib
import json
from pathlib import Path
import shutil


ROOT=Path(__file__).resolve().parents[1]


def archive(folder):
    reg=json.loads((folder/'preregistration.json').read_text(encoding='utf-8'))
    dest=folder/'frozen_source/mechanics_benchmark';dest.mkdir(parents=True,exist_ok=True)
    reconstructed=[]
    for name,expected in reg['source_hashes'].items():
        data=(ROOT/'mechanics_benchmark'/name).read_bytes()
        if hashlib.sha256(data).hexdigest()!=expected:
            text=data.decode('utf-8')
            if reg['version']=='0.2.0' and name=='suite_v2.py':
                text=text.replace("VERSION = '0.2.1'","VERSION = '0.2.0'")
                current=__import__('mechanics_benchmark.suite_v2',fromlist=['task_cards']).task_cards()
                for key in ('S06','S08'):
                    text=text.replace("query='"+current[key]['query']+"'","query='"+reg['tasks'][key]['query']+"'")
                text=text.replace("adjust='JSON boolean false, not string'","adjust='false'")
            elif reg['version']=='0.2.0' and name=='run_suite.py':
                text=text.replace('def freeze(root,amendment_of=None):','def freeze(root):')
                start=text.index('    if amendment_of:\n');end=text.index("    path=root/'preregistration.json'",start)
                text=text[:start]+text[end:]
                text=text.replace("    p.add_argument('--amendment-of',type=Path)\n",'')
                text=text.replace('freeze(a.output,a.amendment_of)','freeze(a.output)')
            else:raise ValueError('Cannot recover registered source '+name)
            data=text.encode('utf-8');reconstructed.append(name)
        if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('Exact registered hash recovery failed: '+name)
        (dest/name).write_bytes(data)
    for name in ('pi_bridge.mjs','requirements.txt'):
        shutil.copy2(ROOT/'mechanics_benchmark'/name,dest/name)
    receipt=dict(all_registered_hashes_verified=True,registered_files=len(reg['source_hashes']),
        recovered_after_amendment=reconstructed,
        provenance='Registered SHA256 exact-match reconstruction for changed files; unchanged files copied.',
        supplemental_not_preinference_hashed=['pi_bridge.mjs','requirements.txt'])
    (folder/'frozen_source/verification.json').write_text(json.dumps(receipt,indent=2))
    print(receipt)


if __name__=='__main__':
    base=ROOT/'outputs/mechanics_agent_benchmark_v02_20261104'
    archive(base);archive(base/'amendment')
