"""Eight frozen public exercises, distinct from the historical v0.1 fixtures.

Only S04 uses a commercial solver. All other responses declare their reduced
physics explicitly; they must never be reported as HyperMesh/Abaqus executions.
"""
from copy import deepcopy
import math

VERSION = '0.2.2'


def task_cards():
    cards = {
        'S01': dict(title='Units, series compliance and equilibrium', title_zh='单位、串联柔度与平衡',
            query='Find tip U in mm, root reaction in N and total strain energy in N mm. Convert GPa to MPa. Execute the FEM tool and cite its artifact.',
            fixture=dict(length_mm=[4,6,2],area_mm2=[2,3,1],E_GPa=[2,1,3],tip_force_N=12),
            output=dict(artifact_id='string',U_mm='number',reaction_N='number',energy_Nmm='number')),
        'S02': dict(title='Goal-oriented mesh allocation', title_zh='面向目标响应的网格分配',
            query='Use uniform 1D linear axial elements and midpoint area. Choose the smallest allowed n with relative tip-U error <=0.001 versus the exact continuum integral. Execute the mesh tool for the submitted n; report U and relative error.',
            fixture=dict(L_mm=1,E_MPa=1000,F_N=10,A_mm2='1+x (x in mm)',
                allowed_n=[1,2,4,8,16,32,64],relative_tolerance=.001),
            output=dict(artifact_id='string',n='integer',U_mm='number',relative_error='number')),
        'S03': dict(title='Independent prelift and unilateral contact', title_zh='独立预抬与单边接触',
            query='Six plates each control consecutive pairs (1,2),(3,4),etc. Choose six independent amplitudes in [0,1] minimizing sum(a_i^2) while every final normal force is >=0.4 N. No friction contribution. Use contact_test; report amplitudes and 12 final forces. This is a unilateral spring model, not a solid/contact solver.',
            fixture=dict(base_lift_mm=.3348,scale_mm=.15,insertion_mm=.18,
                gaps_mm=[.48,.52,.54,.50,.53,.56,.49,.51,.57,.55,.52,.54],
                stiffness_N_per_mm=[6,8,7,6,8,7,6,9,7,8,6,7],threshold_N=.4),
            output=dict(artifact_id='string',amplitudes='six numbers',forces_N='12 numbers')),
        'S04': dict(title='Autonomous 3D substructure partition', title_zh='三维子结构自主分区',
            query='Choose the cut maximizing eliminated translational DOFs while keeping all potentially plastic elements outside the linear substructure. Retain ROOT and all interface translations. Run partition_test on your chosen cut: it invokes actual Abaqus generation, reduced solve and ODB extraction via MCP (1 CPU). Cite the returned artifact. Do not use stress magnitude alone to declare a region linear.',
            fixture=dict(dimensions_mm=[12,2,2],mesh='117 nodes,48 C3D8; x planes at integers; 9 nodes per plane',
                node_rule='label=1+9*i+3*j+k; i=0..12,j,k=0..2',
                materials=[dict(x_mm=[0,6],E_MPa=1000,nu=0,law='linear elastic'),
                    dict(x_mm=[6,12],E_MPa=1000,nu=0,law='J2 plastic; yield=1MPa; hardening=50MPa')],
                load='ROOT fixed; TIP U1=0.12mm, NLGEOM=NO',cuts_mm=[2,4,6,8],
                requirement='linear substructure must preserve nonlinear constitutive regions; curve error <=1e-4 N'),
            output=dict(artifact_id='string',cut_mm='integer',retained_nodes='18 integers',
                retained_dofs='[1,2,3]',eliminated_dofs='integer')),
        'S05': dict(title='Bounded sampling and physical tolerance mapping', title_zh='有界抽样及物理公差映射',
            query='Generate 16 samples of 72 independent variables using each of MC,LHS,Sobol,Halton. All marginals are standard normal conditioned on [-1,1], not clipped normal or uniform. Use sample_test once per method, seed=20261104. Submit four artifact IDs and physical values for the first MC vector. First42 are Z shape changes (0.15a mm), next6 prelift (.3348+0.15a mm), final24 alternating X,Y per 12 rigid CORE terminals (0.1a mm). SUB is unchanged; translation preserves terminal dimensions.',
            fixture=dict(n=16,dimensions=72,seed=20261104,bounds=[-1,1],marginal='truncated standard normal',
                shape_count=42,prelift_count=6,terminal_count=12),
            output=dict(artifact_ids='4 strings, MC/LHS/Sobol/Halton order',
                first_MC_physical_mm='72 numbers')),
        'S06': dict(title='Reuse, geometry compatibility and Tie coverage', title_zh='复用、几何兼容与绑定覆盖',
            query='Choose a reusable library matching target retained topology/material/coordinates. Independently translated CORE slave faces need an unadjusted Tie to an unchanged master plane; maximum normal offset is 0.1mm X +0.1mm Y projected on n. Give minimal safe tolerance=max distance+1e-6 mm, ADJUST=false. In both experiment and final solution, adjust MUST be a JSON boolean false, not a string. Tolerance must not excuse an incompatible library. Execute interface_test.',
            fixture=dict(target=dict(topology='mesh-A',material='E1000',retained_xyz=[[0,0,0],[0,0,1]]),
                libraries={'L17':dict(topology='mesh-A',material='E1000',retained_xyz=[[0,0,0],[0,0,1]]),
                    'L24':dict(topology='mesh-A',material='E1000',retained_xyz=[[0,0,0],[0,.02,1]]),
                    'L33':dict(topology='mesh-A',material='E1200',retained_xyz=[[0,0,0],[0,0,1]]),
                    'L41':dict(topology='mesh-B',material='E1000',retained_xyz=[[0,0,0],[0,0,1]])},
                master_normal=[1/math.sqrt(2),1/math.sqrt(2),0],offset_limits_mm=[.1,.1],margin_mm=1e-6),
            output=dict(artifact_id='string',library_id='string',tie_tolerance_mm='number',adjust='JSON boolean false, not string')),
        'S07': dict(title='Coupled offset-angle first-loss boundary', title_zh='偏位偏角耦合首失效边界',
            query='Along lambda in [0,2], offset X=0.1*lambda mm and angle=2*lambda deg, find a safe/failing bracket for the FIRST contact loss. Any of12 normal forces <0.4N fails. Return lambda_safe,lambda_failed with width<=0.002 and two pose_test artifacts proving endpoints. Kinematic spring contact only, not a connector prediction. Use the lever-arm geometry rather than a reward surrogate.',
            fixture=dict(k_N_per_mm=[6+i*.2 for i in range(12)],
                initial_overlap_mm=[.19+i*.003 for i in range(12)],
                normal_x=[.45+i*.02 for i in range(12)],lever_mm=[1.5+i*.06 for i in range(12)],
                path=dict(offset_X_mm_per_lambda=.1,angle_deg_per_lambda=2),threshold_N=.4,lambda_limits=[0,2]),
            output=dict(lambda_safe='number',lambda_failed='number',artifact_ids='safe/fail IDs')),
        'S08': dict(title='Failure recovery and trustworthy ranking', title_zh='故障恢复与可信排序',
            query='Rank only trustworthy completed cases by minimum absolute normal force across12pairs at final |U3|=8mm. Sort ASCENDING minimum force, weakest first; ties by case ID ascending. Return contact_failures in this same ascending order. Report failure cases (<0.4N) and a recovery action for every case. Completed evidence must include solver success, final frame,12channels. Minimal recovery policy: every trustworthy completed case is done, including genuine contact failures; physical failure alone is not a reason to retry. Inactive interrupted jobs use retry_solve, completed jobs with missing channels use reextract, active jobs use wait, input errors with negative volume use repair_mesh. Never retry an active job or treat numerical abort as contact failure. inspect_cases exposes read-only evidence; no solver is launched.',
            fixture=dict(final_abs_U3_mm=8,expected_pairs=12,threshold_N=.4,
                cases={
                    'c01':dict(solver='completed',U3=-8,forces=[-.41]+[-.8]*11,active=False),
                    'c02':dict(solver='completed',U3=-8,forces=[-.9]*7+[-.35]+[-.8]*4,active=False),
                    'c03':dict(solver='completed',U3=-8,forces=[-.38]+[-.9]*11,active=False),
                    'c04':dict(solver='interrupted',U3=-7,forces=[-.01]*12,active=False),
                    'c05':dict(solver='completed',U3=-8,forces=[-.1]*11,active=False),
                    'c06':dict(solver='running',U3=-4,forces=[-.1]*12,active=True),
                    'c07':dict(solver='input_error',error='negative element volume',active=False),
                    'c08':dict(solver='completed',U3=-8,forces=[-.45]+[-.8]*11,active=False)}),
            output=dict(artifact_id='string',ranking='case IDs',contact_failures='case IDs',
                actions='object: done/retry_solve/reextract/wait/repair_mesh')),
    }
    for key,c in cards.items():
        c.update(id=key,version=VERSION,tier='abaqus_mcp_3d' if key=='S04' else 'public_reduced_physics',
            budget=dict(max_turns=6,max_output_tokens=6144,max_tool_calls=24,max_solver_tests=1),
            scoring='binary: all independent checks required; no self-report scoring')
    return deepcopy(cards)


def definitions():
    def tool(name,description,properties,required=None):
        return dict(name=name,description=description,input_schema=dict(type='object',properties=properties,
            required=list(properties) if required is None else required,additionalProperties=False))
    return [tool('inspect_fixture','Read the current public fixture and required output schema.',{}),
        tool('experiment','Execute only the named experiment for the current task. No arbitrary code/files. Valid parameters are in the fixture and query.',
            dict(parameters=dict(type='object'))),
        tool('submit_solution','Submit final structured solution; ends this attempt.',
            dict(solution=dict(type='object'),explanation=dict(type='string')))]


def query(card):
    import json
    return ('Public mechanics benchmark '+card['id']+' v'+VERSION+'\n'+card['query']+
        '\nFixture and output schema:\n'+json.dumps(dict(fixture=card['fixture'],output=card['output']),sort_keys=True)+
        '\nexperiment parameters: S01={}, S02={n}, S03={amplitudes}, S04={cut_mm}, '+
        'S05={method,seed}, S06={library_id,tie_tolerance_mm,adjust}, S07={lambda}, S08={}. '+
        'Cite host-issued artifact IDs, not fabricated ones. Do not submit a plan in place of executed evidence.')
