"""Host-only MCP worker: one agent-selected partition, no arbitrary deck inputs."""
import argparse
import asyncio
import hashlib
import json
from pathlib import Path
from .solid_reference import prepare,deck
from .calibrate_solid import main


def run(root,reference,cut):
    if cut not in (2,4,6):
        raise ValueError('Cannot linearly condense a potentially plastic region')
    validation=json.loads((reference/'validation.json').read_text())
    if not validation['passed']:
        raise ValueError('Uncalibrated reference')
    full=reference/'full.inp'
    if full.read_text()!=deck('full') or hashlib.sha256(full.read_bytes()).hexdigest()!=validation['input_hashes']['full.inp']:
        raise ValueError('Reference full-deck identity changed')
    prepare(root,cut=cut)
    progress=json.loads((reference/'progress.json').read_text())
    (root/'progress.json').write_text(json.dumps(dict(full=progress['full']),indent=2))
    asyncio.run(main(root,resume=True,cut=cut))
    check=json.loads((root/'validation.json').read_text())
    jobs=json.loads((root/'progress.json').read_text())
    result=dict(engine='actual Abaqus via stdio MCP; independent full reference reused',
        cut_mm=cut,eliminated_dofs=27*(cut-1),retained_nodes=list(range(1,10))+list(range(1+9*cut,10+9*cut)),
        checks=check['checks'],max_curve_difference_N=check['max_curve_difference_N'],
        reduced_final=check['reduced_final'],
        jobs={k:v['submitted']['job_id'] for k,v in jobs.items()},
        input_hashes=check['input_hashes'])
    (root/'candidate_result.json').write_text(json.dumps(result,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--reference',type=Path,required=True);p.add_argument('--cut',type=int,required=True)
    a=p.parse_args();run(a.output.resolve(),a.reference.resolve(),a.cut)
