"""Publish only reviewed benchmark assets and semantically changed site indexes."""
from html.parser import HTMLParser
import json
from pathlib import Path
import subprocess


ROOT=Path(__file__).resolve().parents[1]/"outputs/mechanics_agent_benchmark_20261103"
SITE=ROOT/"website"


def git(*args, raw=False):
    result=subprocess.run(["git","-C",str(SITE),*args],capture_output=True,check=True)
    return result.stdout if raw else result.stdout.decode("utf-8").strip()


class Meaning(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.items=[]

    def handle_starttag(self,tag,attrs):
        self.items.append(("start",tag,tuple(sorted(attrs))))

    def handle_endtag(self,tag):
        self.items.append(("end",tag))

    def handle_data(self,value):
        text=" ".join(value.split())
        if text:self.items.append(("text",text))


def semantic(value):
    parser=Meaning()
    parser.feed(value)
    return parser.items


def main():
    if git("remote","get-url","origin") != "https://github.com/Alexchan114/Alexchan114.github.io.git":
        raise ValueError("Unexpected publication repository")
    selected=[]
    modified=git("diff","--name-only").splitlines()
    for name in modified:
        if name.startswith("site-src/"):
            raise ValueError("Unexpected tracked source change")
        path=SITE/name
        old=git("show","HEAD:"+name,raw=True).decode("utf-8")
        new=path.read_text(encoding="utf-8")
        if semantic(old)!=semantic(new) if path.suffix in (".html",".xml") else old.strip()!=new.strip():
            selected.append(name)
    # Do not stage the accidental local Hugo output under site-src.
    new_roots=["articles/mechanics-agent-benchmark","post/2026/11","en/post/2026/11",
        "tags/agent","tags/benchmark","tags/mechanics","en/tags/agent","en/tags/benchmark","en/tags/mechanics",
        "site-src/static/articles/mechanics-agent-benchmark"]
    for name in new_roots:
        if (SITE/name).exists():
            selected.extend(p.relative_to(SITE).as_posix() for p in (SITE/name).rglob("*") if p.is_file())
    selected += ["site-src/content/post/mechanics-agent-benchmark.md","site-src/content/post/mechanics-agent-benchmark.en.md"]
    selected=sorted(set(selected))
    if any(name.startswith("site-src/") and not (name.startswith("site-src/static/articles/mechanics-agent-benchmark/") or name.startswith("site-src/content/post/mechanics-agent-benchmark")) for name in selected):
        raise ValueError("Source allowlist violation")
    git("switch","-c","codex/mechanics-benchmark-20261103")
    git("add","--",*selected)
    git("diff","--cached","--check")
    staged=git("diff","--cached","--name-only").splitlines()
    if staged!=selected:
        raise ValueError("Staged files differ from review manifest")
    (ROOT/"qa/publish_manifest.json").write_text(json.dumps(dict(files=staged),indent=2),encoding="utf-8")
    # The caller reviews this manifest before running the explicit commit/push.
    print(json.dumps(dict(staged_files=len(staged),files=staged),indent=2))


if __name__ == "__main__":
    main()
