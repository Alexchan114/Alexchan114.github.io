"""Numerical experiments exposed to agents, without evaluator or filesystem tools."""
import math
import numpy as np


def axial_solve(fixture):
    xs = fixture["nodes_mm"]
    matrix = np.zeros((len(xs), len(xs)))
    for i, segment in enumerate(fixture["segments"]):
        stiffness = segment["E_MPa"] * segment["area_mm2"] / (xs[i+1]-xs[i])
        matrix[i:i+2, i:i+2] += stiffness * np.array([[1., -1.], [-1., 1.]])
    force = np.zeros(len(xs))
    force[fixture["load_node"]] = fixture["applied_tip_force_N"]
    free = [i for i in range(len(xs)) if i != fixture["fixed_node"]]
    displacement = np.zeros(len(xs))
    displacement[free] = np.linalg.solve(matrix[np.ix_(free, free)], force[free])
    reactions = matrix @ displacement - force
    stresses = [s["E_MPa"]*(displacement[i+1]-displacement[i])/(xs[i+1]-xs[i])
                for i, s in enumerate(fixture["segments"])]
    return dict(solver="numpy-direct-1d-FEM", tier="mechanics-fixture",
                U_mm=displacement.tolist(), tip_U_mm=float(displacement[fixture["load_node"]]),
                support_RF_N=float(reactions[fixture["fixed_node"]]), stress_MPa=stresses,
                strain_energy_Nmm=float(displacement @ matrix @ displacement / 2),
                force_balance_N=float(sum(reactions)+sum(force)))


def components(regions):
    """Connected substructure edge blocks; a retained CORE edge separates blocks."""
    blocks = []
    for region in sorted(regions, key=lambda r: r["dofs"][0]):
        if blocks and blocks[-1][-1]["dofs"][1] == region["dofs"][0]:
            blocks[-1].append(region)
        else:
            blocks.append([region])
    return blocks


def condensation_test(fixture, core_regions, sub_regions, retained_dofs):
    expected = {r["id"] for r in fixture["regions"]}
    if (set(core_regions) & set(sub_regions) or set(core_regions) | set(sub_regions) != expected
            or len(core_regions)+len(sub_regions) != len(expected)):
        raise ValueError("Partition must cover each region exactly once")
    if len(set(retained_dofs)) != len(retained_dofs) or any(type(d) is not int or not 0 <= d <= 6 for d in retained_dofs):
        raise ValueError("Retained DOFs must be unique valid integer DOFs")
    sub = [r for r in fixture["regions"] if r["id"] in sub_regions]
    core = [r for r in fixture["regions"] if r["id"] in core_regions]
    required = {fixture["fixed_dof"], fixture["loaded_dof"]}
    for region in core:
        required.update(region["dofs"])
    for block in components(sub):
        required.update([block[0]["dofs"][0], block[-1]["dofs"][1]])
    errors, results, condensed = [], [], []
    for block in components(sub):
        ids = sorted({d for r in block for d in r["dofs"]})
        matrix = np.zeros((len(ids), len(ids)))
        for region in block:
            a, b = (ids.index(d) for d in region["dofs"])
            matrix[np.ix_([a, b], [a, b])] += region["stiffness_N_mm"] * np.array([[1., -1.], [-1., 1.]])
        keep = [i for i, d in enumerate(ids) if d in retained_dofs]
        interior = [i for i, d in enumerate(ids) if d not in retained_dofs]
        if not keep:
            raise ValueError("Substructure block needs retained boundary DOFs")
        reduced = matrix[np.ix_(keep, keep)]
        if interior:
            reduced = reduced - matrix[np.ix_(keep, interior)] @ np.linalg.solve(
                matrix[np.ix_(interior, interior)], matrix[np.ix_(interior, keep)])
        condensed.append(dict(dofs=[ids[i] for i in keep], stiffness_N_mm=reduced.tolist(),
                              eliminated_dofs=[ids[i] for i in interior]))
    for force in fixture["load_envelope_N"]:
        full = reduced_displacement = 0.
        for region in fixture["regions"]:
            linear = force / region["stiffness_N_mm"]
            exact = linear
            if region["law"] == "bilinear" and force > region["transition_force_N"]:
                transition = region["transition_force_N"]
                exact = transition/region["stiffness_N_mm"] + (force-transition)/region["post_stiffness_N_mm"]
            full += exact
            reduced_displacement += linear if region["id"] in sub_regions else exact
        error = abs(full-reduced_displacement)/abs(full)
        errors.append(error)
        results.append(dict(force_N=force, full_tip_U_mm=full, reduced_tip_U_mm=reduced_displacement,
                            relative_tip_error=error))
    return dict(tier="mechanics-fixture", experiment="linear-Schur-complement-plus-series-bilinear-reference",
        missing_required_dofs=sorted(required-set(retained_dofs)),
        nonlinear_condensed=[r["id"] for r in sub if r["law"] != "linear"],
        eliminated_dofs=sorted({d for r in condensed for d in r["eliminated_dofs"]}),
        condensed_blocks=condensed, load_results=results, relative_tip_error=max(errors))


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
