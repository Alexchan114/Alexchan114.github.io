# MechAgent Lab

Local archive: V3. Public-facing title has no version suffix.

Reading editions: publication/mechagent_lab_zh.pdf and mechagent_lab_en.pdf.

Claude Code: DeepSeek deepseek-v4-flash, existing CCS Anthropic route. Codex CLI: gpt-6.1-sol, existing ChatGPT login. Native model internals are not inferred. No purchases; actual invoices unknown.

Offline: python -m unittest discover -s mechanics_benchmark/tests -v

Native local startup mock: python -m mechanics_benchmark.native_probe

Frozen campaign: python -m mechanics_benchmark.native_suite remaining

Original absolute paths in native_suite.py describe the author environment. Set your own OUT/PYTHON/REFERENCE/SOLVER_ROOT and exact credential routes before a NEW registration. Never overwrite an executed registry. Original commercial software/MCP/credentials are not bundled.

All retained attempts, including nine adapter-invalid startup records, are in pilot/. Complete observable event appendices: documentation/QUERY_OUTPUTS_ZH.md and QUERY_OUTPUTS_EN.md. Hidden native prompts/computation are not reconstructed.

Every figure: figures/lab_figures.py + figure_data.json + qa/*_tavotto_receipt.json. Final published figures come from Tavotto exports.

Only S04 executes actual Abaqus. Seven other tasks are reduced physics/evidence fixtures. No industrial model or APP is changed. Different native models/routes/budgets prevent causal rankings.