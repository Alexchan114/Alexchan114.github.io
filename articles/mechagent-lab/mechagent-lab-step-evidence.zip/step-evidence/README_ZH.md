# 逐步证据档案

从输入、决策和工具调用，到分区、求解日志、数值表格和真实云图，逐项追溯。全部 25 条保留记录均可阅读，包括启动失败。

Scoring unchanged. No inference or analysis rerun.

| Attempt | Status | Events |
|---|---|---|
| [claude-code-S01-a1](public/attempts/claude-code-S01-a1/index.html) | adapter_invalid | 7 |
| [claude-code-S01-a2](public/attempts/claude-code-S01-a2/index.html) | adapter_invalid | 7 |
| [claude-code-S01-a3](public/attempts/claude-code-S01-a3/index.html) | passed | 48 |
| [claude-code-S02-a1](public/attempts/claude-code-S02-a1/index.html) | passed | 52 |
| [claude-code-S03-a1](public/attempts/claude-code-S03-a1/index.html) | budget_exhausted | 65 |
| [claude-code-S04-a1](public/attempts/claude-code-S04-a1/index.html) | passed | 101 |
| [claude-code-S05-a1](public/attempts/claude-code-S05-a1/index.html) | failed | 55 |
| [claude-code-S06-a1](public/attempts/claude-code-S06-a1/index.html) | passed | 38 |
| [claude-code-S07-a1](public/attempts/claude-code-S07-a1/index.html) | protocol_ambiguity | 121 |
| [claude-code-S08-a1](public/attempts/claude-code-S08-a1/index.html) | passed | 43 |
| [codex-native-S01-a1](public/attempts/codex-native-S01-a1/index.html) | passed | 34 |
| [codex-native-S02-a1](public/attempts/codex-native-S02-a1/index.html) | adapter_invalid | 6 |
| [codex-native-S02-a2](public/attempts/codex-native-S02-a2/index.html) | passed | 22 |
| [codex-native-S03-a1](public/attempts/codex-native-S03-a1/index.html) | adapter_invalid | 6 |
| [codex-native-S03-a2](public/attempts/codex-native-S03-a2/index.html) | passed | 28 |
| [codex-native-S04-a1](public/attempts/codex-native-S04-a1/index.html) | adapter_invalid | 6 |
| [codex-native-S04-a2](public/attempts/codex-native-S04-a2/index.html) | environment_or_incomplete | 36 |
| [codex-native-S05-a1](public/attempts/codex-native-S05-a1/index.html) | adapter_invalid | 6 |
| [codex-native-S05-a2](public/attempts/codex-native-S05-a2/index.html) | passed | 35 |
| [codex-native-S06-a1](public/attempts/codex-native-S06-a1/index.html) | adapter_invalid | 6 |
| [codex-native-S06-a2](public/attempts/codex-native-S06-a2/index.html) | passed | 22 |
| [codex-native-S07-a1](public/attempts/codex-native-S07-a1/index.html) | adapter_invalid | 6 |
| [codex-native-S07-a2](public/attempts/codex-native-S07-a2/index.html) | passed | 27 |
| [codex-native-S08-a1](public/attempts/codex-native-S08-a1/index.html) | adapter_invalid | 6 |
| [codex-native-S08-a2](public/attempts/codex-native-S08-a2/index.html) | passed | 22 |