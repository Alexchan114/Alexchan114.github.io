"""Verify additive numerical/image provenance without rerunning or changing grades."""
import csv
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
from urllib.parse import unquote, urlsplit
import zipfile

from .lab_evidence import EVIDENCE, PUBLIC, integrity, save, sha


def rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.paths = []

    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in ('href', 'src'):
                self.paths.append(value)


def main():
    originals = integrity()
    broken = []
    for page in PUBLIC.rglob('*.html'):
        links = Links()
        links.feed(page.read_text(encoding='utf-8'))
        for link in links.paths:
            parsed = urlsplit(link)
            if parsed.scheme or link.startswith(('/', '#')) or not parsed.path:
                continue
            target = (page.parent / unquote(parsed.path)).resolve()
            if target.name == 'mechagent-lab-step-evidence.zip':
                target = EVIDENCE / target.name
            if not target.exists():
                broken.append(dict(page=str(page), link=link))
    if broken:
        save(EVIDENCE / 'broken_links.json', broken)
        raise ValueError('Broken evidence links: ' + str(len(broken)))
    catalog = json.loads((PUBLIC / 'postprocess/catalog.json').read_text())
    counts, histories = {}, {}
    for label, case in catalog['cases'].items():
        folder = PUBLIC / 'postprocess' / label
        stress = rows(folder / 'stress_integration_points.csv')
        expected = 384 if label == 'full_reference' else 192
        if len(stress) != expected or any(r['position'] != 'INTEGRATION_POINT' for r in stress):
            raise ValueError('Unexpected stored integration point coverage')
        counts[label] = len(stress)
        for kind in ('stress', 'deformation'):
            if sha(folder / (kind + '.png')) != case[kind + '_sha256']:
                raise ValueError('Original native render bytes changed')
            rendered = json.loads((folder / (kind + '_render.json')).read_text())
            if rendered['rendered_timestep'] != 1 or rendered['metadata']['frame_index'] != 0:
                raise ValueError('Wrong converted final frame selected')
        histories[label] = rows(folder / 'history.csv')
        if len(histories[label]) != 21 or abs(float(histories[label][-1]['tip_mean_U1_mm']) - .12) > 1e-7:
            raise ValueError('Wrong native history endpoint')
    full = histories['full_reference']
    discrepancies = {}
    for label, curve in histories.items():
        if label == 'full_reference':
            continue
        discrepancies[label] = max(abs(float(a['tip_RF1_N']) - float(b['tip_RF1_N'])) for a, b in zip(full, curve))
    archive = EVIDENCE / 'mechagent-lab-step-evidence.zip'
    if archive.exists():
        with zipfile.ZipFile(archive) as z:
            manifest = json.loads(z.read('step-evidence/manifest.json'))
            for path, expected in manifest.items():
                if hashlib.sha256(z.read('step-evidence/' + path)).hexdigest() != expected:
                    raise ValueError('Archive manifest mismatch')
    save(EVIDENCE / 'verification.json', dict(passed=True, original_files_unchanged=len(originals),
        local_links_valid=True, raw_integration_point_rows=counts, history_frames=21,
        max_full_reduced_tip_reaction_difference_N=discrepancies,
        late_codex_comparison='postprocessing diagnostic only; original missing-artifact grade remains unchanged',
        native_render_hashes_match=True, source_frame='ODB Pull frame20 time1; converted dataset frame0',
        scores_changed=False, inference_calls=0, solve_calls=0))
    print((EVIDENCE / 'verification.json').read_text())


if __name__ == '__main__':
    main()
