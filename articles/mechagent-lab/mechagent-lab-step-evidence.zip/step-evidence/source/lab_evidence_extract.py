"""Standalone Abaqus Python: read-only existing ODB to raw IP stress and U/RF CSV."""
import csv
import json
import os
import sys
from odbAccess import openOdb


def main(config_path):
    with open(config_path) as stream:
        config = json.load(stream)
    for case in config['cases']:
        output = case['output_dir']
        if not os.path.isdir(output):
            os.makedirs(output)
        odb = openOdb(case['odb_path'], readOnly=True)
        try:
            step = odb.steps['Pull']
            last = step.frames[-1]
            with open(os.path.join(output, 'stress_integration_points.csv'), 'w', newline='') as stream:
                fields = ['instance', 'element_id', 'integration_point', 'position', 'step', 'frame_index', 'time',
                          'S11_MPa', 'S22_MPa', 'S33_MPa', 'S12_MPa', 'S13_MPa', 'S23_MPa', 'Mises_MPa']
                writer = csv.DictWriter(stream, fieldnames=fields)
                writer.writeheader()
                for value in last.fieldOutputs['S'].values:
                    row = dict(instance=value.instance.name, element_id=value.elementLabel,
                               integration_point=value.integrationPoint, position=str(value.position),
                               step='Pull', frame_index=len(step.frames) - 1, time=last.frameValue,
                               Mises_MPa=float(value.mises))
                    row.update(zip(fields[7:13], map(float, value.data)))
                    writer.writerow(row)
            with open(os.path.join(output, 'nodal_final.csv'), 'w', newline='') as stream:
                writer = csv.writer(stream)
                writer.writerow(['instance', 'node_id', 'U1_mm', 'U2_mm', 'U3_mm', 'U_magnitude_mm'])
                for value in last.fieldOutputs['U'].values:
                    writer.writerow([value.instance.name, value.nodeLabel] + list(value.data) + [float(value.magnitude)])
            with open(os.path.join(output, 'history.csv'), 'w', newline='') as stream:
                writer = csv.writer(stream)
                writer.writerow(['frame_index', 'time', 'tip_mean_U1_mm', 'tip_RF1_N', 'root_RF1_N', 'max_PEEQ'])
                for i, frame in enumerate(step.frames):
                    tip = [v for v in frame.fieldOutputs['U'].values if 109 <= v.nodeLabel <= 117]
                    rf = [v for v in frame.fieldOutputs['RF'].values if 109 <= v.nodeLabel <= 117]
                    root = [v for v in frame.fieldOutputs['RF'].values if 1 <= v.nodeLabel <= 9]
                    if len(tip) != 9 or len(rf) != 9 or len(root) != 9:
                        raise ValueError('Stored endpoint node coverage differs')
                    peeq = frame.fieldOutputs['PEEQ'] if 'PEEQ' in frame.fieldOutputs else None
                    writer.writerow([i, frame.frameValue, sum(v.data[0] for v in tip) / 9,
                        sum(v.data[0] for v in rf), sum(v.data[0] for v in root),
                        max([float(v.data) for v in peeq.values] or [0]) if peeq else None])
            with open(os.path.join(output, 'extraction.json'), 'w') as stream:
                json.dump(dict(source_odb=case['odb_path'], read_only=True, step='Pull',
                    frame_index=len(step.frames) - 1, time=last.frameValue,
                    stress_rows=len(last.fieldOutputs['S'].values), field='S', position='INTEGRATION_POINT',
                    stress_unit='MPa', length_unit='mm', force_unit='N',
                    averaging='none; original stored integration-point tensors and Mises invariant',
                    substructure_recovery=False, status='extracted'), stream, indent=2)
        finally:
            odb.close()


if __name__ == '__main__':
    main(sys.argv[1])
