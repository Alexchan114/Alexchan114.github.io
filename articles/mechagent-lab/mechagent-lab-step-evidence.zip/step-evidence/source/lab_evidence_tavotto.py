"""Use actual Tavotto execution/registration/export for evidence panels."""
import argparse
import json
from pathlib import Path
import shutil
import urllib.request
from .lab_evidence import EVIDENCE, PUBLIC, save, read, sha


def prepare():
    figures = EVIDENCE / 'figures'
    figures.mkdir(exist_ok=True)
    shutil.copy2(Path(__file__).with_name('lab_evidence_figures.py'), figures / 'lab_evidence_figures.py')
    shutil.copy2(PUBLIC / 'attempts/claude-code-S04-a1/partition.json', figures / 'partition.json')
    for label in ('full_reference', 'claude_reduced', 'codex_late_reduced'):
        dest = figures / 'raw' / label
        dest.mkdir(parents=True, exist_ok=True)
        for kind in ('stress', 'deformation'):
            shutil.copy2(PUBLIC / 'postprocess' / label / (kind + '.png'), dest / (kind + '.png'))


def export(port):
    session = Path.home() / 'AppData/Local/Tavotto/session' / ('port-' + str(port) + '.json')
    secret = read(session)['secret']
    def call(path, payload):
        request = urllib.request.Request('http://127.0.0.1:' + str(port) + path,
            data=json.dumps(payload).encode(), headers={'X-Tavotto-Auth': secret, 'Content-Type': 'application/json'})
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request, timeout=240) as response:
            return json.load(response)
    probe = call('/api/registry/probe', dict(script='lab_evidence_figures.py', cost='medium'))
    save(EVIDENCE / 'tavotto_probe.json', probe)
    if not probe.get('registered'):
        raise ValueError('Evidence script did not register')
    destination = PUBLIC / 'figures'
    destination.mkdir(exist_ok=True)
    for stem in ('partition', 'stress', 'deformation'):
        descriptor = next(d for d in probe['descriptors'] if d['stem'] == stem)
        width, height = descriptor['size_mm']
        receipt = call('/api/export', dict(scope='canvas', filename=stem, formats=['pdf', 'png'], ppi=180,
            background='white', overwrite='replace', canvas=dict(page_w_mm=width, page_h_mm=height,
            objects=[dict(type='panel', id=descriptor['asset_id'], x_mm=0, y_mm=0, w_mm=width, h_mm=height)])))
        save(destination / (stem + '_tavotto_receipt.json'), receipt)
        for suffix in ('.pdf', '.png'):
            source = EVIDENCE / 'figures/tavottofile/export' / (stem + suffix)
            shutil.copy2(source, destination / source.name)
        save(destination / (stem + '_provenance.json'), dict(source_script='lab_evidence_figures.py',
            source_sha256=sha(Path(__file__).with_name('lab_evidence_figures.py')),
            source='actual INP membership' if stem == 'partition' else 'unaltered ParaView renders of existing ODB fields',
            native_data_catalog='../postprocess/catalog.json', exported_by='Tavotto', png_sha256=sha(destination / (stem + '.png'))))
        print('Tavotto exported ' + stem, flush=True)
    shutil.copy2(Path(__file__).with_name('lab_evidence_figures.py'), destination / 'lab_evidence_figures.py')
    shutil.copy2(EVIDENCE / 'figures/partition.json', destination / 'partition.json')
    shutil.copytree(EVIDENCE / 'figures/raw', destination / 'raw', dirs_exist_ok=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'export'])
    parser.add_argument('--port', type=int, default=26906)
    args = parser.parse_args()
    prepare() if args.command == 'prepare' else export(args.port)
