"""Standalone pvpython: batch genuine contours through the installed renderer."""
import json
from pathlib import Path
import runpy
import sys


def main(path):
    config = json.loads(Path(path).read_text(encoding='utf-8'))
    module = runpy.run_path(config['renderer_template'], run_name='evidence_renderer')
    results = {}
    for case in config['renders']:
        output = Path(case['output_dir'])
        output.mkdir(parents=True, exist_ok=True)
        result = module['main'](dict(operation='pv_render', arguments=case['request']), output)
        (output / 'render.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
        results[case['label']] = result
        module['pv'].ResetSession()
    Path(config['output_json']).write_text(json.dumps(results, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main(sys.argv[1])
