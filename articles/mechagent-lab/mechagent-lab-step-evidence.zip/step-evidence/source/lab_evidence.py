"""Additive, read-only trial collector. Never executes an agent or solver."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import html
import json
from pathlib import Path
import shutil
import zipfile

from .lab_delivery import OUT, ROOT, events, public_text, read, secret_values

EVIDENCE = OUT / 'step_evidence'
PUBLIC = EVIDENCE / 'public'
SOLIDS = Path('D:/kimi/benchmark_public/v03_native_20261105')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def table(path, rows, fields=None):
    rows = list(rows)
    if not fields:
        fields = list(dict.fromkeys(k for row in rows for k in row))
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with Path(path).open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or ['no_recorded_rows'])
        writer.writeheader()
        writer.writerows(rows)


def leaves(value, path='$'):
    """Lossless scalar-leaf CSV, including empty containers and JSON types."""
    if isinstance(value, dict) and value:
        for key, child in value.items():
            yield from leaves(child, path + '[' + json.dumps(key, ensure_ascii=False) + ']')
    elif isinstance(value, list) and value:
        for i, child in enumerate(value):
            yield from leaves(child, '{}[{}]'.format(path, i))
    else:
        yield dict(json_path=path, value_json=json.dumps(value, ensure_ascii=False, allow_nan=False))


def integrity():
    paths = [p for p in (OUT / 'pilot').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    for directory in ('frozen_source', 'amendment_frozen_source', 'native_extension_frozen_source', 'codex_transport_frozen_source'):
        paths += [p for p in (OUT / directory).rglob('*') if p.is_file()]
    paths += [OUT / name for name in ('summary.json', 'summary.csv', 'preregistration.json',
        'amendment_registration.json', 'native_extension_registration.json', 'codex_transport_registration.json',
        'mechagent-lab-source-evidence.zip')]
    paths += list((OUT / 'publication').glob('mechagent_lab_*.pdf'))
    current = {p.relative_to(OUT).as_posix(): sha(p) for p in sorted(paths)}
    target = EVIDENCE / 'original_integrity.json'
    if target.exists() and read(target) != current:
        raise ValueError('Original trial/release bytes changed; do not overwrite the evidence baseline')
    save(target, current)
    return current


def partition(full_path, generation_path):
    def mesh(path):
        nodes, elements, active = {}, {}, ''
        for raw in Path(path).read_text(encoding='utf-8').splitlines():
            line = raw.strip()
            if line.startswith('**') or not line:
                continue
            if line.startswith('*'):
                active = line.split(',')[0].upper()
                continue
            fields = [x.strip() for x in line.split(',') if x.strip()]
            if active == '*NODE':
                nodes[int(fields[0])] = list(map(float, fields[1:4]))
            elif active == '*ELEMENT':
                elements[int(fields[0])] = list(map(int, fields[1:]))
        return nodes, elements
    nodes, elements = mesh(full_path)
    sub_nodes, sub_elements = mesh(generation_path)
    core = {e: conn for e, conn in elements.items() if e not in sub_elements}
    core_nodes = {n for conn in core.values() for n in conn}
    interface = sorted(set(sub_nodes) & core_nodes)
    root = sorted(n for n in sub_nodes if nodes[n][0] == min(v[0] for v in nodes.values()))
    retained = sorted(set(root) | set(interface))
    return dict(nodes={str(k): v for k, v in nodes.items()}, elements={str(k): v for k, v in elements.items()},
        sub_elements=sorted(sub_elements), core_elements=sorted(core), sub_nodes=sorted(sub_nodes),
        core_nodes=sorted(core_nodes), interface_nodes=interface, root_nodes=root, retained_nodes=retained,
        eliminated_nodes=sorted(set(sub_nodes) - set(retained)),
        eliminated_translation_dofs=3 * len(set(sub_nodes) - set(retained)),
        cut_mm=max(v[0] for v in sub_nodes.values()),
        source_hashes={full_path.name: sha(full_path), generation_path.name: sha(generation_path)},
        provenance='Membership parsed from existing public full/generation INP, not a new FE solve')


def export_artifact(path, destination):
    data = read(path)
    save(destination / (path.stem + '.json'), data)
    table(destination / (path.stem + '.csv'), leaves(data))
    result = data.get('result', {})
    if 'forces_N' in result:
        table(destination / (path.stem + '_contacts.csv'),
              [dict(pair_id=i + 1, normal_force_N=v) for i, v in enumerate(result['forces_N'])])
    for key in ('uniform', 'amplitudes'):
        if key in result and result[key] and isinstance(result[key][0], list):
            matrix = result[key]
            table(destination / (path.stem + '_' + key + '.csv'),
                [dict(sample=i + 1, **{'variable_{:02d}'.format(j + 1): v for j, v in enumerate(row)})
                 for i, row in enumerate(matrix)])
    return dict(id=path.stem, parameters=data.get('parameters'), files=[p.name for p in sorted(destination.glob(path.stem + '*'))])


def collect():
    integrity()
    private, records = [], []
    for row in read(OUT / 'summary.json')['rows']:
        name = row['attempt']
        source, target = OUT / 'pilot' / name, PUBLIC / 'attempts' / name
        target.mkdir(parents=True, exist_ok=True)
        copied = []
        for filename in ('task.json', 'query.json', 'run.json', 'submission.json', 'evaluation.json',
                         'native_result.json', 'native_console.json', 'broker_state.json', 'active_tools.json'):
            p = source / filename
            if p.exists():
                (target / filename).write_text(public_text(p.read_text(encoding='utf-8')), encoding='utf-8')
                copied.append(filename)
        timeline = events(source)
        (target / 'timeline.jsonl').write_text(''.join(public_text(json.dumps(e, ensure_ascii=False)) + '\n' for e in timeline), encoding='utf-8')
        table(target / 'timeline.csv', [dict(sequence=i + 1, utc=e['utc'], stream=e['source_stream'],
            stream_index=e['index'], kind=e['kind'], output_json=public_text(json.dumps(e, ensure_ascii=False)))
            for i, e in enumerate(timeline)])
        artifact_dir = target / 'artifacts'
        artifact_dir.mkdir(exist_ok=True)
        artifacts = [export_artifact(p, artifact_dir) for p in sorted((source / 'artifacts').glob('*.json'))]
        native = SOLIDS / name
        partition_record = None
        if (native / 'generation.inp').exists():
            partition_record = partition(native / 'full.inp', native / 'generation.inp')
            save(target / 'partition.json', partition_record)
            table(target / 'partition_nodes.csv', [dict(node_id=n, x_mm=xyz[0], y_mm=xyz[1], z_mm=xyz[2],
                in_SUB=n in partition_record['sub_nodes'], in_CORE=n in partition_record['core_nodes'],
                interface=n in partition_record['interface_nodes'], retained=n in partition_record['retained_nodes'])
                for n, xyz in ((int(k), v) for k, v in partition_record['nodes'].items())])
            table(target / 'partition_elements.csv', [dict(element_id=int(e), region='SUB' if int(e) in partition_record['sub_elements'] else 'CORE',
                connectivity=' '.join(map(str, conn))) for e, conn in partition_record['elements'].items()])
            for filename in ('full.inp', 'generation.inp', 'reduced.inp', 'curves.json', 'progress.json',
                             'validation.json', 'candidate_result.json', 'mcp_trace.jsonl', 'extract_reference.py'):
                p = native / filename
                if p.exists():
                    destination = target / 'solver' / filename
                    destination.parent.mkdir(exist_ok=True)
                    destination.write_text(public_text(p.read_text(encoding='utf-8')), encoding='utf-8')
            if (native / 'curves.json').exists():
                curves = read(native / 'curves.json')
                for kind, points in curves.items():
                    table(target / 'solver' / (kind + '_curve.csv'), points)
            progress = read(native / 'progress.json')
            for stage, record in progress.items():
                directory = Path(record['submitted']['job_directory'])
                for p in sorted(directory.rglob('*')):
                    if p.is_file() and p.suffix.lower() in ('.odb', '.sim', '.sup', '.sta', '.msg', '.dat', '.log', '.inp', '.json', '.py'):
                        private.append(dict(attempt=name, stage=stage, path=str(p), bytes=p.stat().st_size, sha256=sha(p)))
                        if p.suffix.lower() in ('.sta', '.msg', '.dat', '.log'):
                            dest = target / 'solver' / 'logs' / stage / p.relative_to(directory)
                            dest.parent.mkdir(parents=True, exist_ok=True)
                            dest.write_text(public_text(p.read_text(encoding='utf-8', errors='replace')), encoding='utf-8')
        manifest = dict(**row, observation='recorded events only; no hidden reasoning reconstructed',
            timeline_events=len(timeline), source_files=copied, artifacts=artifacts,
            solver_scope='actual Abaqus' if partition_record else 'no native solver artifact for this attempt',
            partition=bool(partition_record), late_host_supplement=name == 'codex-native-S04-a2',
            scoring_changed=False, inference_repeated=False, analysis_repeated=False)
        save(target / 'manifest.json', manifest)
        records.append(manifest)
    save(EVIDENCE / 'local_native_files.json', private)
    save(PUBLIC / 'catalog.json', dict(created_utc=datetime.now(timezone.utc).isoformat(), records=records,
        original_evaluations_unchanged=True, large_native_files='local only; see local_native_files.json',
        notice='Seven reduced-physics/evidence tasks; only S04 actual Abaqus. Late host output is not an agent pass.'))
    table(PUBLIC / 'attempts.csv', [{k: r[k] for k in ('attempt', 'task', 'classification', 'timeline_events', 'partition', 'late_host_supplement')} for r in records])
    print('Collected {} attempts / {} observable events / {} original artifacts'.format(
        len(records), sum(r['timeline_events'] for r in records), sum(len(r['artifacts']) for r in records)))


STYLE = '''body{margin:0;color:#233b49;background:#f7f5ef;font:16px/1.75 Georgia,"Noto Serif CJK SC",serif}
main{max-width:1060px;margin:auto;padding:46px 24px}h1{font-size:clamp(32px,5vw,54px);line-height:1.15}h2{margin-top:2em}
a{color:#087c79}small,.muted{color:#657780}nav{display:flex;gap:20px;flex-wrap:wrap}.tag{font:12px/1.4 monospace;color:#a34d2e}
.table{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}td,th{padding:10px;text-align:left;border-bottom:1px solid #d7dfdc}
details{background:#fffdf8;border:1px solid #d7dfdc;margin:10px 0;padding:12px 16px}summary{cursor:pointer;overflow-wrap:anywhere}
pre{overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.55 Consolas,monospace}img{width:100%;height:auto}
figure{margin:28px 0}figcaption{font-size:14px;color:#657780}ul{padding-left:22px}code{overflow-wrap:anywhere}
.lead{border-left:4px solid #0d7f7b;padding:6px 20px;background:#eef3ee}.eyebrow{letter-spacing:.15em;font:12px monospace}'''


def page(title, body, lang):
    return '<!doctype html><html lang="' + ('zh-CN' if lang == 'zh' else 'en') + '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + html.escape(title) + '</title><style>' + STYLE + '</style></head><body><main>' + body + '</main></body></html>'


def link(path, label=None):
    return '<a href="' + html.escape(path, quote=True) + '">' + html.escape(label or path) + '</a>'


def indexes():
    catalog = read(PUBLIC / 'catalog.json')
    for lang in ('zh', 'en'):
        zh = lang == 'zh'
        title = '逐步证据档案' if zh else 'Step-by-Step Evidence'
        other = 'index.en.html' if zh else 'index.html'
        body = '<nav>' + link('/post/2026/11/05/mechagent-lab/', 'MechAgent Lab') + link(other, 'English' if zh else '中文') + link('../mechagent-lab-step-evidence.zip', 'ZIP') + '</nav>'
        body += '<p class="eyebrow">MECHANICS / OBSERVATIONS / PROVENANCE</p><h1>' + title + '</h1>'
        intro = ('从输入、决策和工具调用，到分区、求解日志、数值表格和真实云图，逐项追溯。全部 25 条保留记录均可阅读，包括启动失败。' if zh else
                 'Follow each recorded input, decision and tool call through partitions, solver logs, numerical tables and genuine contours. All 25 retained records include startup failures.')
        body += '<p class="lead">' + intro + '</p>'
        body += '<p>' + ('此次只读后处理，不重跑、不改分数。七题为简化力学或证据题，仅 S04 使用真实 Abaqus。推理依据以 Agent 实际可见输出为准，不重建隐藏思维。' if zh else
            'Read-only postprocessing: no inference or analysis reruns and no score changes. Seven tasks use reduced physics/evidence; only S04 uses actual Abaqus. Decision explanations are observable outputs, not reconstructed hidden reasoning.') + '</p>'
        captions = [('partition', '子结构分区：按实际 INP 标出凝聚区、保留实体及接口。', 'Substructure partition from actual INP memberships.'),
            ('stress', '真实 ODB 的最终帧 Mises 应力。完整模型为参考；降阶模型只显示未凝聚的实体。', 'Final-frame Mises stress from genuine ODB. Full model is reference; reduced model shows only retained solids.'),
            ('deformation', '真实 ODB 位移模量，变形比例 1；不是接触力云图。', 'Stored displacement magnitude, deformation scale 1; not a contact-force contour.')]
        for stem, cn, en in captions:
            if (PUBLIC / 'figures' / (stem + '.png')).exists():
                body += '<figure><a href="figures/' + stem + '.png"><img src="figures/' + stem + '.png" alt="' + html.escape(cn if zh else en) + '"></a><figcaption>' + (cn if zh else en) + '</figcaption></figure>'
        body += '<p>' + ('子结构使用 RECOVERY MATRIX=NO，内部应力未恢复，不以空白补零。Codex 超时后完成的云图仅为事后主机证据，不改为通过。原始 ODB/SIM/SUP 留在本地，公开包含图像、状态、数据和哈希。' if zh else
            'RECOVERY MATRIX=NO: internal SUB stress is unavailable and is not zero-filled. Late Codex contours are post-trial host evidence, not a pass. ODB/SIM/SUP stay local; the public bundle includes images, states, data and hashes.') + '</p>'
        body += '<h2>' + ('所有案例' if zh else 'Every Retained Attempt') + '</h2><div class="table"><table><tr><th>Attempt</th><th>Status</th><th>Events</th><th>Artifacts</th></tr>'
        for record in catalog['records']:
            name = record['attempt']
            filename = 'index.html' if zh else 'index.en.html'
            body += '<tr><td>' + link('attempts/' + name + '/' + filename, name) + '</td><td>' + record['classification'] + '</td><td>' + str(record['timeline_events']) + '</td><td>' + str(len(record['artifacts'])) + '</td></tr>'
            detail = '<nav>' + link('../../' + filename, title) + link('index.en.html' if zh else 'index.html', 'English' if zh else '中文') + '</nav><h1>' + name + '</h1><p class="tag">' + record['classification'] + '</p>'
            detail += '<p>' + ('按 UTC 合并；保留各原始流的索引。该页面不更改评分。' if zh else 'Merged by UTC, retaining stream-local indices. This page does not change scoring.') + '</p>'
            detail += '<p>' + ' · '.join(link(p) for p in record['source_files'] + ['manifest.json', 'timeline.csv', 'timeline.jsonl']) + '</p>'
            if record['partition']:
                detail += '<h2>' + ('分区与求解产物' if zh else 'Partition and Solver Outputs') + '</h2><p>' + ' · '.join(link(p) for p in ('partition.json', 'partition_nodes.csv', 'partition_elements.csv')) + '</p>'
                post_label = 'codex_late_reduced' if name == 'codex-native-S04-a2' else 'claude_reduced'
                prefix = '../../postprocess/' + post_label + '/'
                detail += '<p>' + ('只有保留实体区域具有降阶应力；完整参考云图见总索引。' if zh else 'Reduced stress exists only in retained solids; see the main gallery for full-reference contours.') + '</p>'
                if record['late_host_supplement']:
                    detail += '<p class="lead">' + ('以下为 Agent 超时后取得的主机补充证据，不是当时交付的结果，不改变原评分。' if zh else 'The following is host evidence obtained after the agent deadline, not an on-time delivered artifact. The original score is unchanged.') + '</p>'
                detail += '<p>' + ' · '.join(link(prefix + p, p) for p in ('history.csv', 'stress_integration_points.csv', 'nodal_final.csv', 'extraction.json', 'stress_render.json', 'deformation_render.json')) + '</p>'
                for kind in ('stress', 'deformation'):
                    detail += '<details><summary>' + ('应力云图' if kind == 'stress' and zh else '位移云图' if zh else kind.title() + ' contour') + '</summary><img src="' + prefix + kind + '.png" alt="' + kind + '"></details>'
                detail += '<ul>'
                for p in sorted((PUBLIC / 'attempts' / name / 'solver').rglob('*')):
                    if p.is_file():
                        rel = p.relative_to(PUBLIC / 'attempts' / name).as_posix()
                        detail += '<li>' + link(rel) + '</li>'
                detail += '</ul>'
            detail += '<h2>' + ('数值产物' if zh else 'Numerical Artifacts') + '</h2><ul>'
            for artifact in record['artifacts']:
                detail += '<li>' + artifact['id'] + ': ' + ' · '.join(link('artifacts/' + p, p) for p in artifact['files']) + '</li>'
            detail += '</ul><h2>' + ('逐步输入与输出' if zh else 'Step Inputs and Outputs') + '</h2>'
            if not record['artifacts']:
                detail += '<p>' + ('本条记录没有成功返回的原始实验产物；缺失不补造，具体原因见下方轨迹。' if zh else 'No successful original experiment artifact was returned for this record. Missing output is not fabricated; see the trace below.') + '</p>'
            for i, event in enumerate(events(OUT / 'pilot' / name)):
                heading = '{} / {} / {} #{} / {}'.format(i + 1, event['utc'], event['source_stream'], event['index'], event['kind'])
                detail += '<details><summary>' + html.escape(heading) + '</summary><pre>' + html.escape(public_text(json.dumps(event, ensure_ascii=False, indent=2))) + '</pre></details>'
            (PUBLIC / 'attempts' / name / filename).write_text(page(name, detail, lang), encoding='utf-8')
        body += '</table></div><p>' + ' · '.join(link(p) for p in ('catalog.json', 'attempts.csv', 'postprocess/catalog.json', 'postprocess/mcp_trace.jsonl')) + '</p>'
        (PUBLIC / ('index.html' if zh else 'index.en.html')).write_text(page('MechAgent Lab | ' + title, body, lang), encoding='utf-8')
        lines = ['# ' + title, '', intro, '', 'Scoring unchanged. No inference or analysis rerun.', '', '| Attempt | Status | Events |', '|---|---|---|']
        lines += ['| [{}](public/attempts/{}/{}) | {} | {} |'.format(r['attempt'], r['attempt'], 'index.html' if zh else 'index.en.html', r['classification'], r['timeline_events']) for r in catalog['records']]
        (EVIDENCE / ('README_' + lang.upper() + '.md')).write_text('\n'.join(lines), encoding='utf-8')


def package():
    integrity()
    entries = {'public/' + p.relative_to(PUBLIC).as_posix(): p for p in PUBLIC.rglob('*') if p.is_file()}
    for p in Path(__file__).parent.glob('lab_evidence*.py'):
        entries['source/' + p.name] = p
    for p in EVIDENCE.glob('README_*.md'):
        entries[p.name] = p
    known = secret_values()
    hashes = {}
    archive = EVIDENCE / 'mechagent-lab-step-evidence.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, path in sorted(entries.items()):
            data = path.read_bytes()
            if any(key in data for key in known):
                raise ValueError('Credential scan blocked ' + name)
            hashes[name] = hashlib.sha256(data).hexdigest()
            z.writestr('step-evidence/' + name, data)
        z.writestr('step-evidence/manifest.json', json.dumps(hashes, indent=2))
    receipt = dict(files=len(entries), bytes=archive.stat().st_size, sha256=sha(archive),
        original_files_verified=len(integrity()), secrets_included=False, native_binaries_included=False,
        original_scores_unchanged=True, analysis_rerun=False)
    save(EVIDENCE / 'package_receipt.json', receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['collect', 'indexes', 'package', 'verify'])
    args = parser.parse_args()
    {'collect': collect, 'indexes': indexes, 'package': package, 'verify': integrity}[args.command]()
