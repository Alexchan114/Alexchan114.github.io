"""Read-only MCP postprocessing of existing outputs; no solve tools permitted."""
import asyncio
from contextlib import AsyncExitStack
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from .lab_evidence import EVIDENCE, PUBLIC, read, save, sha

WORK = Path('D:/kimi/benchmark_public/step_evidence_20261106')
MCP_ROOT = WORK / 'mcp'
CASES = {
    'full_reference': ('abaqus_5d1d0ab8c1f34371', 'Independent full reference; not an agent-generated full solve'),
    'claude_reduced': ('abaqus_eff56b44421446e6', 'Completed within recorded successful Claude S04 attempt'),
    'codex_late_reduced': ('abaqus_122454d847e74e6e', 'Late host supplement only; not available to agent by deadline; score unchanged'),
}


def prepare():
    MCP_ROOT.mkdir(parents=True, exist_ok=True)
    config = read(Path('D:/kimi/cae-mcp/config/settings.json'))
    config['project_root'] = str(MCP_ROOT)
    save(MCP_ROOT / 'config/settings.json', config)


async def main():
    WORK.mkdir(parents=True, exist_ok=True)
    destination = PUBLIC / 'postprocess'
    destination.mkdir(parents=True, exist_ok=True)
    state_file = EVIDENCE / 'postprocess_state.json'
    state = read(state_file) if state_file.exists() else {}
    trace = destination / 'mcp_trace.jsonl'
    async with AsyncExitStack() as stack:
        sessions = {}
        for domain in ('source', 'abaqus', 'paraview'):
            root = 'D:/kimi/cae-mcp' if domain == 'source' else str(MCP_ROOT)
            transport = await stack.enter_async_context(stdio_client(StdioServerParameters(command=sys.executable,
                args=['-m', 'cae_mcp', 'serve', 'abaqus' if domain == 'source' else domain], cwd='D:/kimi/cae-mcp',
                env=dict(os.environ, CAE_MCP_ROOT=root,
                         PYTHONPATH='D:/kimi/cae-mcp/src' + os.pathsep + os.environ.get('PYTHONPATH', '')))))
            sessions[domain] = await stack.enter_async_context(ClientSession(*transport))
            await sessions[domain].initialize()

        async def call(domain, name, arguments):
            if name not in {'abaqus_job_status', 'abaqus_job_artifacts', 'abaqus_inspect_odb', 'abaqus_export_odb',
                            'abaqus_run_python_script', 'paraview_job_status', 'paraview_job_artifacts',
                            'paraview_render', 'paraview_inspect_data', 'paraview_run_python_script'}:
                raise ValueError('Not a read-only postprocess capability: ' + name)
            def log(event, **values):
                with trace.open('a', encoding='utf-8') as stream:
                    stream.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(), event=event,
                        tool=name, domain=domain, **values), ensure_ascii=False) + '\n')
            log('request', arguments=arguments)
            result = await sessions[domain].call_tool(name, arguments, read_timeout_seconds=__import__('datetime').timedelta(seconds=600))
            data = result.structuredContent
            if data is None:
                raw = next(c.text for c in result.content if c.type == 'text')
                try:
                    data = json.loads(raw)
                except ValueError:
                    data = dict(error=raw)
            log('response', result=data, is_error=bool(result.isError))
            if result.isError:
                raise RuntimeError(str(data))
            return data

        async def stage(label, domain, tool, arguments):
            if label not in state:
                state[label] = dict(submitted=await call(domain, tool, arguments))
                save(state_file, state)
            job_id = state[label]['submitted']['job_id']
            for _ in range(240):
                status = await call(domain, domain + '_job_status', dict(job_id=job_id))
                if status['status'] == 'succeeded':
                    state[label]['state'] = status
                    save(state_file, state)
                    return status['result']
                if status['status'] not in ('queued', 'running'):
                    state[label]['state'] = status
                    save(state_file, state)
                    raise RuntimeError(label + ': ' + str(status))
                await asyncio.sleep(2)
            raise TimeoutError(label)

        catalog = {}
        extract_cases, renders = [], []
        for label, (job, note) in CASES.items():
            actual = await call('source', 'abaqus_job_status', dict(job_id=job))
            if actual['status'] != 'succeeded':
                raise ValueError('Existing solve is not succeeded: ' + job)
            odb = Path(actual['result']['odb_path'])
            info = await call('source', 'abaqus_inspect_odb', dict(odb_path=str(odb)))
            save(destination / label / 'odb_inspection.json', info)
            exported = await stage(label + '_export', 'abaqus', 'abaqus_export_odb', dict(request=dict(
                odb_path=str(odb), steps=['Pull'], frames='last', fields=['U', 'S:MISES', 'PEEQ'],
                position='averaged', averaging_regions='section', averaging_threshold=75,
                encoding='binary', skip_unsupported=True), timeout_seconds=300))
            save(destination / label / 'export.json', exported)
            manifest = read(Path(exported['manifest_path']))
            save(destination / label / 'conversion_manifest.json', manifest)
            vtk_dir = Path(exported['pvd_path']).parent
            shutil.copytree(vtk_dir, destination / label / 'vtk', dirs_exist_ok=True)
            catalog[label] = dict(job_id=job, source_odb_sha256=sha(odb), source_odb_bytes=odb.stat().st_size,
                note=note, step='Pull', frame_index=20, frame_time=1.0,
                contour_stress='S:MISES; MPa; scalar-before-average; section regions; Avg75',
                substructure_recovery=False, inference_repeated=False, analysis_repeated=False)
            extract_cases.append(dict(odb_path=str(odb), output_dir=str(WORK / label)))
            data_path = exported.get('pvd_path') or exported.get('output_path')
            if not data_path:
                candidates = [v for k, v in exported.items() if isinstance(v, str) and v.endswith(('.pvd', '.vtu'))]
                if len(candidates) != 1:
                    raise ValueError('Inspect export result for actual data path: ' + str(exported))
                data_path = candidates[0]
            for kind, array, scale, title in [('stress', 'S_MISES_Avg', 0, 'Mises stress / MPa'),
                                              ('deformation', 'U', 1, '|U| / mm (scale 1)')]:
                if array not in manifest['files'][0]['arrays']:
                    raise ValueError('Required stored/converter field missing: ' + array)
                renders.append(dict(label=label + '_' + kind, output_dir=str(WORK / 'renders' / label / kind), request=dict(
                    data_path=data_path, frame=-1, array_name=array, association='POINTS', component=-1,
                    deformation_scale=scale, width=1600, height=700, representation='Surface With Edges',
                    view='isometric', scalar_label=title)))
        script = WORK / 'extract_fields.py'
        shutil.copy2(Path(__file__).with_name('lab_evidence_extract.py'), script)
        config = WORK / 'extraction_config.json'
        save(config, dict(cases=extract_cases))
        await stage('extract_stored_fields_v2', 'abaqus', 'abaqus_run_python_script', dict(request=dict(
            script_path=str(script), mode='python', arguments=[str(config)]), timeout_seconds=300))
        for label in CASES:
            for path in (WORK / label).iterdir():
                shutil.copy2(path, destination / label / path.name)
        render_script = WORK / 'render_fields.py'
        shutil.copy2(Path(__file__).with_name('lab_evidence_render.py'), render_script)
        template = WORK / 'installed_renderer_snapshot.py'
        shutil.copy2(Path('D:/kimi/cae-mcp/src/cae_mcp/templates/paraview_operation.py'), template)
        render_config = WORK / 'render_config.json'
        save(render_config, dict(renders=renders, renderer_template=str(template), output_json=str(WORK / 'renders.json')))
        await stage('render_batch_v2', 'paraview', 'paraview_run_python_script', dict(request=dict(
            script_path=str(render_script), arguments=[str(render_config)]), timeout_seconds=600))
        rendered = read(WORK / 'renders.json')
        for label in CASES:
            for kind in ('stress', 'deformation'):
                result = rendered[label + '_' + kind]
                shutil.copy2(result['image_path'], destination / label / (kind + '.png'))
                shutil.copy2(result['state_path'], destination / label / (kind + '.pvsm'))
                save(destination / label / (kind + '_render.json'), result)
                catalog[label][kind + '_sha256'] = sha(destination / label / (kind + '.png'))
        save(destination / 'render_config.json', read(render_config))
        shutil.copy2(template, destination / template.name)
        save(destination / 'catalog.json', dict(cases=catalog, read_only=True,
            grades_changed=False, new_analyses=0, native_binaries_published=False))
    print('Completed read-only exports, six original renders and stored-field extraction', flush=True)


if __name__ == '__main__':
    if '--prepare' in sys.argv:
        prepare()
    else:
        asyncio.run(main())
