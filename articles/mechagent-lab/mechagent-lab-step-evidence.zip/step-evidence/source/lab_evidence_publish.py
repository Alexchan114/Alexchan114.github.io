"""Allowlisted additive evidence publication, leaving old bundles unchanged."""
import argparse
import hashlib
import json
import shutil
import subprocess
import time
import httpx
from .lab_evidence import EVIDENCE, PUBLIC, save, sha
from .lab_delivery import SITE, secret_values

PREFIX = 'articles/mechagent-lab'


def prepare():
    static = SITE / 'site-src/static' / PREFIX
    shutil.copytree(PUBLIC, static / 'step-evidence', dirs_exist_ok=True)
    shutil.copy2(EVIDENCE / 'mechagent-lab-step-evidence.zip', static / 'mechagent-lab-step-evidence.zip')
    for lang in ('zh', 'en'):
        suffix = '' if lang == 'zh' else '.en'
        path = SITE / 'site-src/content/post' / ('mechagent-lab' + suffix + '.md')
        text = path.read_text(encoding='utf-8')
        start, end = '<!-- STEP-EVIDENCE-START -->', '<!-- STEP-EVIDENCE-END -->'
        if start in text:
            left, rest = text.split(start, 1)
            text = left + rest.split(end, 1)[1]
        zh = lang == 'zh'
        title = '逐步证据：从分区到真实应力云图' if zh else 'Step Evidence: From Partition to Genuine Stress Contours'
        description = ('新增独立证据档案，收录全部 25 条保留记录的 805 条可观察事件与 38 份数值产物。每个案例均可查看输入、决策输出、工具调用、JSON/CSV 和计算日志；S04 另有分区节点/单元清单、真实 ODB 应力及位移云图。' if zh else
            'An additive archive covers all 25 retained records, 805 observable events and 38 numerical artifacts. Inspect inputs, decision outputs, tool calls, JSON/CSV and solver logs for each attempt; S04 also includes node/element partition memberships and genuine ODB stress/displacement contours.')
        caution = ('仅只读后处理，没有重跑模型或分析，也没有改变原评分。完整模型云图为独立参考；降阶模型仅显示保留实体应力，不恢复子结构内部应力。Codex 的延迟完成结果标作事后主机补充证据，不改判为通过。大体积 ODB/SIM/SUP 文件仅在本地保留。' if zh else
            'Read-only postprocessing only: no model or analysis reruns and no score changes. Full-model contours are independent reference evidence. Reduced contours cover retained solids only; SUB internal stress is not recovered. Late Codex outputs are labeled post-trial host supplements, not a pass. Large ODB/SIM/SUP files remain local.')
        index = 'index.html' if zh else 'index.en.html'
        asset = '/' + PREFIX + '/'
        block = '\n' + start + '\n<h2>' + title + '</h2>\n<p>' + description + '</p>\n<p><a href="' + asset + 'step-evidence/' + index + '">' + ('打开逐步证据档案' if zh else 'Open the step evidence archive') + '</a> · <a href="' + asset + 'mechagent-lab-step-evidence.zip">' + ('下载独立证据包' if zh else 'Download the additive evidence bundle') + '</a></p>\n<figure><a href="' + asset + 'step-evidence/' + index + '"><img src="' + asset + 'step-evidence/figures/stress.png" alt="Genuine full and reduced ODB stress contours" loading="lazy"></a><figcaption>' + caution + '</figcaption></figure>\n' + end + '\n'
        text = text.replace('</article>', block + '</article>')
        path.write_text(text, encoding='utf-8')


def stage():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(SITE), *args]).decode('utf-8').strip()
    if git('remote', 'get-url', 'origin') != 'https://github.com/Alexchan114/Alexchan114.github.io.git':
        raise ValueError('Wrong publication repository')
    existing = git('diff', '--cached', '--name-only').splitlines()
    files = ['.gitattributes', 'site-src/content/post/mechagent-lab.md', 'site-src/content/post/mechagent-lab.en.md',
             'post/2026/11/05/mechagent-lab/index.html', 'en/post/2026/11/05/mechagent-lab/index.html']
    for root in (SITE / PREFIX, SITE / 'site-src/static' / PREFIX):
        files.extend(p.relative_to(SITE).as_posix() for p in (root / 'step-evidence').rglob('*') if p.is_file())
        files.append((root / 'mechagent-lab-step-evidence.zip').relative_to(SITE).as_posix())
    files = sorted(set(files))
    if any(name not in files for name in existing):
        raise ValueError('Other staged work exists')
    secrets = secret_values()
    for name in files:
        if any(secret in (SITE / name).read_bytes() for secret in secrets):
            raise ValueError('Credential scan blocked ' + name)
    # Bound command length on Windows while staging exactly the reviewed list.
    for offset in range(0, len(files), 30):
        git('add', '--', *files[offset:offset + 30])
        git('add', '--renormalize', '--', *files[offset:offset + 30])
    # Native fixed-width solver logs retain their original whitespace.
    git('-c', 'core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol',
        'diff', '--cached', '--check', '--', '.',
        ':(glob,exclude)articles/mechagent-lab/step-evidence/attempts/*/solver/logs/**',
        ':(glob,exclude)site-src/static/articles/mechagent-lab/step-evidence/attempts/*/solver/logs/**')
    staged = git('diff', '--cached', '--name-only').splitlines()
    if any(name not in files for name in staged):
        raise ValueError('Unexpected staged file')
    blobs = dict((line.split('\t', 1)[1], line.split()[1]) for line in git('ls-files', '-s').splitlines())
    for name in staged:
        if '/step-evidence/' in name:
            data = (SITE / name).read_bytes()
            blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            if blobs[name] != blob:
                raise ValueError('Git changed provenance bytes: ' + name)
    save(EVIDENCE / 'publish_manifest.json', dict(files=staged, exact_evidence_bytes_verified=True,
        native_log_whitespace='preserved; fixed-width solver output is excluded from whitespace lint'))
    print('Staged {} allowlisted evidence/article files'.format(len(staged)))


def verify_live():
    base = 'https://alexchan114.github.io'
    expected = EVIDENCE / 'mechagent-lab-step-evidence.zip'
    with httpx.Client(proxy='http://127.0.0.1:12450', trust_env=False, timeout=90, follow_redirects=True) as client:
        for _ in range(30):
            paths = ['/post/2026/11/05/mechagent-lab/', '/en/post/2026/11/05/mechagent-lab/',
                     '/' + PREFIX + '/step-evidence/index.html', '/' + PREFIX + '/step-evidence/index.en.html']
            checks = []
            for path in paths:
                r = client.get(base + path, params=dict(verify=int(time.time())))
                checks.append(dict(url=base + path, status=r.status_code,
                    evidence_link='step-evidence' in r.text or 'claude-code-S04-a1' in r.text))
            response = client.get(base + '/' + PREFIX + '/mechagent-lab-step-evidence.zip', params=dict(verify=int(time.time())))
            match = response.status_code == 200 and hashlib.sha256(response.content).hexdigest() == sha(expected)
            if match and all(r['status'] == 200 and r['evidence_link'] for r in checks):
                receipt = dict(date='2026-11-06', articles=checks, bundle_bytes=len(response.content),
                    bundle_sha256=sha(expected), live_matches_local=True)
                save(EVIDENCE / 'deployment.json', receipt)
                print(json.dumps(receipt, indent=2))
                return
            time.sleep(15)
    raise RuntimeError('Live evidence publication has not yet matched local files')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'stage', 'verify-live'])
    args = parser.parse_args()
    {'prepare': prepare, 'stage': stage, 'verify-live': verify_live}[args.command]()
