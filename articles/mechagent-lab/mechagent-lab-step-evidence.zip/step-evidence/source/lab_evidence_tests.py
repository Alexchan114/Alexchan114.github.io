"""Offline tests for additive authoring only; not part of frozen trial execution."""
import csv
import json
from pathlib import Path
import tempfile
import unittest
from .lab_evidence import leaves, table, partition, integrity, PUBLIC, EVIDENCE
from .native_suite import OUT, hashes


class EvidenceTests(unittest.TestCase):
    def test_leaf_csv_preserves_types_and_empties(self):
        source = {'number': .15, 'bool': False, 'null': None, 'empty': [], 'matrix': [[1, 2], []]}
        rows = list(leaves(source))
        self.assertEqual(len(rows), 7)
        self.assertEqual(json.loads(next(r['value_json'] for r in rows if r['json_path'] == '$["bool"]')), False)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'test.csv'
            table(path, rows)
            with path.open(encoding='utf-8-sig', newline='') as stream:
                self.assertEqual(list(csv.DictReader(stream)), rows)

    def test_actual_partition_membership(self):
        source = Path('D:/kimi/benchmark_public/v03_native_20261105/claude-code-S04-a1')
        p = partition(source / 'full.inp', source / 'generation.inp')
        self.assertEqual(len(p['sub_elements']), 24)
        self.assertEqual(len(p['core_elements']), 24)
        self.assertEqual(len(p['interface_nodes']), 9)
        self.assertEqual(len(p['retained_nodes']), 18)
        self.assertEqual(p['eliminated_translation_dofs'], 135)
        self.assertFalse(set(p['core_elements']) & set(p['sub_elements']))

    def test_frozen_execution_and_original_outputs_unchanged(self):
        registry = json.loads((OUT / 'codex_transport_registration.json').read_text())
        self.assertEqual(hashes(), registry['source_hashes'])
        self.assertGreater(len(integrity()), 100)

    def test_every_retained_attempt_and_artifact_indexed(self):
        summary = json.loads((OUT / 'summary.json').read_text())
        catalog = json.loads((PUBLIC / 'catalog.json').read_text())
        self.assertEqual({r['attempt'] for r in summary['rows']}, {r['attempt'] for r in catalog['records']})
        self.assertEqual(len(catalog['records']), 25)
        self.assertEqual(sum(len(r['artifacts']) for r in catalog['records']), 38)
        self.assertTrue(all(r['scoring_changed'] is False for r in catalog['records']))

    def test_original_odb_files_unchanged(self):
        from .lab_evidence import sha
        records = json.loads((EVIDENCE / 'local_native_files.json').read_text())
        odbs = {r['path']: r['sha256'] for r in records if r['path'].lower().endswith('.odb')}
        self.assertGreaterEqual(len(odbs), 5)
        for path, expected in odbs.items():
            self.assertEqual(sha(path), expected)


if __name__ == '__main__':
    unittest.main()
