# Step-by-Step Evidence

Follow each recorded input, decision and tool call through partitions, solver logs, numerical tables and genuine contours. All 25 retained records include startup failures.

Scoring unchanged. No inference or analysis rerun.

| Attempt | Status | Events |
|---|---|---|
| [claude-code-S01-a1](public/attempts/claude-code-S01-a1/index.en.html) | adapter_invalid | 7 |
| [claude-code-S01-a2](public/attempts/claude-code-S01-a2/index.en.html) | adapter_invalid | 7 |
| [claude-code-S01-a3](public/attempts/claude-code-S01-a3/index.en.html) | passed | 48 |
| [claude-code-S02-a1](public/attempts/claude-code-S02-a1/index.en.html) | passed | 52 |
| [claude-code-S03-a1](public/attempts/claude-code-S03-a1/index.en.html) | budget_exhausted | 65 |
| [claude-code-S04-a1](public/attempts/claude-code-S04-a1/index.en.html) | passed | 101 |
| [claude-code-S05-a1](public/attempts/claude-code-S05-a1/index.en.html) | failed | 55 |
| [claude-code-S06-a1](public/attempts/claude-code-S06-a1/index.en.html) | passed | 38 |
| [claude-code-S07-a1](public/attempts/claude-code-S07-a1/index.en.html) | protocol_ambiguity | 121 |
| [claude-code-S08-a1](public/attempts/claude-code-S08-a1/index.en.html) | passed | 43 |
| [codex-native-S01-a1](public/attempts/codex-native-S01-a1/index.en.html) | passed | 34 |
| [codex-native-S02-a1](public/attempts/codex-native-S02-a1/index.en.html) | adapter_invalid | 6 |
| [codex-native-S02-a2](public/attempts/codex-native-S02-a2/index.en.html) | passed | 22 |
| [codex-native-S03-a1](public/attempts/codex-native-S03-a1/index.en.html) | adapter_invalid | 6 |
| [codex-native-S03-a2](public/attempts/codex-native-S03-a2/index.en.html) | passed | 28 |
| [codex-native-S04-a1](public/attempts/codex-native-S04-a1/index.en.html) | adapter_invalid | 6 |
| [codex-native-S04-a2](public/attempts/codex-native-S04-a2/index.en.html) | environment_or_incomplete | 36 |
| [codex-native-S05-a1](public/attempts/codex-native-S05-a1/index.en.html) | adapter_invalid | 6 |
| [codex-native-S05-a2](public/attempts/codex-native-S05-a2/index.en.html) | passed | 35 |
| [codex-native-S06-a1](public/attempts/codex-native-S06-a1/index.en.html) | adapter_invalid | 6 |
| [codex-native-S06-a2](public/attempts/codex-native-S06-a2/index.en.html) | passed | 22 |
| [codex-native-S07-a1](public/attempts/codex-native-S07-a1/index.en.html) | adapter_invalid | 6 |
| [codex-native-S07-a2](public/attempts/codex-native-S07-a2/index.en.html) | passed | 27 |
| [codex-native-S08-a1](public/attempts/codex-native-S08-a1/index.en.html) | adapter_invalid | 6 |
| [codex-native-S08-a2](public/attempts/codex-native-S08-a2/index.en.html) | passed | 22 |