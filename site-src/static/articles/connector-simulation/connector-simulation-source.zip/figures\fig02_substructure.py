"""Substructure partition schematic. No real connector geometry."""
from pathlib import Path
import numpy as np
from matplotlib.patches import Rectangle
from plot_style import *

fig,axes=plt.subplots(1,2,figsize=(7.1,3.2))
for ax in axes:
    ax.set(xlim=(0,1),ylim=(0,1))
    ax.axis('off')
ax=axes[0]
ax.set_title('(a) Full mesh partition',loc='left',pad=10)
for x,w,c in [(.05,.32,TEAL),(.37,.26,ORANGE),(.63,.32,TEAL)]:
    ax.add_patch(Rectangle((x,.25),w,.5,ec=c,fc=c+'12',lw=1.))
    for xx in np.linspace(x,x+w,8):
        ax.plot([xx,xx],[.25,.75],color=c,lw=.6,alpha=.45)
    for yy in np.linspace(.25,.75,9):
        ax.plot([x,x+w],[yy,yy],color=c,lw=.6,alpha=.45)
ax.text(.5,.5,'CORE',ha='center',weight='bold',color=ORANGE)
ax.text(.21,.83,'SUB',ha='center',color=TEAL)
ax.text(.79,.83,'SUB',ha='center',color=TEAL)
ax.text(.5,.10,'Nonlinear contact stays in CORE',ha='center',fontsize=9)
ax=axes[1]
ax.set_title('(b) Retained interface + library',loc='left',pad=10)
box(ax,(.05,.25),.29,.5,'Library','reduced DOFs',TEAL)
box(ax,(.39,.25),.23,.5,'CORE','full detail',ORANGE)
box(ax,(.67,.25),.28,.5,'Library','reduced DOFs',TEAL)
for x in (.36,.65):
    ax.scatter([x]*5,np.linspace(.30,.70,5),s=21,facecolors='white',edgecolors=INK,lw=.8,zorder=5)
ax.text(.5,.10,'Retained nodes preserve load transfer',ha='center',fontsize=9)
fig.subplots_adjust(left=.03,right=.98,bottom=.04,top=.86,wspace=.20)
fig.savefig(Path(__file__).with_name('fig02_substructure.pdf'))
