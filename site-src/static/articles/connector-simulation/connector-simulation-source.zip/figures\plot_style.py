"""Public, synthetic method illustrations. No proprietary input files are read."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

INK='#183247'
TEAL='#16827e'
ORANGE='#cc6a31'
GRAY='#637482'


def style():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,
        'axes.titlesize':11,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
        'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,
        'axes.linewidth':.7,'axes.edgecolor':INK,'text.color':INK,'axes.labelcolor':INK,
        'xtick.color':INK,'ytick.color':INK,'lines.linewidth':1.2,'savefig.facecolor':'white'})


def box(ax,xy,w,h,title,detail='',color=TEAL):
    x,y=xy
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.015,rounding_size=0.025',
        ec=color,fc=color+'0c',lw=1.1))
    ax.text(x+w/2,y+h*.64,title,ha='center',va='center',weight='bold',fontsize=10)
    if detail:
        ax.text(x+w/2,y+h*.28,detail,ha='center',va='center',fontsize=9)


def arrow(ax,start,end,color=GRAY):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=11,color=color,lw=1.))


style()
