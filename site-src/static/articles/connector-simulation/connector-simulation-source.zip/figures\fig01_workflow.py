"""Workflow schematic; software architecture, not measured performance."""
from pathlib import Path
from plot_style import *

fig,ax=plt.subplots(figsize=(7.1,3.5))
ax.set(xlim=(0,1),ylim=(0,1))
ax.axis('off')
items=[(.02,.66,'Baseline model','interfaces + materials'),
       (.37,.66,'Bounded samples','MC / LHS / Sobol / Halton'),
       (.72,.66,'Tolerance injection','node shapes + controls'),
       (.72,.18,'Parallel cases','assemble / check / solve'),
       (.37,.18,'Contact assessment','all channels at endpoint'),
       (.02,.18,'Pose boundary','offset + initial angle')]
for x,y,title,detail in items:
    box(ax,(x,y),.25,.23,title,detail)
for start,end in [((.28,.77),(.36,.77)),((.63,.77),(.71,.77)),((.845,.64),(.845,.43)),
                  ((.71,.30),(.63,.30)),((.36,.30),(.28,.30))]:
    arrow(ax,start,end)
ax.text(.5,.53,'One frozen tolerance vector; traceable inputs and outputs',ha='center',fontsize=10)
fig.subplots_adjust(left=.02,right=.98,bottom=.04,top=.98)
fig.savefig(Path(__file__).with_name('fig01_workflow.pdf'))
