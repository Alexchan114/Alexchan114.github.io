"""New illustrative samples, not the project's actual tolerance vectors.

Underlying N(0,1) conditioned on [-1,1], n=256, seed=20261018.
Top panels show the unit-square design before inverse-CDF transformation.
"""
from pathlib import Path
import numpy as np
from scipy.stats import norm,qmc
from plot_style import *

n=256
seed=20261018
unit=[np.random.default_rng(seed).random((n,2)),
      qmc.LatinHypercube(2,seed=seed).random(n),
      qmc.Sobol(2,scramble=True,seed=seed).random_base2(8),
      qmc.Halton(2,scramble=True,seed=seed).random(n)]
names=['Monte Carlo','Latin hypercube','Sobol','Halton']
fig,axes=plt.subplots(2,4,figsize=(7.1,4.3))
x=np.linspace(-1,1,300)
a,b=norm.cdf(-1),norm.cdf(1)
for i,(u,name) in enumerate(zip(unit,names)):
    ax=axes[0,i]
    ax.scatter(u[:,0],u[:,1],s=3.5,color=TEAL,alpha=.7,rasterized=False)
    ax.set(title=name,xlim=(0,1),ylim=(0,1),xticks=[0,.5,1],yticks=[0,.5,1],xlabel='$u_1$')
    if i==0:
        ax.set_ylabel('$u_2$')
    ax=axes[1,i]
    values=norm.ppf(a+(b-a)*u[:,0])
    ax.hist(values,bins=np.linspace(-1,1,13),density=True,color=TEAL,alpha=.32,edgecolor='white',lw=.6)
    ax.plot(x,norm.pdf(x)/(b-a),color=ORANGE,lw=1.2)
    ax.set(xlim=(-1,1),ylim=(0,1.05),xticks=[-1,0,1],yticks=[0,.5,1],xlabel='Amplitude')
    if i==0:
        ax.set_ylabel('Density')
fig.subplots_adjust(left=.08,right=.985,bottom=.12,top=.91,hspace=.60,wspace=.45)
fig.savefig(Path(__file__).with_name('fig03_sampling.pdf'))
