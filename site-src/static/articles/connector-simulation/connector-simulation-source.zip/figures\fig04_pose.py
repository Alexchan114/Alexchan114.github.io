"""Manufacturing displacement versus whole-side mating pose: schematic only."""
from pathlib import Path
import numpy as np
from matplotlib.patches import Rectangle,Polygon,Arc
from plot_style import *

fig,axes=plt.subplots(1,2,figsize=(7.1,3.4))
for ax in axes:
    ax.set(xlim=(-.1,1.1),ylim=(-.2,1.05),aspect='equal')
    ax.axis('off')
ax=axes[0]
ax.set_title('(a) Local manufacturing offset',loc='left',pad=6)
ax.add_patch(Rectangle((.10,.10),.33,.65,fc=TEAL+'18',ec=TEAL,lw=1.1))
ax.add_patch(Rectangle((.43,.30),.48,.12,fc='none',ec=GRAY,ls='--',lw=1.))
ax.add_patch(Rectangle((.43,.46),.48,.12,fc=ORANGE+'25',ec=ORANGE,lw=1.1))
arrow(ax,(.79,.34),(.79,.53),ORANGE)
ax.text(.25,.83,'SUB stays',ha='center',fontsize=9,color=TEAL)
ax.text(.70,.68,'CORE terminal moves',ha='center',fontsize=9,color=ORANGE)
ax.text(.52,-.06,'Interface mismatch must be reviewed',ha='center',fontsize=9)
ax=axes[1]
ax.set_title('(b) Initial assembly pose',loc='left',pad=6)
c=np.array([.28,.30])
theta=np.deg2rad(15)
R=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])
delta=np.array([.10,.16])
for x,w,color in [(.08,.30,TEAL),(.38,.48,ORANGE)]:
    vertices=np.array([[x,.22],[x+w,.22],[x+w,.45],[x,.45]])
    ax.add_patch(Polygon(vertices,fc='none',ec=GRAY,ls='--',lw=.8))
    ax.add_patch(Polygon((vertices-c)@R.T+c+delta,fc=color+'24',ec=color,lw=1.1))
ax.scatter(*c,s=17,color=INK)
arrow(ax,c,c+delta)
ax.text(.63,.84,'CORE + SUB move together',ha='center',fontsize=9)
ax.text(.60,-.06,'Then insert along the prescribed axis',ha='center',fontsize=9)
fig.subplots_adjust(left=.03,right=.98,bottom=.06,top=.87,wspace=.25)
fig.savefig(Path(__file__).with_name('fig04_pose.pdf'))
