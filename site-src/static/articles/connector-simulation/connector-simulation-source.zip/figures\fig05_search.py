"""Search decisions schematic. Pass/fail colors are conceptual, not solver data."""
from pathlib import Path
from plot_style import *

fig,ax=plt.subplots(figsize=(7.1,3.7))
ax.set(xlim=(0,1),ylim=(0,1))
ax.axis('off')
box(ax,(.02,.67),.26,.23,'Verify baseline','fixed tolerances',TEAL)
box(ax,(.37,.67),.26,.23,'Parallel coarse scan','signed offsets / angles',TEAL)
box(ax,(.72,.67),.26,.23,'Bracket crossings','pass | fail | unknown',ORANGE)
arrow(ax,(.29,.78),(.36,.78))
arrow(ax,(.64,.78),(.71,.78))
box(ax,(.72,.18),.26,.23,'Subdivide intervals','batch interior points',ORANGE)
box(ax,(.37,.18),.26,.23,'Refine angle slices','boundary / channel changes',TEAL)
box(ax,(.02,.18),.26,.23,'Export brackets','resolution + unknowns',TEAL)
arrow(ax,(.85,.65),(.85,.43))
arrow(ax,(.71,.29),(.64,.29))
arrow(ax,(.36,.29),(.29,.29))
arrow(ax,(.50,.42),(.50,.65),ORANGE)
ax.text(.5,.04,'No force-monotonicity assumption; no continuous-space safety proof',ha='center',fontsize=9)
fig.subplots_adjust(left=.02,right=.98,bottom=.02,top=.98)
fig.savefig(Path(__file__).with_name('fig05_search.pdf'))
