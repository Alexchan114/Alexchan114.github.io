# Connector simulation automation: anonymous public article

Main text: `connector-simulation.tex`, compiled with XeLaTeX twice.
Author: AlexanderChan. Date: 2026-10-18.

This source bundle contains no CAD, FE meshes, solver libraries, original
tolerance vectors, real contact-force outputs, client identities or server paths.
The sampling example is newly generated illustrative data, not a cleared export
of project data. The remaining figures are conceptual diagrams.

## Build

Requirements: TeX Live with XeLaTeX and Chinese fonts; Python with NumPy,
SciPy and Matplotlib; Tavotto for figure editing/export.

The supplied PDF figures have already been exported through Tavotto 0.18.0
(RenderCore backend). Compile the article without rerunning any scripts:

```text
xelatex -interaction=nonstopmode -halt-on-error connector-simulation.tex
xelatex -interaction=nonstopmode -halt-on-error connector-simulation.tex
```

The initial setup uses the Windows CTeX font set and Consolas. On a non-Windows
system, change `fontset=windows` to `fontset=fandol` and use `TeX Gyre Cursor`
instead of Consolas if that font is not installed.

## Figures

`figures/fig01_workflow.py` - workflow architecture schematic.
`figures/fig02_substructure.py` - abstract CORE/SUB partition schematic.
`figures/fig03_sampling.py` - independent sampling demonstration.
`figures/fig04_pose.py` - local manufacturing displacement vs whole-side pose.
`figures/fig05_search.py` - parallel adaptive-search decision schematic.
`figures/plot_style.py` - shared style, no project inputs.

Run each `fig*.py` with Python, then open `figures/` as a project in Tavotto.
The script remains beside its raw PDF, so Tavotto can associate editable artists.
For each figure, choose original figure dimensions and export vector PDF.
Put exported PDFs in `figures/exported/` using the original base filenames.
Tavotto standard export was used; this is not a claim of passing every journal
profile rule. Pages and plots were visually inspected separately.

Sampling parameters: 256 points per method; independent two-dimensional MC,
LHS, scrambled Sobol and scrambled Halton; seed 20261018. Top panels show the
unit-square design, bottom panels show the first coordinate after inverse-CDF
mapping of an underlying N(0,1) conditioned on [-1,1]. The conditional standard
deviation is not 1. No mechanical response is inferred from this demonstration.

## Scope

The article distinguishes offline software/coordinate tests from real solver
validation. It reports no connector critical angles, failure probabilities,
speedup ratios or unpublished contact forces. A sampled 2D boundary is not a
certificate of continuous-space safety or a full multi-axis reliability result.

English full text: connector-body.en.tex. English document: connector-simulation.en.tex. Compile the English document twice with XeLaTeX; all figure PDFs are shared. Both language PDFs are linked from their matching full web articles.
