# Eight tasks and scoring basis

## S01 Units, series compliance and equilibrium

Find tip U in mm, root reaction in N and total strain energy in N mm. Convert GPa to MPa. Execute the FEM tool and cite its artifact.

Tier: public_reduced_physics

```json
{
  "fixture": {
    "length_mm": [
      4,
      6,
      2
    ],
    "area_mm2": [
      2,
      3,
      1
    ],
    "E_GPa": [
      2,
      1,
      3
    ],
    "tip_force_N": 12
  },
  "output": {
    "artifact_id": "string",
    "U_mm": "number",
    "reaction_N": "number",
    "energy_Nmm": "number"
  }
}
```

## S02 Goal-oriented mesh allocation

Use uniform 1D linear axial elements and midpoint area. Choose the smallest allowed n with relative tip-U error <=0.001 versus the exact continuum integral. Execute the mesh tool for the submitted n; report U and relative error.

Tier: public_reduced_physics

```json
{
  "fixture": {
    "L_mm": 1,
    "E_MPa": 1000,
    "F_N": 10,
    "A_mm2": "1+x (x in mm)",
    "allowed_n": [
      1,
      2,
      4,
      8,
      16,
      32,
      64
    ],
    "relative_tolerance": 0.001
  },
  "output": {
    "artifact_id": "string",
    "n": "integer",
    "U_mm": "number",
    "relative_error": "number"
  }
}
```

## S03 Independent prelift and unilateral contact

Six plates each control consecutive pairs (1,2),(3,4),etc. Choose six independent amplitudes in [0,1] minimizing sum(a_i^2) while every final normal force is >=0.4 N. No friction contribution. Use contact_test; report amplitudes and 12 final forces. This is a unilateral spring model, not a solid/contact solver.

Tier: public_reduced_physics

```json
{
  "fixture": {
    "base_lift_mm": 0.3348,
    "scale_mm": 0.15,
    "insertion_mm": 0.18,
    "gaps_mm": [
      0.48,
      0.52,
      0.54,
      0.5,
      0.53,
      0.56,
      0.49,
      0.51,
      0.57,
      0.55,
      0.52,
      0.54
    ],
    "stiffness_N_per_mm": [
      6,
      8,
      7,
      6,
      8,
      7,
      6,
      9,
      7,
      8,
      6,
      7
    ],
    "threshold_N": 0.4
  },
  "output": {
    "artifact_id": "string",
    "amplitudes": "six numbers",
    "forces_N": "12 numbers"
  }
}
```

## S04 Autonomous 3D substructure partition

Choose the cut maximizing eliminated translational DOFs while keeping all potentially plastic elements outside the linear substructure. Retain ROOT and all interface translations. Run partition_test on your chosen cut: it invokes actual Abaqus generation, reduced solve and ODB extraction via MCP (1 CPU). Cite the returned artifact. Do not use stress magnitude alone to declare a region linear.

Tier: abaqus_mcp_3d

```json
{
  "fixture": {
    "dimensions_mm": [
      12,
      2,
      2
    ],
    "mesh": "117 nodes,48 C3D8; x planes at integers; 9 nodes per plane",
    "node_rule": "label=1+9*i+3*j+k; i=0..12,j,k=0..2",
    "materials": [
      {
        "x_mm": [
          0,
          6
        ],
        "E_MPa": 1000,
        "nu": 0,
        "law": "linear elastic"
      },
      {
        "x_mm": [
          6,
          12
        ],
        "E_MPa": 1000,
        "nu": 0,
        "law": "J2 plastic; yield=1MPa; hardening=50MPa"
      }
    ],
    "load": "ROOT fixed; TIP U1=0.12mm, NLGEOM=NO",
    "cuts_mm": [
      2,
      4,
      6,
      8
    ],
    "requirement": "linear substructure must preserve nonlinear constitutive regions; curve error <=1e-4 N"
  },
  "output": {
    "artifact_id": "string",
    "cut_mm": "integer",
    "retained_nodes": "18 integers",
    "retained_dofs": "[1,2,3]",
    "eliminated_dofs": "integer"
  }
}
```

## S05 Bounded sampling and physical tolerance mapping

Generate 16 samples of 72 independent variables using each of MC,LHS,Sobol,Halton. All marginals are standard normal conditioned on [-1,1], not clipped normal or uniform. Use sample_test once per method, seed=20261104. Submit four artifact IDs and physical values for the first MC vector. First42 are Z shape changes (0.15a mm), next6 prelift (.3348+0.15a mm), final24 alternating X,Y per 12 rigid CORE terminals (0.1a mm). SUB is unchanged; translation preserves terminal dimensions.

Tier: public_reduced_physics

```json
{
  "fixture": {
    "n": 16,
    "dimensions": 72,
    "seed": 20261104,
    "bounds": [
      -1,
      1
    ],
    "marginal": "truncated standard normal",
    "shape_count": 42,
    "prelift_count": 6,
    "terminal_count": 12
  },
  "output": {
    "artifact_ids": "4 strings, MC/LHS/Sobol/Halton order",
    "first_MC_physical_mm": "72 numbers"
  }
}
```

## S06 Reuse, geometry compatibility and Tie coverage

Choose a reusable library matching target retained topology/material/coordinates. Independently translated CORE slave faces need an unadjusted Tie to an unchanged master plane; maximum normal offset is 0.1mm X +0.1mm Y projected on n. Give minimal safe tolerance=max distance+1e-6 mm, ADJUST=false. In both experiment and final solution, adjust MUST be a JSON boolean false, not a string. Tolerance must not excuse an incompatible library. Execute interface_test.

Tier: public_reduced_physics

```json
{
  "fixture": {
    "target": {
      "topology": "mesh-A",
      "material": "E1000",
      "retained_xyz": [
        [
          0,
          0,
          0
        ],
        [
          0,
          0,
          1
        ]
      ]
    },
    "libraries": {
      "L17": {
        "topology": "mesh-A",
        "material": "E1000",
        "retained_xyz": [
          [
            0,
            0,
            0
          ],
          [
            0,
            0,
            1
          ]
        ]
      },
      "L24": {
        "topology": "mesh-A",
        "material": "E1000",
        "retained_xyz": [
          [
            0,
            0,
            0
          ],
          [
            0,
            0.02,
            1
          ]
        ]
      },
      "L33": {
        "topology": "mesh-A",
        "material": "E1200",
        "retained_xyz": [
          [
            0,
            0,
            0
          ],
          [
            0,
            0,
            1
          ]
        ]
      },
      "L41": {
        "topology": "mesh-B",
        "material": "E1000",
        "retained_xyz": [
          [
            0,
            0,
            0
          ],
          [
            0,
            0,
            1
          ]
        ]
      }
    },
    "master_normal": [
      0.7071067811865475,
      0.7071067811865475,
      0
    ],
    "offset_limits_mm": [
      0.1,
      0.1
    ],
    "margin_mm": 1e-06
  },
  "output": {
    "artifact_id": "string",
    "library_id": "string",
    "tie_tolerance_mm": "number",
    "adjust": "JSON boolean false, not string"
  }
}
```

## S07 Coupled offset-angle first-loss boundary

Along lambda in [0,2], offset X=0.1*lambda mm and angle=2*lambda deg, find a safe/failing bracket for the FIRST contact loss. Any of12 normal forces <0.4N fails. Return lambda_safe,lambda_failed with width<=0.002 and two pose_test artifacts proving endpoints. Kinematic spring contact only, not a connector prediction. Use the lever-arm geometry rather than a reward surrogate.

Tier: public_reduced_physics

```json
{
  "fixture": {
    "k_N_per_mm": [
      6.0,
      6.2,
      6.4,
      6.6,
      6.8,
      7.0,
      7.2,
      7.4,
      7.6,
      7.8,
      8.0,
      8.2
    ],
    "initial_overlap_mm": [
      0.19,
      0.193,
      0.196,
      0.199,
      0.202,
      0.20500000000000002,
      0.20800000000000002,
      0.211,
      0.214,
      0.217,
      0.22,
      0.223
    ],
    "normal_x": [
      0.45,
      0.47000000000000003,
      0.49,
      0.51,
      0.53,
      0.55,
      0.5700000000000001,
      0.5900000000000001,
      0.61,
      0.63,
      0.65,
      0.67
    ],
    "lever_mm": [
      1.5,
      1.56,
      1.62,
      1.68,
      1.74,
      1.8,
      1.8599999999999999,
      1.92,
      1.98,
      2.04,
      2.1,
      2.16
    ],
    "path": {
      "offset_X_mm_per_lambda": 0.1,
      "angle_deg_per_lambda": 2
    },
    "threshold_N": 0.4,
    "lambda_limits": [
      0,
      2
    ]
  },
  "output": {
    "lambda_safe": "number",
    "lambda_failed": "number",
    "artifact_ids": "safe/fail IDs"
  }
}
```

## S08 Failure recovery and trustworthy ranking

Rank only trustworthy completed cases by minimum absolute normal force across12pairs at final |U3|=8mm. Sort ASCENDING minimum force, weakest first; ties by case ID ascending. Return contact_failures in this same ascending order. Report failure cases (<0.4N) and a recovery action for every case. Completed evidence must include solver success, final frame,12channels. Minimal recovery policy: every trustworthy completed case is done, including genuine contact failures; physical failure alone is not a reason to retry. Inactive interrupted jobs use retry_solve, completed jobs with missing channels use reextract, active jobs use wait, input errors with negative volume use repair_mesh. Never retry an active job or treat numerical abort as contact failure. inspect_cases exposes read-only evidence; no solver is launched.

Tier: public_reduced_physics

```json
{
  "fixture": {
    "final_abs_U3_mm": 8,
    "expected_pairs": 12,
    "threshold_N": 0.4,
    "cases": {
      "c01": {
        "solver": "completed",
        "U3": -8,
        "forces": [
          -0.41,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8
        ],
        "active": false
      },
      "c02": {
        "solver": "completed",
        "U3": -8,
        "forces": [
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.35,
          -0.8,
          -0.8,
          -0.8,
          -0.8
        ],
        "active": false
      },
      "c03": {
        "solver": "completed",
        "U3": -8,
        "forces": [
          -0.38,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9,
          -0.9
        ],
        "active": false
      },
      "c04": {
        "solver": "interrupted",
        "U3": -7,
        "forces": [
          -0.01,
          -0.01,
          -0.01,
          -0.01,
          -0.01,
          -0.01,
          -0.01,
          -0.01,
          -0.01,
          -0.01,
          -0.01,
          -0.01
        ],
        "active": false
      },
      "c05": {
        "solver": "completed",
        "U3": -8,
        "forces": [
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1
        ],
        "active": false
      },
      "c06": {
        "solver": "running",
        "U3": -4,
        "forces": [
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1,
          -0.1
        ],
        "active": true
      },
      "c07": {
        "solver": "input_error",
        "error": "negative element volume",
        "active": false
      },
      "c08": {
        "solver": "completed",
        "U3": -8,
        "forces": [
          -0.45,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8,
          -0.8
        ],
        "active": false
      }
    }
  },
  "output": {
    "artifact_id": "string",
    "ranking": "case IDs",
    "contact_failures": "case IDs",
    "actions": "object: done/retry_solve/reextract/wait/repair_mesh"
  }
}
```
