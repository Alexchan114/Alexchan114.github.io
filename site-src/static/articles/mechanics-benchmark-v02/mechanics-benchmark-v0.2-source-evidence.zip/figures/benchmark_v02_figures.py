"""Original public figures, sourced from measured artifacts; exported by Tavotto."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch

ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'figure_data.json').read_text(encoding='utf-8'))
INK,TEAL,ORANGE,GRAY='#203746','#197b77','#bf6039','#77818a'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'text.color':INK,
    'axes.labelcolor':INK,'axes.edgecolor':GRAY,'xtick.color':GRAY,'ytick.color':GRAY,
    'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})

fig,ax=plt.subplots(figsize=(9,4.5));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
ax.text(.02,.95,'MECHANICS DECISIONS, NOT PLAUSIBLE PROSE',fontsize=13,weight='bold')
def box(x,y,w,h,title,body,color=TEAL):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.01,rounding_size=.012',fc=color+'0b',ec=color,lw=1))
    ax.text(x+.02,y+h-.065,title,fontsize=10,weight='bold',color=color)
    ax.text(x+.02,y+h-.13,body,va='top',linespacing=1.55,fontsize=9)
box(.03,.54,.27,.29,'PUBLIC TASK','load / mesh / contact\npartition / tolerances\nreuse / boundary / recovery')
box(.37,.54,.25,.29,'MODEL + HARNESS','Kimi + controlled mini\nDeepSeek + Pi SDK\nread-only CCS route')
box(.70,.54,.27,.29,'FINITE CAPABILITIES','inspect / experiment / submit\nno shell or arbitrary files\nno answer/evaluator access')
box(.37,.12,.25,.27,'AUDIT TRAIL','query / output / artifact\nMCP parent-call IDs\nfrozen sources + hashes',INK)
box(.70,.12,.27,.27,'HOST VALIDATOR','independent mechanics\nfull vs reduced 3D curve\npass / fail / environment',ORANGE)
for a,b in [((.31,.68),(.35,.68)),((.63,.68),(.68,.68)),((.495,.52),(.495,.41)),((.835,.52),(.835,.41)),((.63,.25),(.68,.25))]:
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=13,color=GRAY,lw=1.2))
ax.text(.03,.34,'EXECUTION TIERS',color=TEAL,weight='bold',fontsize=10)
ax.text(.03,.27,'S04: actual Abaqus / MCP\nOther 7: declared reduced physics\nNo industrial-model upload',fontsize=9,va='top',linespacing=1.6)
fig.subplots_adjust(left=.02,right=.98,bottom=.02,top=.98);fig.savefig(ROOT/'workflow.pdf');plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(9,4.5),gridspec_kw={'width_ratios':[1,1.1]})
ax=axes[0]
ax.axvspan(0,6,color=TEAL,alpha=.10);ax.axvspan(6,12,color=ORANGE,alpha=.12)
for x in range(13):ax.plot([x,x],[0,2],color=GRAY,lw=.6)
for y in range(3):ax.plot([0,12],[y,y],color=GRAY,lw=.6)
ax.plot([6,6],[-.15,2.15],color=TEAL,lw=2.5)
ax.text(3,2.55,'LINEAR SUB',ha='center',color=TEAL,weight='bold',fontsize=10)
ax.text(9,2.55,'J2 PLASTIC CORE',ha='center',color=ORANGE,weight='bold',fontsize=10)
ax.text(3,-.3,'135 interior DOFs\neliminated',ha='center',va='top',fontsize=8,color=TEAL)
ax.text(9,-.3,'nonlinear material\nretained',ha='center',va='top',fontsize=8,color=ORANGE)
ax.set(xlim=(-.5,12.5),ylim=(-1.5,3.3),xlabel='x / mm',ylabel='y / mm');ax.set_aspect('equal')
ax.set_title('48 C3D8 / 117 nodes',loc='left',fontsize=11,pad=20)
ax=axes[1];c=D['curves']
for name,marker,color,style in [('full_odb','o',INK,'-'),('reduced_odb','x',TEAL,'--')]:
    rows=c[name];ax.plot([r['U1'] for r in rows],[r['tip_RF1'] for r in rows],style,marker=marker,
        markersize=4,color=color,label='Full 3D' if name=='full_odb' else 'Linear SUB + plastic CORE')
ax.set(xlabel='Tip U1 / mm',ylabel='Total tip RF1 / N');ax.grid(alpha=.15)
ax.legend(frameon=False,fontsize=8,loc='lower right')
ax.set_title('Actual Abaqus results',loc='left',fontsize=11)
ax.text(.03,.90,'Stored-frame difference: 0 N\nIndependent reference reused',transform=ax.transAxes,fontsize=9,color=TEAL,va='top')
fig.subplots_adjust(left=.07,right=.98,top=.85,bottom=.16,wspace=.28);fig.savefig(ROOT/'solid.pdf');plt.close(fig)

fig,axes=plt.subplots(2,2,figsize=(9,5.5),sharex=True,sharey=True)
x=np.linspace(-1,1,300);norm=np.sqrt(2*np.pi)*.6826894921370859
for ax,(name,values) in zip(axes.flat,D['sampling'].items()):
    ax.hist(values,bins=np.linspace(-1,1,9),density=True,color=TEAL,alpha=.6,edgecolor='white',lw=.7)
    ax.plot(x,np.exp(-x*x/2)/norm,color=ORANGE,lw=1.7,label='Target truncated normal')
    ax.set_title(name+' / n=16',loc='left',fontsize=11);ax.grid(axis='y',alpha=.13)
    ax.set(xlim=(-1,1),ylim=(0,2))
for ax in axes[-1,:]:ax.set_xlabel('Dimensionless amplitude')
for ax in axes[:,0]:ax.set_ylabel('Probability density')
handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',frameon=False,ncol=1)
fig.subplots_adjust(left=.09,right=.98,top=.86,bottom=.11,wspace=.14,hspace=.38)
fig.savefig(ROOT/'sampling.pdf');plt.close(fig)

rows=D['summary']['rows'];fig,ax=plt.subplots(figsize=(9,5.5))
colors={'passed':TEAL,'environment_error':GRAY,'failed_or_budget':ORANGE,'adapter_invalid':GRAY,'excluded_task_ambiguity':GRAY,'excluded_policy_ambiguity':GRAY}
for i,r in enumerate(rows):
    ax.barh(i,r['elapsed_seconds'],color=colors[r['classification']],height=.55)
    ax.text(r['elapsed_seconds']+5,i,r['classification'].replace('_',' '),va='center',fontsize=8)
ax.set_yticks(range(len(rows)),[r['task']+('*' if r['phase']=='amended' else '')+' / '+r['configuration'] for r in rows]);ax.invert_yaxis()
ax.set(xlabel='Single-attempt wall time / s',xlim=(0,max(r['elapsed_seconds'] for r in rows)*1.75))
ax.set_title('8 INITIAL + 2 PROTOCOL CHECKS / NOT A MODEL RANKING',loc='left',fontsize=11,pad=17)
ax.grid(axis='x',alpha=.14);ax.set_axisbelow(True);ax.spines['left'].set_visible(False)
fig.subplots_adjust(left=.24,right=.98,top=.88,bottom=.13);fig.savefig(ROOT/'outcomes.pdf');plt.close(fig)
