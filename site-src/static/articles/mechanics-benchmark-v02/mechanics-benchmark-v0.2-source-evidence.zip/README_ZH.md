# 力学工程 Agent Benchmark v0.2

八道公开力学/工程决策题均有工具、产物和独立判分器。S04实际调用Abaqus/MCP；其余七题是明确标注的简化力学或工程证据题，不是七道真实商业软件操作题。原v0.1结果保留，不以新版成绩替换旧失败。

当前交付修订为v0.2.2：首轮8次，加2次题面澄清复核，共10次记录。4次通过、2次有效预算未通过、1次RPM限制、3次协议歧义排除，能力有效尝试6次。详见`PROTOCOL_REVIEW.md`。最后一次对恢复策略的题面澄清没有继续调用API，不能称其已完成新试跑。更正前后两套已运行的冻结源码均有哈希校验，不覆盖原记录。

## 阅读与证据
- `publication/benchmark_v02_zh.pdf`：中文正文，LaTeX源文件同目录。
- `publication/benchmark_v02_en.pdf`：英文正文。
- `documentation/TASK_CARDS_ZH.md`：八题输入、要求、产物结构。
- `documentation/QUERY_OUTPUTS_ZH.md`：每次可观测请求、输出、工具返回和原生MCP事件。
- `summary.csv`、`summary.json`：单次任务结果、耗时和API报告的用量；不是排行榜。
- `preregistration.json`：推理前冻结的题目、源码哈希、预算和八次尝试矩阵。
- `pilot/`：原始本地证据。公开ZIP中的账号标识会被隐去，原始本地记录不修改。
- `figures/`：Tavotto图源、数据和导出；`qa/`：导出回执及发布检查。

## 本地运行
在源码包根目录运行。Python依赖见`mechanics_benchmark/requirements.txt`。当前已验证Python3.12.9、NumPy2.1.3、SciPy1.17.1和HTTPX0.28.1。

```powershell
python -m pip install -r mechanics_benchmark/requirements.txt
python -m unittest discover -s mechanics_benchmark/tests -q
python -m mechanics_benchmark.run_suite freeze --output NEW_OUTPUT
python -m mechanics_benchmark.run_suite run --output NEW_OUTPUT --task S02 --configuration deepseek-pi
```

先用全新目录冻结。每个题目只执行一次；已有目录会报错而非覆盖。不要删除失败记录后重跑。修改题目、路由或评分规则时使用新版本/新目录并再次冻结。

复核旧结果时采用`frozen_source/mechanics_benchmark`或`amendment/frozen_source/mechanics_benchmark`中的对应版本，不能用已经扩展的新源码冒充原冻结字节。旧快照的恢复方式与SHA256精确验证见各自的`verification.json`；最初未预哈希的Pi桥接/依赖文件另行标注。新的freeze会同时快照并哈希Python、Pi桥接和requirements。

## 服务器迁移
上传源码文件夹及本README，不上传CCS数据库或商业软件。按服务器实际环境修改以下位置，再运行freeze：

1. `credentials.py`的`DEFAULT_DB`，或采用本机合规密钥注入方式；当前实现从本机CCS只读取凭据。
2. `run_suite.py`的`CONFIGURATIONS`（本机CCS provider ID、请求model ID）、Node与Pi SDK路径。
3. `suite_tools.py`的MCP专用Python和MCP项目所在目录；MCP环境需已安装并运行其dispatcher。
4. `run_suite.py`的`--reference`与`--solver-root`，指向服务器原创参考算例及隔离的求解目录。
5. `calibrate_solid.py`中的MCP启动目录。先在服务器执行完整校准，不能把本机旧ODB路径当作服务器上的有效参考。

```powershell
MCP_PYTHON -m mechanics_benchmark.calibrate_solid --output REFERENCE_DIR
python -m mechanics_benchmark.run_suite run --output NEW_OUTPUT --task S04 --configuration deepseek-pi --reference REFERENCE_DIR --solver-root PUBLIC_SOLVER_ROOT
```

Pi SDK使用`@mariozechner/pi-coding-agent@0.73.1`，由Node22.16验证。SDK不是模型，不包含API额度；运行时单独安装，不随源码ZIP打包。商业软件、许可证及MCP部署也不包含在包中。不要把工业工程文件作为公开API输入。

## 新框架/新模型
模型路由与框架独立。新增路由修改`CONFIGURATIONS`；新增框架需实现`call(name,arguments,id)`回传、同等受控工具、事件日志和预算控制。当前只验证mini和Pi，其他客户端不应在未测试时标为兼容。正式公平比较要交叉运行相同任务，而不是对本轮交替分配的不同题直接比较通过率。

现在也可不改代码，通过`--configurations configurations.json --matrix matrix.json`传给freeze。配置文件每个条目只含`provider`（本机CCS ID）、`model`和`adapter`（`mini`或`pi`），不能含密钥；矩阵为`[{"task":"S03","configuration":"自定义配置名"}]`。同一个provider/model可以分别注册mini、Pi两种组合。freeze只登记，不会自动执行整个矩阵，也不代表已经批准大批量API费用。

## 费用与限制
每题最多6次模型调用、每次6144输出token、24次工具调用；S04最多一次真实候选分区。8次开发试跑不是96次重复研究。服务限流、环境失败、无提交及数值失败分别保留。账单不可由token或Pi的零成本占位字段推断，实际费用未知，未购买额度。
