"""Frozen eight-exercise bounded pilot; credentials resolved from CCS read-only."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import platform
import time
from importlib.metadata import version
from .api import Client,SYSTEM,run_loop
from .credentials import select
from .security import Trace,digest
from .suite_v2 import task_cards,definitions,query,VERSION
from .suite_tools import Broker
from .suite_evaluate import evaluate
from .pi_adapter import run_pi


CONFIGURATIONS={
    'kimi-mini':dict(provider='e64ab143-3e03-483a-bef2-46fb708af66e',model='kimi-k2.6',adapter='mini'),
    'deepseek-pi':dict(provider='ab26ff7c-b94a-4228-a0b0-a5b40a926362',model='deepseek-v4-flash',adapter='pi')}


def freeze(root):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    cards=task_cards();specs=definitions()
    value=dict(version=VERSION,tasks=cards,tools=specs,system=SYSTEM,
        matrix=[dict(task=k,configuration='kimi-mini' if int(k[1:])%2 else 'deepseek-pi') for k in cards],
        repetitions=1,automatic_retries=0,extra_runs='none authorized by this registry',
        scoring='all checks binary; no model judge; missing submission scores zero',
        dependencies={k:version(k) for k in ('numpy','scipy','httpx')},
        source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')},
        scope='eight public exercises; S04 actual 3D Abaqus, seven reduced-physics exercises; not eight vendor CAE tasks',
        cost='existing API authorization, max8 attempts*6calls*6144output tokens; no purchase, no 96-run campaign')
    path=root/'preregistration.json'
    if path.exists() and json.loads(path.read_text(encoding='utf-8'))!=value:raise ValueError('Registry changed; new release directory required')
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')
    return value


def run(root,key,configuration,reference,solver_root):
    root=Path(root);registration=json.loads((root/'preregistration.json').read_text(encoding='utf-8'))
    if dict(task=key,configuration=configuration) not in registration['matrix']:raise ValueError('Outside frozen matrix')
    for name,expected in registration['source_hashes'].items():
        if hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()!=expected:
            raise ValueError('Source changed after registration: '+name)
    card=registration['tasks'][key];cfg=CONFIGURATIONS[configuration]
    route=select(cfg['provider']);folder=root/'pilot'/(configuration+'-'+key+'-a1')
    folder.mkdir(parents=True,exist_ok=False);trace=Trace(folder,[route.secret]);budget=card['budget']
    args=argparse.Namespace(model=cfg['model'],max_turns=budget['max_turns'],
        max_output_tokens=budget['max_output_tokens'],timeout=300,node='D:/NodeJs/node.exe',
        pi_module='D:/huaweiproject/outputs/mechanics_agent_benchmark_20261103/pi-runtime/node_modules/@mariozechner/pi-coding-agent/dist/index.js')
    specs=registration['tools'];q=query(card)
    trace.save('query.json',dict(system=SYSTEM,user=q,tools=specs));trace.save('task.json',card)
    metadata=dict(version=VERSION,task_id=key,tier=card['tier'],adapter=cfg['adapter'],requested_model=cfg['model'],
        provider=route.public(),started_utc=datetime.now(timezone.utc).isoformat(),status='running',
        preregistration_hash=digest(registration),task_hash=digest(card),query_hash=digest(q),
        dependencies=registration['dependencies'],hardware=platform.platform(),budgets=budget,
        actual_billed_usd=None,automatic_retry=False)
    trace.save('run.json',metadata);started=time.monotonic()
    broker=Broker(card,trace,solver_root,reference)
    try:
        result=(run_loop(Client(route,args.model,trace,args.max_output_tokens,args.timeout),q,specs,broker,args.max_turns)
            if cfg['adapter']=='mini' else run_pi(route,args,q,specs,broker,trace))
        scoring=evaluate(card,broker.submission['solution'],broker.artifacts) if broker.submission else dict(status='not_submitted',score=0,checks={})
        metadata.update(status=result['status'],result=result,evaluation=scoring)
        trace.save('evaluation.json',scoring)
    except Exception as error:
        trace.write('execution_error',error=str(error),error_type=type(error).__name__)
        metadata.update(status='execution_error',error=str(error),error_type=type(error).__name__)
    finally:
        metadata.update(elapsed_seconds=time.monotonic()-started,tool_calls=broker.calls,
            solver_tests=broker.solver_calls,finished_utc=datetime.now(timezone.utc).isoformat())
        trace.save('run.json',metadata)
    print(json.dumps(dict(task=key,configuration=configuration,status=metadata['status'],evaluation=metadata.get('evaluation')),indent=2),flush=True)
    return metadata


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['freeze','run']);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--task',choices=task_cards());p.add_argument('--configuration',choices=CONFIGURATIONS)
    p.add_argument('--reference',default='D:/kimi/benchmark_public/solid_20261104_03')
    p.add_argument('--solver-root',default='D:/kimi/benchmark_public/v02_agent')
    a=p.parse_args()
    if a.command=='freeze':print('Frozen',digest(freeze(a.output)))
    else:run(a.output,a.task,a.configuration,a.reference,a.solver_root)
