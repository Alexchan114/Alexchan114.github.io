# Mechanics Agent Benchmark v0.2

Eight public mechanics/engineering exercises have executable tools, artifacts and independent checks. S04 uses actual Abaqus through MCP; seven others explicitly use reduced physics or synthetic engineering evidence. They are not seven vendor-software tasks. Historical v0.1 attempts remain unchanged.

Release revision v0.2.2 retains8 initial attempts plus2 protocol checks:4 passes,2 valid budget failures,1 RPM error and3 protocol-ambiguity exclusions;6 capability-valid attempts remain. See `PROTOCOL_REVIEW.md`. The last recovery-policy clarification has no additional model trial. Neither raw results nor original registrations are overwritten.

## Deliverables
- `publication/benchmark_v02_en.pdf` and `benchmark_v02_zh.pdf`: bilingual LaTeX reports and adjacent sources.
- `documentation/TASK_CARDS_EN.md`: eight task inputs, requirements and output schemas.
- `documentation/QUERY_OUTPUTS_EN.md`: complete observable requests, outputs, tool responses and native MCP events.
- `summary.csv/json`: single-attempt outcomes, elapsed times and provider-reported usage, not a leaderboard.
- `preregistration.json`: sources, tasks, budgets and eight-attempt matrix frozen before inference.
- `pilot/`: original local evidence. Public archive copies redact account identifiers without rewriting originals.
- `figures/`: Tavotto sources/data/exports; `qa/`: receipts and release audit.

## Run
Tested Python3.12.9, NumPy2.1.3, SciPy1.17.1, HTTPX0.28.1. Run from the source bundle root:

```powershell
python -m pip install -r mechanics_benchmark/requirements.txt
python -m unittest discover -s mechanics_benchmark/tests -q
python -m mechanics_benchmark.run_suite freeze --output NEW_OUTPUT
python -m mechanics_benchmark.run_suite run --output NEW_OUTPUT --task S02 --configuration deepseek-pi
```

Choose a new directory. Existing attempts are rejected, not overwritten. Changed rules/routes require a new registration. Do not delete failures to manufacture a passing record.

For old runs, use their exact `frozen_source/mechanics_benchmark` or `amendment/frozen_source/mechanics_benchmark` snapshot. Verification receipts identify byte-for-byte SHA256 recovery and originally unpinned supplemental files. New freezes also hash/snapshot the Pi bridge and requirements.

## Server migration
Upload source code, not CCS databases or vendor software. Before freezing, configure:

1. Local credential resolution in `credentials.py`; no plaintext key files in public outputs.
2. Provider IDs/model IDs, Node and Pi SDK paths in `run_suite.py`.
3. MCP Python path in `suite_tools.py`; deploy/start the existing MCP dispatcher separately.
4. `--reference` and `--solver-root` paths to original public fixtures and isolated solver workspaces.
5. MCP working directory in `calibrate_solid.py`. Build a fresh reference on the server; local ODB paths are not portable evidence.

```powershell
MCP_PYTHON -m mechanics_benchmark.calibrate_solid --output REFERENCE_DIR
python -m mechanics_benchmark.run_suite run --output NEW_OUTPUT --task S04 --configuration deepseek-pi --reference REFERENCE_DIR --solver-root PUBLIC_SOLVER_ROOT
```

Pi SDK is pinned to`@mariozechner/pi-coding-agent@0.73.1`, tested on Node22.16. Install it separately. SDKs supply no model credits. Commercial software/licenses/MCP deployment are not bundled. Keep industrial models out of public API inputs.

## Extension and limits
Model and harness are separate. New routes need explicit identity; a new harness must implement identical finite tools, query/output events and budgets. Only mini and Pi are validated. Compare configurations on crossed identical tasks with repeats before drawing model conclusions.

The new freeze CLI accepts `--configurations configurations.json --matrix matrix.json`. Each configuration contains only`provider`(local CCS ID),`model`,`adapter`(`mini`or`pi`),never keys. Matrix entries are`{"task":"S03","configuration":"custom-name"}`. Register the same provider/model under both harnesses to cross them. Freezing does not execute the matrix or authorize large API spending.

Budgets:6 calls per task,6144 output tokens per call,24tools,one native partition candidate. Eight attempts are a development pilot, not the proposed96-run study. Rate limits, environment failures, missing submissions and numerical failures remain distinct. Actual billing is unknown; SDK zero-cost fields are placeholders. No credits were purchased.
